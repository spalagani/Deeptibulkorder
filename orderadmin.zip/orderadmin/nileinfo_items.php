<?
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
include("FCKeditor/fckeditor.php");
extract($_REQUEST);
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='validation.js'></script>

<script type="text/javascript">
//var _editor_url  = document.location.href.replace(/examples\/simple_example\.html.*/, '')
// And the language we need to use in the editor.
var _editor_lang = "en";
//var _editor_url  = document.location.href.replace(/xinha\/xinha\*/, '')
var _editor_url = "../../auction/admin/xinha/";
</script>
<!-- Load up the actual editor core -->
<script type="text/javascript" src="xinha/htmlarea.js"></script>
<script type="text/javascript">
/*var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'SpellChecker', 'Stylist', 'SuperClean', 'TableOperations', 'ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText', 'InsertSmiley', 'InsertAnchor', 'HorizontalRule', 'GetHtml', 'FullScreen', 'BackgroundImage','InsertWords','ListType'
 ];*/
 var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'Stylist', 'SuperClean','TableOperations','ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText',  'InsertAnchor','HtmlEntities','FullPage','ContextMenu'
];
/************************************************************************
 * Names of the textareas you will be turning into editors
 ************************************************************************/
var xinha_editors =
[
   'cat_desc1'
];
/************************************************************************
 * Initialisation function
 ************************************************************************/
function xinha_init()
{
  // THIS BIT OF JAVASCRIPT LOADS THE PLUGINS, NO TOUCHING  :)
  //var _editor_url  = document.location.href.replace(/xinha\*/, '');
 // alert(_editor_url);
  if(!HTMLArea.loadPlugins(xinha_plugins, xinha_init)) return;
  var xinha_config = new HTMLArea.Config();
    xinha_editors = HTMLArea.makeEditors(xinha_editors, xinha_config, xinha_plugins);
   //xinha_editors.cat_smdesc.config.width = '600px';
  // xinha_editors.cat_smdesc.config.height = '400px';
   xinha_editors.cat_desc.config.width = '500px';
   xinha_editors.cat_desc.config.height = '300px';
   //xinha_editors.cat_smdesc.config.statusBar = false;
   xinha_editors.cat_desc.config.statusBar = false;
   HTMLArea.startEditors(xinha_editors);
}
window.onload = xinha_init;
</script>
<script language="javascript" type="text/javascript" src="includes/scripts.js"></script>
<script language="javascript">
function delete1(uid){
	if(confirm("Are you sure want to delete?")){
		document.location.href = 'nileinfo_items.php?del=1&uid='+uid;
	}
}
function open_window(img_name)
{
	url = "../images/categories/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function open_window1(img_name)
{
	url = "../images/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}

</script>
<script language="javascript">
	function changeaudio(f){//alert(f.value);
	if(f.value == 1){
		if(navigator.appName == "Microsoft Internet Explorer"){
			document.getElementById("cur_inscomp").style.display = "block";
		}else{
			document.getElementById("cur_inscomp").style.display = "table-row";
		}
	}else{
		document.getElementById("cur_inscomp").style.display = "none";
	}
  }

</script>
<script type="text/javascript">
function itemsorting()
{

var sortvalue=document.formx1.itemdisplay.value;

document.formx1.action='nileinfo_items.php?sortid='+sortvalue+'&act=view';
document.formx1.submit();
}


</script>
<link type="text/css" rel="stylesheet" title="xp-green" href="xinha/skins/xp-green/skin.css">
</head>
<?
///////////////////////////////single delete/////////////////////////////////
	$del=$_REQUEST['del'];
	$uid=$_REQUEST['uid'];
	if($del==1)
	{
			
			//delete_directory("../images/categories/".$name."/");

			$delete2=mysql_query("delete from nile_items where item_id='$uid'");
			header("location:nileinfo_items.php?act=view");
			exit;
			
	}
///////////////////////////////////////multiple delete///////////////////////////
	$ok=$_REQUEST[ok];
	$colors=$_REQUEST['chk'];
	$chk1=$_REQUEST['chk1'];
	$number=count($colors);
	if($ok=='alldel')
	{
		foreach($colors as $chk1)
		{
			
			$delete2=mysql_query("delete from nile_items where item_id='$chk1'");
		}
		header("location:nileinfo_items.php?act=view");
		exit;	
			
	}
//////////////////////////////end of multiple delete///////////////////////////////////	
$ok=$_REQUEST[ok];
//echo $ok;exit;
//////////////////////////////////////ADD////////////////////////////////////////////
if($ok==add)
{
	//echo "SELECT * FROM auc_categories WHERE listing_id='$listing_id' and name='$name'";exit;
	$selCat = mysql_query("SELECT * FROM nile_items WHERE item_name='$itemname' And where cat_type='3'");
	//echo "SELECT * FROM nile_category WHERE cat_name='$catname'";exit;
	$num=mysql_num_rows($selCat);
	if($num<=0)
	{
			$item_image = $_FILES['file']['name'];
			uploadFile($_FILES['file']['tmp_name'],'../images/pictures/'.$item_image);
			
			/************************************Resizing the image 209x178****************/
			if($item_image<>'')
			{
			$path="../images/pictures/";
			$filetype=$_FILES['file']['type'];
			$bgim_file_name = $path."/".$item_image; 
			
			$bgimage_attribs = getimagesize($bgim_file_name);
			
			
			if($filetype=='image/gif')	{
				$bgim_old = imagecreatefromgif($bgim_file_name); 
			}	
			else	{
				 $bgim_old = imagecreatefromjpeg($bgim_file_name);
			}
						
			$bgth_max_width = 201; //for Album image
			$bgth_max_height = 91;
			$bgratio = ($bgwidth > $bgheight) ? $bgth_max_width/$bgimage_attribs[0] : $bgth_max_height/$bgimage_attribs[1];
		
			$bgth_width = 201;//$image_attribs[0] * $ratio; 
			$bgth_height = 91;//$image_attribs[1] * $ratio;
		
			$bgim_new = imagecreatetruecolor($bgth_width,$bgth_height); 
			imageantialias($bgim_new,true); 
			 $bgth_file_name = "../images/thumbnailpictures1/$item_image";
						 
			imagecopyresampled($bgim_new,$bgim_old,0,0,0,0,$bgth_width,$bgth_height, $bgimage_attribs[0], $bgimage_attribs[1]);
		
			if($filetype=='image/gif')	{									
				imagegif($bgim_new,$bgth_file_name,100); 
			}	else	{
				imagejpeg($bgim_new,$bgth_file_name,100);
			}}
			////////////////////////////////////////end resize/////////////////////////////////////
			
			/************************************Resizing the image 209x178****************/
	
				if($item_image<>'')
			{
			$path1="../images/pictures/";
			$filetype1=$_FILES['file']['type'];
			$bgim_file_name1 = $path."/".$item_image; 
			
			$bgimage_attribs1 = getimagesize($bgim_file_name1);
			
			
			if($filetype1=='image/gif')	{
				$bgim_old1 = imagecreatefromgif($bgim_file_name1); 
			}	
			else	{
				 $bgim_old1 = imagecreatefromjpeg($bgim_file_name1);
			}
						
			$bgth_max_width1 = 120; //for Album image
			$bgth_max_height1 = 120;
			$bgratio1 = ($bgwidth1 > $bgheight1) ? $bgth_max_width1/$bgimage_attribs1[0] : $bgth_max_height1/$bgimage_attribs1[1];
		
			$bgth_width1 = 120;//$image_attribs[0] * $ratio; 
			$bgth_height1 = 120;//$image_attribs[1] * $ratio;
		
			$bgim_new1 = imagecreatetruecolor($bgth_width1,$bgth_height1); 
			imageantialias($bgim_new1,true); 
			 $bgth_file_name1 = "../images/thumbnailpictures2/$item_image";
						 
			imagecopyresampled($bgim_new1,$bgim_old1,0,0,0,0,$bgth_width1,$bgth_height1, $bgimage_attribs1[0], $bgimage_attribs1[1]);
		
			if($filetype1=='image/gif')	{									
				imagegif($bgim_new1,$bgth_file_name1,100); 
			}	else	{
				imagejpeg($bgim_new1,$bgth_file_name1,100);
			}}
			////////////////////////////////////////end resize/////////////////////////////////////
			
			
			$item_audio = $_FILES['audio_file']['name'];
			uploadFile($_FILES['audio_file']['tmp_name'],'../images/audio/'.$item_audio);
			
		$sql=mysql_query("insert into nile_items (cat_id,item_name,file_type,item_address,item_audio,item_shortdesc,item_description,item_metakeyword,item_metadesc,status,date_added,createdby,cat_type,rate_status) values('$category','$itemname','$have_hins','$item_image','$item_audio','$sdesc','$item_desc','$item_metakeyword','$item_metadesc','$status',now(),
		'a_".$_SESSION['admin_id']."',3,'$rate_status')");
		
		/*echo "insert into nile_items (cat_id,item_name,item_address,item_audio,item_description,item_metakeyword,item_metadesc,status,date_added) values('$category','$itemname','$item_image','$item_audio','$item_desc','$item_metakeyword','$item_metadesc','$status',now())";exit;*/
		header("location:nileinfo_items.php?act=view");
		exit;
	}
	else
	{
		header("location:nileinfo_items.php?act=new&error=1");
		exit;
	}
	
}
//////////////////////////////////////update////////////////////////////////////////////
if($ok==edit)
{	
extract($_REQUEST);
		
		$sql_filetype=mysql_query("select * from nile_items where item_id = $idno");
		$row_filetype=mysql_fetch_array($sql_filetype);
		//echo $row_filetype['item_audio'];exit;
			if($have_hins==0 && $row_filetype['item_audio']!="")
			{
				//echo "Update nile_items set item_audio='' where item_id = $idno";exit;
				$update_filetype=mysql_query("Update nile_items set item_audio='' where item_id = $idno");
			}
		
		$sql=mysql_query("select * from nile_items where item_name='$itemname' && item_id != $idno");
		$row=mysql_fetch_array($sql);
		$cc=mysql_num_rows($sql);
		if($cc<=0)
		{	
				$item_edit_image = $_FILES['file']['name'];
				if($item_edit_image!="")
				{
					uploadFile($_FILES['file']['tmp_name'],'../images/pictures/'.$item_edit_image);
					/************************************Resizing the image 209x178****************/
			if($item_edit_image<>'')
			{
			$path="../images/pictures/";
			$filetype=$_FILES['file']['type'];
			$bgim_file_name = $path."/".$item_edit_image; 
			
			$bgimage_attribs = getimagesize($bgim_file_name);
			
			
			if($filetype=='image/gif')	{
				$bgim_old = imagecreatefromgif($bgim_file_name); 
			}	
			else	{
				 $bgim_old = imagecreatefromjpeg($bgim_file_name);
			}
						
			$bgth_max_width = 201; //for Album image
			$bgth_max_height = 91;
			$bgratio = ($bgwidth > $bgheight) ? $bgth_max_width/$bgimage_attribs[0] : $bgth_max_height/$bgimage_attribs[1];
		
			$bgth_width = 201;//$image_attribs[0] * $ratio; 
			$bgth_height = 91;//$image_attribs[1] * $ratio;
		
			$bgim_new = imagecreatetruecolor($bgth_width,$bgth_height); 
			imageantialias($bgim_new,true); 
			 $bgth_file_name = "../images/thumbnailpictures1/$item_edit_image";
						 
			imagecopyresampled($bgim_new,$bgim_old,0,0,0,0,$bgth_width,$bgth_height, $bgimage_attribs[0], $bgimage_attribs[1]);
		
			if($filetype=='image/gif')	{									
				imagegif($bgim_new,$bgth_file_name,100); 
			}	else	{
				imagejpeg($bgim_new,$bgth_file_name,100);
			}}
			////////////////////////////////////////end resize/////////////////////////////////////
			
			/************************************Resizing the image 209x178****************/
	
				if($item_edit_image<>'')
			{
			$path1="../images/pictures/";
			$filetype1=$_FILES['file']['type'];
			$bgim_file_name1 = $path."/".$item_edit_image; 
			
			$bgimage_attribs1 = getimagesize($bgim_file_name1);
			
			
			if($filetype1=='image/gif')	{
				$bgim_old1 = imagecreatefromgif($bgim_file_name1); 
			}	
			else	{
				 $bgim_old1 = imagecreatefromjpeg($bgim_file_name1);
			}
						
			$bgth_max_width1 = 120; //for Album image
			$bgth_max_height1 = 120;
			$bgratio1 = ($bgwidth1 > $bgheight1) ? $bgth_max_width1/$bgimage_attribs1[0] : $bgth_max_height1/$bgimage_attribs1[1];
		
			$bgth_width1 = 120;//$image_attribs[0] * $ratio; 
			$bgth_height1 = 120;//$image_attribs[1] * $ratio;
		
			$bgim_new1 = imagecreatetruecolor($bgth_width1,$bgth_height1); 
			imageantialias($bgim_new1,true); 
			 $bgth_file_name1 = "../images/thumbnailpictures2/$item_edit_image";
						 
			imagecopyresampled($bgim_new1,$bgim_old1,0,0,0,0,$bgth_width1,$bgth_height1, $bgimage_attribs1[0], $bgimage_attribs1[1]);
		
			if($filetype1=='image/gif')	{									
				imagegif($bgim_new1,$bgth_file_name1,100); 
			}	else	{
				imagejpeg($bgim_new1,$bgth_file_name1,100);
			}}
			////////////////////////////////////////end resize/////////////////////////////////////
			
				}else 
					{
					$item_edit_image = $lastfile;
					}
				$item_edit_audio = $_FILES['audio_file']['name'];
				if($have_hins==1 && $item_edit_audio!="")
				{
				uploadFile($_FILES['audio_file']['tmp_name'],'../images/audio/'.$item_edit_audio);	
				} 
				elseif($have_hins==1 && $item_edit_audio=="")
				{
					$item_edit_audio=$last_audio_file;
					//echo $item_edit_audio;exit;
				}
				elseif($have_hins==0 && $row_filetype['item_audio']!="") 
				{
				$item_edit_audio ='';
				}
	$updsub=mysql_query("update nile_items set cat_id='$category',item_name='$itemname',file_type='$have_hins',item_address='$item_edit_image',item_audio='$item_edit_audio',item_description='$item_desc',item_metakeyword='$item_metakeyword',item_shortdesc='$sdesc',
	item_metadesc='$item_metadesc',date_added=now(),status='$status',cat_type='3',rate_status='$rate_status' where item_id='$idno'");
	//$id="a_".$idno;
	/*echo "update nile_items set cat_id='$category',item_name='$itemname',item_address='$item_edit_image',item_audio='$item_edit_audio',item_description='$item_desc',item_metakeyword='$item_metakeyword',
	item_metadesc='$item_metadesc',date_added=now(),status='$status' where item_id='$idno'";exit;*/
	header("location:nileinfo_items.php?act=view");
	exit;
	}
	else
	{
		header("location:nileinfo_items.php?act=view&error=1");
		exit;
	}
}
///////////////////paging////////////////////
$PageSize = 20;
$StartRow = 0;
if(empty($_GET['PageNo'])){
    if($StartRow == 0){
        $PageNo = $StartRow + 1;
    }
}else{
    $PageNo = $_GET['PageNo'];
    $StartRow = ($PageNo - 1) * $PageSize;
}

if($PageNo % $PageSize == 0){
    $CounterStart = $PageNo - ($PageSize - 1);
}else{
    $CounterStart = $PageNo - ($PageNo % $PageSize) + 1;
}
//Counter End
$CounterEnd = $CounterStart + ($PageSize - 1);
//////////////////end //////////////////////////////

	
	$TRecord=mysql_query("select * from nile_items where cat_type='3' order by date_added desc");
	$sql=mysql_query("select * from nile_items where cat_type='3' order by date_added desc LIMIT ". $StartRow .",". $PageSize."");


$RecordCount = mysql_num_rows($TRecord);
$MaxPage = $RecordCount % $PageSize;
if($RecordCount % $PageSize == 0){
    $MaxPage = $RecordCount / $PageSize;
 }
else{
    $MaxPage = ceil($RecordCount / $PageSize);
 }

$num=mysql_num_rows($sql);



if(($_REQUEST['sortid']<>''))
{
$act=$_REQUEST['act'];
 $sid=$_REQUEST['sortid'];
$TRecord=mysql_query("select * from nile_items where cat_type='3' and cat_id='$sid' order by date_added desc");
	$sql=mysql_query("select * from nile_items where cat_type='3'  and cat_id='$sid' order by date_added desc LIMIT ". $StartRow .",". $PageSize."");


$RecordCount = mysql_num_rows($TRecord);
$MaxPage = $RecordCount % $PageSize;
if($RecordCount % $PageSize == 0){
    $MaxPage = $RecordCount / $PageSize;
 }
else{
    $MaxPage = ceil($RecordCount / $PageSize);
 }

$num=mysql_num_rows($sql);
}


?>


<body>
	<TABLE cellSpacing=0 cellPadding=0 width=96% align=center border="0">
	
	<tr>
	<td>
	
	          <!--VIEW USERS -->
			  <? if($act=="view"){?>
	<form name="formx1" method="post" enctype="multipart/form-data" id="formx1" >
	
<table width="100%">
	
	<tr>
		<td height="40" align="center" class="style13">&nbsp;<b class="greentext22bold">View Items </b></td>
	</tr>
	<? if($num<=0){?>
	<br>
	<br>
		<tr>
				
			<td height="40" colspan="2" align="center" class="bold_txt">
			<?
				echo "Item Does not exists";
				
				
				//header("Location:nileinfo_items.php?act=new");
			?>
			
			<a href="#" onClick="javascript:history.go(-1);" class="greenlink">Go Back</a>
			</td>
		</tr>
	<? } else { ?>
					
					<tr class="txtblack3" >
					
					
					<?
					
					$cat1=mysql_query("Select * from nile_category where cat_type='3'");
						
						?>
					<td  width="68%" align="right">
					
					<select name="itemdisplay" onchange="itemsorting()">
					<option value="">Select Item category</option>
					<? while ($values=mysql_fetch_array($cat1)){?>
					<option value="<?=$values['cat_id']?>"><?=$values['cat_name']?></option>
					<? } ?>
					</select>
					
					</td>
					
					  <td height="10" align="right" class="normal" colspan="10" ><a href="nileinfo_items.php?act=new" class="greentextbold">Add Items</a></td>
	  </tr>
					<tr class="txtblack3" >
					  <td height="10" align="center" class="normal" colspan="10" ><span class="style14">
					    <?
					  if($error==1)
					  {
					  	echo "Item already exists";
					  }
					  ?>
					  </span></td>
	  </tr>
					<tr class="txtblack3" >
					<td height="10" align="right" class="normal" colspan="10" ><b ><strong><font color="#FF0000">Page: <? echo $PageNo." of ". $MaxPage  ?></font></strong></b></td>
				</tr>
	
	<tr>
		<td colspan="2">
			<table width=61% border="0" align=center cellPadding=0 cellSpacing=0 frame="box" style="border-style:solid; border-width:1px; border-color:#999999" >
				<tr class="txtblack3" bgcolor="#FA9032" >
				  <td width="40" align="center" class="style12"><input type="checkbox" name="selall" onClick="checkstate('chk[]')" ></td>
				  <td width="142" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><b> Item Name </b></div></td>
				  <td width="116" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><b> Image</b></div></td>
				  <td width="141" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><b>Category</b></div></td>
				  <td width="141" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><b>Display Status</b></div></td>
				  <td width="58" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Edit</b></td>
					<td width="58" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Delete</b></td>
			  </tr>
<? 
 while($row=mysql_fetch_array($sql))
{ 
	
?>
				<tr style="background-color:#FFFFFF" onMouseOver="javascript:MouseOverMenu(this);" onMouseOut="javascript:MouseOutMenu(this);">
						<td align="center" class="style12"><input type="hidden" name="chk1[]"  id="chk1" value="<?=$row['item_id']; ?>"> 
   					  <input type="checkbox" name="chk[]"  id="chk" value="<? echo $row['item_id']; ?>" onClick="checkval('chk[]')"></td>
				
				    <td height="28" class="normal style12"><div align="center">
					  <?=$row['item_name']?>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					  <img src="../images/pictures/<?=$row['item_address']?>" width="110" height="95" border="0">
				    </div></td>
					<? 
						$cat=mysql_query("Select * from nile_category where cat_id='".$row['cat_id']."'");
						$rowcat=mysql_fetch_array($cat);
					?>
					 <td height="28" class="normal style12"><div align="center">
					  <?=$rowcat['cat_name']?>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					  <? if($row['status']==1) { ?>Posted to site<? } else { ?>Not Posted to site<? } ?>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					  <a href="nileinfo_items.php?act=edit&aid=<?=$row['item_id']?>"><img src="images/edit_f2.png" width="18" height="18" border="0"></a>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					   <a href="javascript:delete1(<?=$row['item_id']?>)">
					   <img src="images/delete.png" width="18" height="18" border="0"></a>
				    </div></td>
			  </tr><?
					}
					?>
		  </table>	  </td>
		  </tr><tr><td>&nbsp;</td></tr>
					<tr>
					  <td align="center"><img src="images/delete1.gif" onClick="javascript:document.formx1.action='nileinfo_items.php?ok=alldel';document.formx1.submit();"><!--<input name="delete" type="button" class="greentextbold" onClick="javascript:document.formx1.action='nileinfo_items.php?ok=alldel';document.formx1.submit();" value="Delete">--></td>
	  </tr>
					<tr>
					  <td align="right" class="normal">
					  <?php
      	//Print First & Previous Link is necessary
        if($CounterStart != 1){
            $PrevStart = $CounterStart - 1;
            print "<a href=nileinfo_items.php?PageNo=1&act=view class=greenlink>First </a>: ";
            print "<a href=nileinfo_items.php?PageNo=$PrevStart&act=view class=greenlink>Previous </a>";
        }
        print " <font color='red'><b> [ </b></font>";
        $c = 0;

        //Print Page No
        for($c=$CounterStart;$c<=$CounterEnd;$c++){
            if($c < $MaxPage){
                if($c == $PageNo){
                    if($c % $PageSize == 0){
                        print "$c ";
                    }else{
                        print "$c , ";
                    }
                }elseif($c % $PageSize == 0){
                    echo "<a href=nileinfo_items.php?PageNo=$c&act=view class=greenlink>$c</a> ";
                }else{
                    echo "<a href=nileinfo_items.php?PageNo=$c&act=view class=greenlink>$c</a> , ";
                }//END IF


            }else{
                if($PageNo == $MaxPage){
                    print "$c ";
                    break;
                }else{
                    echo "<a href=nileinfo_items.php?PageNo=$c&act=view class=greenlink>$c</a> ";
                    break;
                }
            }
       }

      echo "<font color='red'><b> ]</b> </font> ";

      if($CounterEnd < $MaxPage){

          $NextPage = $CounterEnd + 1;
          echo "<a href=nileinfo_items.php?PageNo=$NextPage&act=view class=greenlink>Next</a>";
      }
      
      //Print Last link if necessary
      if($CounterEnd < $MaxPage){
       $LastRec = $RecordCount % $PageSize;
        if($LastRec == 0){
            $LastStartRecord = $RecordCount - $PageSize;
        }
        else{
            $LastStartRecord = $RecordCount - $LastRec;
        }

        print " : ";
        echo "<a href=nileinfo_items.php?PageNo=$MaxPage&act=view class=greenlink>Last</a>";
        }?></td>
	  </tr>
	
	</table></form>
	
	<?
		}}
	?>
	</td></tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr>
					  <td align="left">
					  
					  			<!--ADD and EDIT -->
					  <? 
				  		
					  if($act=='new' || $act=='edit') {
					   if($act == 'edit'){
					$chn=mysql_query("select * from nile_items where item_id='$aid'");
					$row=getSqlFetch($chn);
					extract($row);
					$selcat=mysql_query("select * from nile_category where cat_id='$row[cat_id]'");
					$res=mysql_fetch_array($selcat);
					}
					  ?>
					  <form name="formx1" method="post" enctype="multipart/form-data">
						<input type="hidden" name='idno' value="<?=$item_id?>">
						<input type="hidden" name='oldname' value="<?=$item_name?>">
					  <TABLE cellSpacing=0 cellPadding=0 width=100% align=center border="0">
                        <tr>
                          <td height="40" colspan="3" align="center" class="txtnolink">&nbsp;<b class="greentext22bold">
                            <?
							if($aid){
							?>
                            Edit Items Details
  <? }else {?>
                            Add Items Details
  <? }?>
                          </b></td>
                        </tr>
						<tr>
						<td colspan="3" align="center" class="style14">
						<?
						if($error==1)
						{
							echo "Category already Exists";
						}
						?>						</td>
						</tr>
                        <tr>
                          <td height="40" colspan="3" align="right" class="txtnolink"><a href="nileinfo_items.php?act=view" class="greentextbold"><b>View Items </b></a>&nbsp;</td>
                        </tr>
						<TR>
                          <TD height="30" align="right" class="itemstyle">Post to site </TD>
                          <TD align="center">:</TD>
                          <td align="left" class="normal"><input name="status" type="radio" value="1" checked />
                            Yes
                            <input name="status" type="radio" value="0" <? if( isset($status) && $status == 0 ){ echo "checked";}?>>
                            No</td>
                        </TR>
                        <TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Items Name</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="itemname" id="itemname" value="<?=$item_name?>" size=25></TD>
                        </TR>
						<?php
							$selcat=mysql_query("select * from nile_category where cat_type='3'"); 
						?>
						 <TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Select Category</TD>
                          <TD width="33" align="center">:</TD>	
                          <TD width="472"><select name="category">
						  				<option value="<? if($act == 'edit') { echo $res['cat_id']; }else { echo "0"; }?>"><? if($act == 'edit') { echo $res['cat_name']; }else { echo "Please select any category"; }?></option>
										<? while($retcat=mysql_fetch_array($selcat)) { ?>
										<option value="<?=$retcat['cat_id']?>">
										<?= $retcat['cat_name']?>
										</option>
										<? } ?>
						  				</select>
						 </TD>
                        </TR>
						<tr>
							 <TD width="415" height="30" align="right" class="itemstyle">Select the type of file you want to upload</TD>
								 <TD width="33" align="center">:</TD>	
								<TD width="472"><input  type="radio" id="have_hins" name="have_hins" value="0" onClick="javascript:changeaudio(this);" <? if($act='edit'){ if($file_type=='0') { echo "checked=checked"; } else {  ?> checked="checked" <? }} ?>>
								  Image
								  <input  type="radio" id="have_hins" name="have_hins" value="1" onClick="javascript:changeaudio(this);" <? if($act='edit'){ if($file_type=='1') { echo "checked=checked"; } }  ?>>
								  Audio</td>
						</tr>
						
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Upload Image</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="file" type="file" id="file" value="<?=$item_address?>" size=25><span class="bold_txt">(W:209,H:178)</span></TD>
                        </TR>
						<? if(isset($aid) && $act=='edit'){ ?>
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">&nbsp;</TD>
                          <TD width="33" align="center"></TD>
                          <TD width="472"><input name="lastfile" type="hidden" id="file" value="<?=$item_address?>" size=25><img src="../images/pictures/<?=$item_address?>" width="110" height="95" border="0">&nbsp;<?=$item_address?></TD>
                        </TR>
                        <? }?>

						<TR style="display:none;" id="cur_inscomp">
                          <TD width="415" height="30" align="right" class="itemstyle">Upload Audio</TD>
                          <TD width="33" align="center">:</TD>
                         <TD width="472"><input name="audio_file" type="file" id="audio_file" value="<?=$item_audio?>" size=25></TD>
                        </TR>
					    <? if($act == 'edit'){?>
<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">&nbsp;</TD>
                          <TD width="33" align="center"></TD>
                          <TD width="472"><input name="last_audio_file" type="hidden" id="last_audio_file" value="<?=$item_audio?>" size=25><?=$item_audio?></TD>
                        </TR>
						
						<? }?>
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Short description</TD>
                          <TD width="33" align="center">:</TD>	
                          <TD width="472"><input name="sdesc" id="sdesc" value="<?=$item_shortdesc?>" size=25></TD>
                        </TR>
                        <TR>	
                          <TD height="30" align="right" class="itemstyle">Long Description</TD>
                          <TD align="center">:</TD>
                          <TD><?php /*?><textarea name="item_desc" cols="25" rows="5" id="item_desc" style="width:173px"><?=stripslashes($item_description)?></textarea><?php */?>
						  <?php
								$oFCKeditor = new FCKeditor('item_desc') ; 
								$oFCKeditor->BasePath = 'FCKeditor/';
								$oFCKeditor->Value = $item_description;
								$oFCKeditor->Width  = '550' ;
								$oFCKeditor->Height = '400' ;
								$oFCKeditor->Create() ;
			 			?>  
						  </TD>
                        </TR>
						 <TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Meta keyword</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="item_metakeyword" id="item_metakeyword" value="<?=$item_metakeyword?>" size=25></TD>
                        </TR>
						<TR>
                          <TD height="30" align="right" class="itemstyle">Meta Description</TD>
                          <TD align="center">:</TD>
                          <TD><textarea name="item_metadesc" cols="25" rows="5" id="item_metadesc" style="width:173px"><?=stripslashes($item_metadesc)?></textarea>                          </TD>
                        </TR>
                        
						<TR>
                          <TD height="30" align="right" class="itemstyle">Rating Option</TD>
                          <TD align="center">:</TD>
                          <td align="left" class="normal"><input name="rate_status" type="radio" value="1" checked />
                            Yes
                            <input name="rate_status" type="radio" value="0" <? if( isset($rate_status) && $rate_status == 0 ){ echo "checked";}?>>
                            No</td>
                        </TR>
                        <TR>
                          <TD height="60" colspan="3" align="center"><?
			if($aid){
			?>
                              <img src="images/update.gif"  onClick="javascript:return nileinfo_items1();"><!--<input name="submit" type="submit" class="normal" onClick="javascript:return items1();" value='Update'>-->
                              <?
		} else {
		?>
                <img src="images/additems.gif"  onClick="javascript:return nileinfo_items();"><!--<input name="submit" type="submit" class="normal" onClick="javascript:return items();" value='Add Categories'>-->
                            <? }?>
                            &nbsp;
                            <img src="images/cancel.gif" onClick="javascript:document.formx1.action='nileinfo_items.php?act=view';document.formx1.submit();"><!--<input name="submit1" type="submit" class="normal" onClick="javascript:document.formx1.action='nileinfo_items.php?act=view';document.formx1.submit();" value="Cancel">-->                          </TD>
                        </TR>
                        <TR>
                          <TD height="50" colspan="3">&nbsp;</TD>
                        </TR>
                      </TABLE>
					  <?
					  }
					  ?>
					  </form>
					 <!-- END ADD AND EDIT -->
					  
					  </td>
	  </tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr><td align="center">&nbsp;</td>
					</tr>
					
					</TABLE>

					</body>
					</html>
			