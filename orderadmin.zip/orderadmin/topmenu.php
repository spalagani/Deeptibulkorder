<?
ob_start();
session_start();
include("../includes/dbconfig.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?=$title?></title>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style122 {color: #22241C}
-->
</style>
</head>
<body topmargin="0" leftmargin="0" rightmargin="0" > 

<table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/innerbg.jpg" >
  <tr>
    <td width="8%" height="60" align="left" valign="middle">
	
	<!--<img src="images/logo.gif">-->
	
	<!--<img src="images/<?=$alogo?>" />-->
	
	</td>
      
    <td width="70%" height="60"></td>
    <td width="22%" align="left" valign="middle" class="copy-text"><div align="center"><span class="style122">Deepti Publications
         
        <br />
        All rights reserved</span>.</div></td>
  </tr></table>

<map name="Map">
<area shape="rect" coords="1,1,193,58" href="home.php" target="main">
</map>
</body>
</html>
