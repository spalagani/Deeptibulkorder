<?
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
extract($_REQUEST);
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" media="all" href="../calendar-win2k-cold-1.css" title="win2k-cold-1" />
<script type="text/javascript" src="../cal/calendar.js"></script>
<script type="text/javascript" src="../cal/calendar-en.js"></script>
<script type="text/javascript" src="../cal/calendar-setup.js"></script>

<script language="javascript"></script>
<script language="javascript" type="text/javascript" src="validation.js"></script>
<script type="text/javascript">
function scat12()
{

var id2=document.formx1.category1.value;
	document.formx1.category.options.length=1;	
var a1=0;

<?php $selSub12 = mysql_query("Select * from nile_category") ;
						  $num12=mysql_num_rows($selSub12);
							while($data12=mysql_fetch_array($selSub12)) { ?>
							
					//alert(id1);
if(id2 == '<?=$data12[cat_type]?>') {
a1++;
document.formx1.category.options.length=document.formx1.category.options.length+1;
document.formx1.category.options[a1].text='<?=$data12[cat_name]?>';
document.formx1.category.options[a1].value='<?=$data12[cat_id]?>';
}
<?php } ?>
}




function scatite()
{
var id1=document.formx1.category.value;
document.formx1.category.options.length=1;

var a=0;
<?php $selSub = mysql_query("SELECT * FROM nile_items" );
						  $num1=mysql_num_rows($selSub);
							while($data1=mysql_fetch_array($selSub)) { ?>
							
					//alert('<?//=$data1[cat_id]?>');
					//alert(id1);
if(id1 == '<?=$data1[cat_id]?>') {
a++;
document.formx1.subcat_id.options.length=document.formx1.subcat_id.options.length+1;
document.formx1.subcat_id.options[a].text='<?=$data1[item_name]?>';
document.formx1.subcat_id.options[a].value='<?=$data1[cat_id]?>';
}
<?php } ?>
}
</script>
<script type="text/javascript">
//var _editor_url  = document.location.href.replace(/examples\/simple_example\.html.*/, '')
// And the language we need to use in the editor.
var _editor_lang = "en";
//var _editor_url  = document.location.href.replace(/xinha\/xinha\*/, '')
var _editor_url = "../../auction/admin/xinha/";
</script>
<!-- Load up the actual editor core -->
<script type="text/javascript" src="xinha/htmlarea.js"></script>
<script type="text/javascript">
/*var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'SpellChecker', 'Stylist', 'SuperClean', 'TableOperations', 'ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText', 'InsertSmiley', 'InsertAnchor', 'HorizontalRule', 'GetHtml', 'FullScreen', 'BackgroundImage','InsertWords','ListType'
 ];*/
 var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'Stylist', 'SuperClean','TableOperations','ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText',  'InsertAnchor','HtmlEntities','FullPage','ContextMenu'
];
/************************************************************************
 * Names of the textareas you will be turning into editors
 ************************************************************************/
var xinha_editors =
[
   'cat_desc1'
];
/************************************************************************
 * Initialisation function
 ************************************************************************/
function xinha_init()
{
  // THIS BIT OF JAVASCRIPT LOADS THE PLUGINS, NO TOUCHING  :)
  //var _editor_url  = document.location.href.replace(/xinha\*/, '');
 // alert(_editor_url);
  if(!HTMLArea.loadPlugins(xinha_plugins, xinha_init)) return;
  var xinha_config = new HTMLArea.Config();
    xinha_editors = HTMLArea.makeEditors(xinha_editors, xinha_config, xinha_plugins);
   //xinha_editors.cat_smdesc.config.width = '600px';
  // xinha_editors.cat_smdesc.config.height = '400px';
   xinha_editors.cat_desc.config.width = '500px';
   xinha_editors.cat_desc.config.height = '300px';
   //xinha_editors.cat_smdesc.config.statusBar = false;
   xinha_editors.cat_desc.config.statusBar = false;
   HTMLArea.startEditors(xinha_editors);
}
window.onload = xinha_init;
</script>
<script language="javascript">
function open_window(img_name)
{
	url = "../images/categories/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function open_window1(img_name)
{
	url = "../images/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function delete1(uid){
	if(confirm("Are you sure want to delete?")){
		document.location.href = 'events.php?del=1&uid='+uid;
	}
}
</script>
<?php /*?><script language="javascript">
function validate(f)
{

	if(!GenValidation(f.eventname,'Event Name','',''))
	{
		return false;
	}
	if(!GenValidation(f.cname,'Contact Phone','',''))
	{
		return false;
	}
	if(!GenValidation(f.sdesc,'Introduction','',''))
	{
		return false;
	}
	if(!GenValidation(f.desc,'Profile','',''))
	{
		return false;
	}
	if(f.category1.value=='')
	{
	alert("Please Select Main Category");
	f.category1.focus();
	return false;
	}
	if(f.category.value=='')
	{
	alert("Please Select Category");
	f.category.focus();
	return false;
	}
	if(f.subcat_id.value=='')
	{
	alert("Please Select Sub Category");
	f.subcat_id.focus();
	return false;
	}
	if(f.picture.value=='')
	{
	alert("Please upload image");
	f.picture.focus();
	return false;
	}
	if(!GenValidation(f.venuename,'Venue Name','',''))
	{
		return false;
	}
	if(!GenValidation(f.address,'Address','',''))
	{
		return false;
	}
	if(!GenValidation(f.city,'City','',''))
	{
		return false;
	}
	if(f.type.value=='')
	{
	alert("Please Select Venue Type");
	f.type.focus();
	return false;
	}
	if(!GenValidation(f.vphone,'Phone Number','',''))
	{
		return false;
	}
	var radio_ch=false;
	for (counter = 0; counter < f.paymentcat.length; counter++)
    {
      if (f.paymentcat[counter].checked)
      radio_ch = true; 
    }
    if (!radio_ch)
    {
    alert("Please select a Radio Button");
	return false;
     }
	if(!GenValidation(f.price,'Price Summary','',''))
	{
		return false;
	}
	if(!GenValidation(f.ticketlink,'Tickets Link','',''))
	{
		return false;
	}
	if(!GenValidation(f.pphone,'Phone Number ','',''))
	{
		return false;
	}
	if(!GenValidation(f.startdate,'Start Date','',''))
	{
		return false;
	}
	if(!GenValidation(f.enddate,'End Date','',''))
	{
		return false;
	}
	if(f.timefrom.value=='')
	{
	alert("Please Select Start Time");
	f.timefrom.focus();
	return false;
	}
	if(f.timeto.value=='')
	{
	alert("Please Select End Time");
	f.timeto.focus();
	return false;
	}
	return true;
}
</script><?php */?>
<script type="text/javascript">

function scat1()
{
var id2=document.events.category1.value;
		
var a1=0;

<?php $selSub12 = mysql_query("Select * from nile_category") ;
						  $num12=mysql_num_rows($selSub12);
							while($data12=mysql_fetch_array($selSub12)) { ?>
							
					//alert(id1);
if(id2 == '<?=$data12[cat_type]?>') {
a1++;
document.events.category.options.length=document.events.category.options.length+1;
document.events.category.options[a1].text='<?=$data12[cat_name]?>';
document.events.category.options[a1].value='<?=$data12[cat_id]?>';
}
<?php } ?>
}




function scat()
{
var id1=document.events.category.value;


var a=0;
<?php $selSub = mysql_query("SELECT * FROM nile_items" );
						  $num1=mysql_num_rows($selSub);
							while($data1=mysql_fetch_array($selSub)) { ?>
							
					//alert('<?//=$data1[cat_id]?>');
					//alert(id1);
if(id1 == '<?=$data1[cat_id]?>') {
a++;
document.events.subcat_id.options.length=document.events.subcat_id.options.length+1;
document.events.subcat_id.options[a].text='<?=$data1[item_name]?>';
document.events.subcat_id.options[a].value='<?=$data1[cat_id]?>';
}
<?php } ?>
}
</script>
<link type="text/css" rel="stylesheet" title="xp-green" href="xinha/skins/xp-green/skin.css">
</head>
<?
///////////////////////////////single delete/////////////////////////////////
	$del=$_REQUEST['del'];
	$uid=$_REQUEST['uid'];
	if($del==1)
	{
			
			//delete_directory("../images/categories/".$name."/");

			$delete2=mysql_query("delete from nile_events where event_id='$uid'");
			header("location:events.php?act=view");
			exit;
			
	}
///////////////////////////////////////multiple delete///////////////////////////
	$ok=$_REQUEST[ok];
	$colors=$_REQUEST['chk'];
	$chk1=$_REQUEST['chk1'];
	$number=count($colors);
	if($ok=='alldel')
	{
		foreach($colors as $chk1)
		{
			
			$delete2=mysql_query("delete from nile_events where event_id='$chk1'");
		}
		header("location:events.php?act=view");
		exit;	
			
	}
//////////////////////////////end of multiple delete///////////////////////////////////	
$ok=$_REQUEST[ok];
//echo $ok;exit;
//////////////////////////////////////ADD////////////////////////////////////////////
if($ok==add)
{

$sdesc=str_replace("'","\'",$sdesc);

$desc=str_replace("'","\'",$desc);

	if($audience<>'')
{
foreach($audience as $value)
{ $audience1.=$value.",";
}
}	
$event_audience=substr($audience1,0,-1);
	
if(is_uploaded_file($_FILES["picture"]["tmp_name"])){
			
				move_uploaded_file($_FILES["picture"]["tmp_name"], "../eventpicture/" . $_FILES["picture"]["name"]);
				
				$Attachments=$_FILES["picture"]["name"];
				
			}
	
	
	
$filetype=$_FILES['picture']['type'];
/************************************Resizing the image 88x120****************/
			$path="../eventpicture";
			$bgim_file_name = $path."/".$Attachments; 
			$bgimage_attribs = getimagesize($bgim_file_name);
		
			if($filetype=='image/gif')	{
				$bgim_old = imagecreatefromgif($bgim_file_name); 
			}	
			else	{
				 $bgim_old = imagecreatefromjpeg($bgim_file_name);
			}
						
			$bgth_max_width = 180; //for Album image
			$bgth_max_height = 180;
			$bgratio = ($bgwidth > $bgheight) ? $bgth_max_width/$bgimage_attribs[0] : $bgth_max_height/$bgimage_attribs[1];
		
			$bgth_width = 180;//$image_attribs[0] * $ratio; 
			$bgth_height = 180;//$image_attribs[1] * $ratio;
		
			$bgim_new = imagecreatetruecolor($bgth_width,$bgth_height); 
			imageantialias($bgim_new,true); 
			$bgth_file_name = "../eventpicture/displaypicture/$Attachments";
						 
			imagecopyresampled($bgim_new,$bgim_old,0,0,0,0,$bgth_width,$bgth_height, $bgimage_attribs[0], $bgimage_attribs[1]);
		
			if($filetype=='image/gif')	{									
				imagegif($bgim_new,$bgth_file_name,100); 
			}	else	{
				imagejpeg($bgim_new,$bgth_file_name,100);
			}
			////////////////////////////////////////end resize/////////////////////////////////////
	
	// $seluname = mysql_query("SELECT * FROM nile_user WHERE eventname='$username'");
	//$num=mysql_num_rows($seluname);
	//if($num<=0)
	//{
	
		list($month,$date,$year)=split('[/]',$startdate);
		$datefrm=$year."-".$month."-".$date;
		list($month1,$date1,$year1)=split('[/]',$enddate);
		$dateto1=$year1."-".$month1."-".$date1;
	
	/*echo $event_sql="insert into nile_events(event_name,event_shortdesc,event_desc,event_type,event_subcat,event_picture,) values('$eventname','$sdesc','$desc,'$category','$subcat_id','$Attachments')";*/
		
		 $sel_event = mysql_query("SELECT * FROM nile_events WHERE event_name='$eventname'");
		
		$event_record=mysql_num_rows($sel_event);
		if($event_record<=0)
		{
	
	   $event_sql="insert into nile_events(event_name,event_shortdesc,event_desc,event_type,event_cat,event_subcat,event_picture,event_address,contactphone,url,Tags,event_fromdate,event_todate,event_day,audience,payment_type,price_summary,ticket_link,ticket_phone,event_status,event_featured) values('$eventname','$sdesc','$desc','$category1','$category','$subcat_id','$Attachments','$address','$cname','$url','$tag','$datefrm','$dateto1','$weekday','$event_audience','$paymentcat','$price','$ticketlink','$pphone','1','$featured')";
			 
	$sql_execute=mysql_query($event_sql)or die(mysql_error());
	
	 $insert_id=mysql_insert_id();
	
	 $event_address="insert into  nile_event_address(venue_name,venue_address,venue_city,venue_type,event_id,phone)values('$venuename','$address','$city','$type','$insert_id','$vphone')";
			  
	$execute_address=mysql_query($event_address);

$event_fromtime=$timefrom.":".$timefrom.":".$medfrom;
$event_totime=$timeto.":".$timeto.":".$medto;
if((isset($_REQUEST['ftime']))&($_REQUEST['ftime']<>''))
{
$event_fromtime="fulltime";
$event_totime="fulltime";
}

	 $event_date="insert into nile_event_date(event_id,event_fromdate,event_todate,event_fromtime,event_totime)values('$insert_id','$datefrm','$dateto1','$event_fromtime','$event_totime')";
	$execute_date=mysql_query($event_date); 
	$value=1;
}
else
{
$value="no";
}
	header("location:events.php?act=view&=1");
}
//////////////////////////////////////update////////////////////////////////////////////
if($ok==edit)
{	
extract($_REQUEST);

$sdesc=str_replace("'","\'",$sdesc);

$desc=str_replace("'","\'",$desc);
	
		if($audience<>'')
{
foreach($audience as $value)
{ $audience1.=$value.",";
}
$event_audience=substr($audience1,0,-1);
}	
		list($month,$date,$year)=split('[/]',$startdate);
		$datefrm=$year."-".$month."-".$date;
		list($month1,$date1,$year1)=split('[/]',$enddate);
		$dateto1=$year1."-".$month1."-".$date1;
		
		
		if($_FILES["picture"]["tmp_name"]==''){
		
	    $event_update="update  nile_events set 
	 event_name='$eventname',
	 event_shortdesc='$sdesc',
	 event_desc='$desc',
	 event_type='$category1',
	 event_cat='$category',
	 event_subcat='$subcat_id',
	 event_address='$address',
	 contactphone='$cname',
	 url='$url',
	 Tags='$tag',
	 event_fromdate='$datefrm',
	 event_todate='$dateto1',
	 event_day='$weekday',
	 audience='$event_audience',
	 payment_type='$paymentcat',
	 price_summary='$price',
	 ticket_link='$ticketlink',
	 ticket_phone='$pphone',
	 event_status='$status',
	 event_featured='$featured'	 
	  where event_id='$idno'";
	 
	 $update_exec=mysql_query($event_update);
		
		}
		else
		{
		
		if(is_uploaded_file($_FILES["picture"]["tmp_name"])){
			
				move_uploaded_file($_FILES["picture"]["tmp_name"], "../eventpicture/" . $_FILES["picture"]["name"]);
				
				$Attachments=$_FILES["picture"]["name"];
				
			}
			
			
/************************************Resizing the image 180x180****************/
			$filetype=$_FILES['picture']['type'];
			$path="../eventpicture";
			 $bgim_file_name = $path."/".$Attachments; 
			$bgimage_attribs = getimagesize($bgim_file_name);
		
			if($filetype=='image/gif')	{
				$bgim_old = imagecreatefromgif($bgim_file_name); 
			}	
			else	{
				 $bgim_old = imagecreatefromjpeg($bgim_file_name);
			}
						
			$bgth_max_width = 180; //for Album image
			$bgth_max_height = 180;
			$bgratio = ($bgwidth > $bgheight) ? $bgth_max_width/$bgimage_attribs[0] : $bgth_max_height/$bgimage_attribs[1];
		
			$bgth_width = 180;//$image_attribs[0] * $ratio; 
			$bgth_height = 180;//$image_attribs[1] * $ratio;
		
			$bgim_new = imagecreatetruecolor($bgth_width,$bgth_height); 
			imageantialias($bgim_new,true); 
			 $bgth_file_name = "../eventpicture/displaypicture/$Attachments";
						 
			imagecopyresampled($bgim_new,$bgim_old,0,0,0,0,$bgth_width,$bgth_height, $bgimage_attribs[0], $bgimage_attribs[1]);
		
			if($filetype=='image/gif')	{									
				imagegif($bgim_new,$bgth_file_name,100); 
			}	else	{
				imagejpeg($bgim_new,$bgth_file_name,100);
			}
			////////////////////////////////////////end resize/////////////////////////////////////
			
		      $event_update="update  nile_events set 
	 event_name='$eventname',
	 event_shortdesc='$sdesc',
	 event_desc='$desc',
	 event_type='$category1',
	 event_cat='$category',
	 event_subcat='$subcat_id',
	 event_picture='$Attachments',
	 event_address='$address',
	 contactphone='$cname',
	 url='$url',
	 Tags='$tag',
	 event_fromdate='$datefrm',
	 event_todate='$dateto1',
	 event_day='$weekday',
	 audience='$event_audience',
	 payment_type='$paymentcat',
	 price_summary='$price',
	 ticket_link='$ticketlink',
	 ticket_phone='$pphone',
	 event_status=1 where event_id=$idno";
	 
	 $update_exec=mysql_query($event_update);
	 
	 }
		 	 
		 	  $update_address="update nile_event_address set 
					venue_name='$venuename',
					venue_address='$address',
					venue_city='$city',
					venue_type='$type',
					phone='$vphone' where event_id='$idno'";
					
											  
				$execute_address=mysql_query($update_address);
			
			$event_fromtime=$timefrom.".".$timefrom.":".$medfrom;
			$event_totime=$timeto.".".$timeto.":".$medto;
			if((isset($_REQUEST['ftime']))&($_REQUEST['ftime']<>''))
			{
			$event_fromtime="fulltime";
			$event_totime="fulltime";
			}
			
				 $event_date="update nile_event_date
				event_fromdate='$startdate',
				event_todate='$enddate',
				event_fromtime='$event_fromtime',
				event_totime='$event_totime' where event_id='$idno' ";
				$execute_date=mysql_query($event_date); 
				$value=1;
	header("location:events.php?act=view&=1");





	/*}
	else
	{
		header("location:events.php?act=view&=1");
		exit;*/
	
}
///////////////////paging////////////////////
$PageSize = 20;
$StartRow = 0;
if(empty($_GET['PageNo'])){
    if($StartRow == 0){
        $PageNo = $StartRow + 1;
    }
}else{
    $PageNo = $_GET['PageNo'];
    $StartRow = ($PageNo - 1) * $PageSize;
}

if($PageNo % $PageSize == 0){
    $CounterStart = $PageNo - ($PageSize - 1);
}else{
    $CounterStart = $PageNo - ($PageNo % $PageSize) + 1;
}
//Counter End
$CounterEnd = $CounterStart + ($PageSize - 1);
//////////////////end //////////////////////////////

	
	$TRecord=mysql_query("select * from nile_events ");
	$sql=mysql_query("select * from nile_events  LIMIT ". $StartRow .",". $PageSize."");


$RecordCount = mysql_num_rows($TRecord);
$MaxPage = $RecordCount % $PageSize;
if($RecordCount % $PageSize == 0){
    $MaxPage = $RecordCount / $PageSize;
 }
else{
    $MaxPage = ceil($RecordCount / $PageSize);
 }

$num=mysql_num_rows($sql);

?>


<body>
	<TABLE cellSpacing=0 cellPadding=0 width=96% align=center border="0">
	
	<tr>
	<td>
	
	          <!--VIEW USERS -->
			  <? if($act=="view"){?>
	<form name="formx1" method="post" enctype="multipart/form-data">
	
<table width="100%">
	
	<tr>
		<td height="40" align="center" class="style13">&nbsp;<b class="greentext22bold">View Events </b></td>
	</tr>
	<? if($num<=0){?>
		<tr>
			<td height="40" colspan="2" align="center" class="style14">
			<?
				header("Location:events.php?act=new");
			?>
			</td>
		</tr>
	<? } else { ?>
					
					<tr class="txtblack3" >
					  <td height="10" align="right" class="normal" colspan="10" ><a href="events.php?act=new" class="greentextbold">Add Events </a></td>
	  </tr>
					<tr class="txtblack3" >
					  <td height="10" align="center" class="normal" colspan="10" ><span class="style14">
					    <?
					  if($error==1)
					  {
					  	echo "Category already exists";
					  }
					  ?>
					  </span></td>
	  </tr>
					<tr class="txtblack3" >
					<td height="10" align="right" class="normal" colspan="10" ><b ><strong><font color="#FF0000">Page: <? echo $PageNo." of ". $MaxPage  ?></font></strong></b></td>
				</tr>
	
	<tr>
		<td colspan="2">
			<table width=59% border="0" align=center cellPadding=0 cellSpacing=0 frame="box" style="border-style:solid; border-width:1px; border-color:#999999" >
				<tr class="txtblack3" bgcolor="#FA9032" >
				  <td width="75" align="center" class="style12"><input type="checkbox" name="selall" onClick="checkstate('chk[]')" ></td>
				  <td width="279" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><b> Event Name </b></div></td>
				  
				  <td width="279" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><b> Status  </b></div></td>
				  <td width="91" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Edit</b></td>
					<td width="91" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Delete</b></td>
			  </tr>
<? 
 while($row=mysql_fetch_array($sql))
{ 
	
?>
				<tr style="background-color:#FFFFFF" onMouseOver="javascript:MouseOverMenu(this);" onMouseOut="javascript:MouseOutMenu(this);">
						<td align="center" class="style12"><input type="hidden" name="chk1[]"  id="chk1" value="<?=$row['event_id']; ?>"> 
   					  <input type="checkbox" name="chk[]"  id="chk" value="<? echo $row['event_id']; ?>" onClick="checkval('chk[]')"></td>
				
				    <td height="28" class="normal style12"><div align="center">
					  <?=$row['event_name']?>
				    </div></td>
					 <td height="28" class="normal style12"><div align="center">
					 <? if($row['event_status']=='1'){
					 $st="Posted";}
					 else
					 {
					 $st="Not Posted";
					 }
					 ?><? echo $st;?>
				    </div></td>
					
					<td height="28" class="normal style12"><div align="center">
					  <a href="events.php?act=edit&aid=<?=$row['event_id']?>"><img src="images/edit_f2.png" width="18" height="18" border="0"></a>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					   <a href="javascript:delete1(<?=$row['event_id']?>)">
					   <img src="images/delete.png" width="18" height="18" border="0"></a>
				    </div></td>
			  </tr><?
					}
					?>
		  </table>	  </td>
		  </tr><tr><td>&nbsp;</td></tr>
					<tr>
					  <td align="center"><img src="images/delete1.gif" onClick="javascript:document.formx1.action='events.php?ok=alldel';document.formx1.submit();"></td>
	  </tr>
					<tr>
					  <td align="right" class="normal">
					  <?php
      	//Print First & Previous Link is necessary
        if($CounterStart != 1){
            $PrevStart = $CounterStart - 1;
            print "<a href=events.php?PageNo=1&act=view class=greenlink>First </a>: ";
            print "<a href=events.php?PageNo=$PrevStart&act=view class=greenlink>Previous </a>";
        }
        print " <font color='red'><b> [ </b></font>";
        $c = 0;

        //Print Page No
        for($c=$CounterStart;$c<=$CounterEnd;$c++){
            if($c < $MaxPage){
                if($c == $PageNo){
                    if($c % $PageSize == 0){
                        print "$c ";
                    }else{
                        print "$c , ";
                    }
                }elseif($c % $PageSize == 0){
                    echo "<a href=events.php?PageNo=$c&act=view class=greenlink>$c</a> ";
                }else{
                    echo "<a href=events.php?PageNo=$c&act=view class=greenlink>$c</a> , ";
                }//END IF


            }else{
                if($PageNo == $MaxPage){
                    print "$c ";
                    break;
                }else{
                    echo "<a href=events.php?PageNo=$c&act=view class=greenlink>$c</a> ";
                    break;
                }
            }
       }

      echo "<font color='red'><b> ]</b> </font> ";

      if($CounterEnd < $MaxPage){

          $NextPage = $CounterEnd + 1;
          echo "<a href=events.php?PageNo=$NextPage&act=view class=greenlink>Next</a>";
      }
      
      //Print Last link if necessary
      if($CounterEnd < $MaxPage){
       $LastRec = $RecordCount % $PageSize;
        if($LastRec == 0){
            $LastStartRecord = $RecordCount - $PageSize;
        }
        else{
            $LastStartRecord = $RecordCount - $LastRec;
        }

        print " : ";
        echo "<a href=events.php?PageNo=$MaxPage&act=view class=greenlink>Last</a>";
        }?></td>
	  </tr>
	
	</table></form>
	
	<?
		}}
	?>
	</td></tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr>
					  <td align="left">
					  
					  			<!--ADD and EDIT -->
					  <? 
				  		
					  if($act=='new' || $act=='edit') {
					   if($act == 'edit'){
					   
					 /*  Query to retrieve event information*/
					   
					$chn=mysql_query("select * from nile_events where event_id='$aid'");
					$row=getSqlFetch($chn);
					
					
					/* Query to retrieve event address information*/
					
					$chn2=mysql_query("select * from nile_event_address where event_id='$aid'");
					$row2=getSqlFetch($chn2);
					
					
					/*Query to retrieve event dates information*/
					
					$chn3=mysql_query("select * from nile_event_date where event_id='$aid'");
					$row3=getSqlFetch($chn3);
					
					
					
					
					
													
					}
					  ?>
					  <form name="formx1" method="post" enctype="multipart/form-data">
						<input type="hidden" name='idno' value="<?=$row['event_id']?>">
						<input type="hidden" name='oldname' value="<?=$row['event_name']?>">
					  <TABLE cellSpacing=0 cellPadding=0 width=100% align=center border="0">
                        <tr>
                          <td height="40" colspan="3" align="center" class="txtnolink">&nbsp;<b class="greentext22bold">
                            <?
							if($aid){
							?>
                            Edit Event Details
  <? }else {?>
                            Add Event Details
  <? }?>
                          </b></td>
                        </tr>
						<tr>
						<td colspan="3" align="center" class="style14">
						<?
						if($error==1)
						{
							echo "Category already Exists";
						}
						?>						</td>
						</tr>
                        <tr>
                          <td height="40" colspan="3" align="right" class="txtnolink"><a href="events.php?act=view" class="greentextbold"><b>View Events </b></a>&nbsp;</td>
                        </tr>
                        <TR>
                          <TD width="415" height="30" align="right" class="itemstyle">*Event Name</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="eventname" id="eventname" value="<?=$row['event_name']?>" size=25></TD>
                        </TR>
						
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">*Contact Phone</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="cname" id="cname" value="<?=$row['contactphone']?>" size=25></TD>
                        </TR>
						
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">*Introduction</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="sdesc" id="sdesc" value="<?=$row['event_shortdesc']?>" size=25></TD>
                        </TR>
						
						
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Website Link</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="url" id="url" value="<?=$row['url']?>" size=25></TD>
                        </TR>
						
						
						
                        <? if($act == 'edit'){?>
						<? }?>
                        <TR>
                          <TD height="30" align="right" class="itemstyle">Profile</TD>
                          <TD align="center">:</TD>
                          <TD><textarea name="desc" cols="25" rows="5" id="desc" style="width:173px"><?=$row['event_desc']?></textarea>                          </TD>
                        </TR>
						 <tr><td></td></tr>
						 <TR>
                          <TD height="30" align="right" class="itemstyle">Tags</TD>
                          <TD align="center">:</TD>
                          <TD><textarea name="tag" cols="25" rows="5" id="tag" style="width:173px"><?=nl2br($row['Tags'])?></textarea>                          </TD>
                        </TR>
						
						<? if($row['event_type']=='1'){
							$eventtype1="FeaturedLinks";
							}
							if($row['event_type']=='2'){
							$eventtype1="Nile Shopping";
							}
							if($row['event_type']=='3'){
							$eventtype1="Nile Info";
							}
															
						?>
					
					
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Main Category</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"> 
						  
						  			<select name="category1" onChange="scat12()">
						  
								  <option value="">Select Category</option>
									
								  <option value="1" <? if($eventtype1=="FeaturedLinks") {echo  "selected"; } ?> >FeaturedLinks</option>
								  <option value="2" <? if($eventtype1=="Nile Shopping") {echo  "selected"; } ?>>Nile Shopping</option>
								  <option value="3" <? if($eventtype1=="Nile Info") {echo  "selected"; } ?>>Nile Info</option>
								  
								  </select>
						  </TD>
                        </TR>
						
						<? 	/*Query to retrieve Categories information*/
					
					$cat_info=mysql_query("select * from nile_category where cat_id='".$row['event_cat']."'");
					$catinfo=mysql_fetch_array($cat_info);
					
					
					$cat_allinfo=mysql_query("select * from nile_category  where cat_type='".$row['event_type']."'");
			
					
					?>
					
					
					<? 	/*Query to retrieve Sub-Categories information*/
					
					$subcat_info=mysql_query("select * from nile_items  where cat_id='".$row['event_cat']."'");
					$subcatinfo=mysql_fetch_array($subcat_info);
					
					
					$subcat_infoall=mysql_query("select * from nile_items where cat_id='".$catinfo['cat_id']."'");
					
					
					?>
					
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Category</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"> <select name="category" onChange="scatite();">
						  
						  		<? if($catinfo['cat_name']<>''){?>
								 <option value="<?=$catinfo['cat_id'];?>"><?=$catinfo['cat_name'];?></option><? }
								 else { ?>
								  <option value="">Select Category</option>
									<? } ?>
								  <? while ($catnames=mysql_fetch_array($cat_allinfo)){?>
								  	<? if($catnames['cat_name']<>$catinfo['cat_name']){?>
								   <option value="<?=$catnames['cat_id'];?>"><?=$catnames['cat_name'];?></option>
								   <? }}?>
								  
								  </select>
								  
						  </TD>
                        </TR>
						
						 <TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Sub-category</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"> <select name="subcat_id" onChange="scat1();">
						  
						  		<? if($subcatinfo['item_name']<>''){?>
								 <option value="<?=$subcatinfo['item_name'];?>"><?=$subcatinfo['item_name'];?></option><? }
								 else { ?>
								  <option value="">Select Category</option>
									<? } ?>
								 <? while ($subcatnames=mysql_fetch_array($subcat_infoall)){
								 if($subcatinfo['item_name']<>$subcatnames['item_name']){?>
								 <option value="<?=$subcatnames['item_id'];?>"><?=$subcatnames['item_name'];?></option>
								   <? }}?>
								  </select>
						   </TD>
                        </TR>
						
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">* Image</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="picture" id="picture"  type="file" size=25></TD>
                        </TR>
						
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Venue Name</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="venuename" id="venuename" value="<?=$row2['venue_name'];?>" size=25></TD>
                        </TR>
						
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Address</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="address" id="address" value="<?=$row2['venue_address']?>" size=25></TD>
                        </TR>
						
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">City</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="city" id="city" value="<?=$row2['venue_city']?>" size=25></TD>
                        </TR>
						
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Venue Type</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"> <select name="type">
						 		 <? if($row2['venue_type']<>''){?>
								 <option value="<?=$row2['$venue_type'];?>"><?=$row2['venue_type'];?></option><? }else{ ?>
								 <option value="">Select</option><? } ?>
								  <option value="Hotel">Hotel</option>
								  <option value="Art Venue">Art Venue</option>
								  <option value="Restaurant">Restaurant </option>
								   <option value="Bar or Club">Bar or Club </option>
								  	
								  </select></TD>
                        </TR>
						 
						 <TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Phone</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="vphone" id="vphone" value="<?=$row2['phone']?>" size=25></TD>
                        </TR>
						
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Admission & Price</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472" class="normal"> <input type="radio" name="paymentcat" value="Donation" <? if ($row['payment_type']=="Donation"){ echo"checked";} ?>>Donation<input type="radio" name="paymentcat" value="free" <? if ($row['payment_type']=="free"){ echo"checked";} ?> checked>free 					  <input type="radio" name="paymentcat" value="payment" <? if ($row['payment_type']=="payment"){ echo"checked";} ?>>payment <input type="radio" name="paymentcat" value="TBA" <? if ($row['payment_type']=="TBA"){ echo"checked";} ?>>TBA</TD>
                        </TR>
						 
						 <TR>
                          <TD width="415" height="30" align="right" class="itemstyle">PriceSummary</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="price" class="body-txt" type="text" size="30" value="<?=$row['price_summary']?>"/></TD>
                        </TR>
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Buy Tickets Link</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="ticketlink" class="body-txt" type="text" value="<?=$row['ticket_link']?>"   size="30"/></TD>
                        </TR>
						
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Public Phone</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="pphone" class="body-txt" type="text"  size="30" value="<?=$row[' ticket_phone'];?>"/ ></TD>
                        </TR>
						 <tr><td>&nbsp;</td></tr>
						 <? $audien=explode(",",$row['audience']);?>
						 <TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Audience</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472" class="normal" >
                            <input type="checkbox"  name="audience[]" value="Kids" <? if(in_array("Kids",$audien)){echo "checked";}?>>
                            Kids &nbsp;&nbsp;&nbsp;&nbsp;
                            <input type="checkbox" name="audience[]" value="Teens" <? if(in_array("Teens",$audien)){echo "checked";}?>>
                            Teens&nbsp; 		
                            <input type="checkbox" name="audience[]" value="Family" <? if(in_array("Family",$audien)){echo "checked";}?>>
                            Family&nbsp;&nbsp;&nbsp;&nbsp;                            
                            <p>
                              <input type="checkbox" name="audience[]" value="Adults" <? if(in_array("Adults",$audien)){echo "checked";}?>>
                              Adults 
                              &nbsp;
                              <input type="checkbox" name="audience[]" value="Singles" <? if(in_array("Singles",$audien)){echo "checked";}?>>
                              Singles   
                              <input type="checkbox" name="audience[]" value="All Ages" <? if(in_array("All Ages",$audien)){echo "checked";}?>>
                            All Ages </p>
                            <p>
                              <input type="checkbox" name="audience[]" value="18+" <? if(in_array("18+",$audien)){echo "checked";}?>>
                              18+	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
                               <input type="checkbox" name="audience[]" value="19+" <? if(in_array("19+",$audien)){echo "checked";}?>>
                           19+ </p></TD>
								  
								  
                        </TR>
						<?  
						
						list($year,$month,$date)=split('[-]',$row['event_fromdate']);
						list($year1,$month1,$date1)=split('[-]',$row['event_todate']);
						
						?>
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Start Date</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472">
						  
						  <input name="startdate" class="body-txt" type="text" id="f_date_f" size="30" <? if($act=="edit"){?>value="<?=$month."/",$date."/".$year;  } ?>"/>&nbsp;<img src="images/calendar.gif" id="f_trigger_f" style="cursor: pointer; "
      onmouseover="this.style.background='red';" onMouseOut="this.style.background=''" border=0 />
	  
	  </TD>
                        </TR>
						
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">End Date</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input name="enddate" class="body-txt" type="text" id="f_date_g" size="30" <? if($act=="edit"){?> value="<?=$month1."/",$date1."/".$year1; }?>"/>&nbsp;<img src="images/calendar.gif" id="f_trigger_g" style="cursor: pointer; "
      onmouseover="this.style.background='red';" onMouseOut="this.style.background=''" border=0  /></TD>
                        </TR>
						
						<? $event_fromtime=explode(":",$row3['event_fromtime']);
							$event_totime=explode(":",$row3['event_totime']);
						
						
						
						?>
						 <TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Start Time</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><select name="timefrom">
						 	<?  if($event_fromtime[0]<>'')
						  {?>
						  		<option value="<?=$event_fromtime[0];?>"><?=$event_fromtime[0];?></option>
								<? }else{ ?>
								  <option value="">Select</option><? } ?>
								  <option value="01">01</option>
									<option value="02">02</option>
									<option value="03">03</option>
									<option value="04">04</option>
									<option value="05">05</option>
									<option value="06">06</option>
									<option value="07">07</option>
									<option value="08">08</option>
									<option value="09">09</option>
									<option value="10">10</option>
									<option value="11">11</option>
									<option value="12">12</option>
								  </select>
								  <select name="timefrom1">
								  <?  if($event_fromtime[1]<>'')
						  {?>
								  <option value="<?=$event_fromtime[1];?>"><?=$event_fromtime[1];?></option>
								 <? }else{ ?>
								  <option value="">Select</option><? } ?>
								
								<option value="05">05</option>
								<option value="10">10</option>
								<option value="15">15</option>
								<option value="20">20</option>
								<option value="25">25</option>
								<option value="30">30</option>
								<option value="35">35</option>
								<option value="40">40</option>
								<option value="45">45</option>
								<option value="50">50</option>
								<option value="55">55</option>
								  </select>
								  <select name="medfrom">
								  <option value="AM" <? if ($event_fromtime[2]=="AM"){ echo "selected";}?>>AM</option>
								   <option value="PM" <? if ($event_fromtime[2]=="PM"){ echo "selected";}?>>PM</option>
						    </select>
						   </TD>
                        </TR>
						
						<TR>
                          <TD width="415" height="30" align="right" class="itemstyle">End Time</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><select name="timeto">
								   <?  if($event_totime[0]<>'')
						  {?>
								  <option value="<?=$event_totime[0];?>"><?=$event_totime[0];?></option>
								 <? }else{ ?>
								  <option value="">Select</option><? } ?>
								  <option value="01">01</option>
									<option value="02">02</option>
									<option value="03">03</option>
									<option value="04">04</option>
									<option value="05">05</option>
									<option value="06">06</option>
									<option value="07">07</option>
									<option value="08">08</option>
									<option value="09">09</option>
									<option value="10">10</option>
									<option value="11">11</option>
									<option value="12">12</option>
								  </select>
								  <select name="timeto1">
								  <?  if($event_totime[1]<>'')
						  {?>
								  <option value="<?=$event_totime[1];?>"><?=$event_totime[1];?></option>
								 <? }else{ ?>
								  <option value="">Select</option><? } ?>
								<option value="05">05</option>
								<option value="10">10</option>
								<option value="15">15</option>
								<option value="20">20</option>
								<option value="25">25</option>
								<option value="30">30</option>
								<option value="35">35</option>
								<option value="40">40</option>
								<option value="45">45</option>
								<option value="50">50</option>
								<option value="55">55</option>
								  </select>
								  <select name="medto">
								  <option value="AM" <? if ($event_totime[2]=="AM"){ echo "selected";}?>>AM</option>
								   <option value="PM" <? if ($event_totime[2]=="PM"){ echo "selected";}?>>PM</option>
						    </select>
						  </TD>
                        </TR>
						
						<!--<TR>
                          <TD width="415" height="30" align="right" class="itemstyle"> Day of the week that the event occurs</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472">&nbsp;</TD>
                        </TR>-->
						 
                        <TR>
                          <TD height="30" align="right" class="itemstyle">Post to site</TD>
                          <TD align="center">:</TD>
                          <td align="left" class="normal"><input name="status" type="radio" value="1" checked />
                            Yes
                            <input name="status" type="radio" value="0" <? if( isset($event_status) && $event_status == 0 ){ echo "checked";}?>>
                            No</td>
                        </TR>
						
					<TR>
                          <TD width="415" height="30" align="right" class="itemstyle"> Featured Event</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><input type="checkbox" name="featured" value="1" <? if($row['event_featured']=='1'){ echo "checked";}?>></TD>
                        </TR>
						
                        <TR>
                          <TD height="60" colspan="3" align="center"><?
			if($aid){
			?>
                              <img src="images/update.gif" onClick="return events1();"><!--<input name="submit" type="submit" class="normal" onClick="javascript:return category1();" value='Update'>-->
                              <?
		} else {
		?>
               <img src="images/addcategory.gif" onClick="javascript:return events2();"> <!--<input name="submit" type="submit" class="normal" onClick="javascript:return category();" value='Add Categories'>-->
                            <? }?>
                            &nbsp;
                            <img src="images/cancel.gif" onClick="javascript:document.formx1.action='events.php?act=view';document.formx1.submit();"><!--<input name="submit1" type="submit" class="normal" onClick="javascript:document.formx1.action='events.php?act=view';document.formx1.submit();" value="Cancel">-->                          </TD>
                        </TR>
                        <TR>
                          <TD height="50" colspan="3">&nbsp;</TD>
                        </TR>
                      </TABLE>
					  <?
					  }
					  ?>
					  </form>
					<?  if($act=='new' || $act=='edit') {  ?>
					 <!-- END ADD AND EDIT -->
					 <script type="text/javascript">
    Calendar.setup({
        inputField     :    "f_date_f",     // id of the input field
        ifFormat       :    "%m/%d/%Y",      // format of the input field
        button         :    "f_trigger_f",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true
    })
	Calendar.setup({
        inputField     :    "f_date_g",     // id of the input field
        ifFormat       :    "%m/%d/%Y",      // format of the input field
        button         :    "f_trigger_g",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true
    });
</script>	
			<? } ?>		<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr><td align="center">&nbsp;</td>
					</tr>
					
					</TABLE>

					</body>
					</html>
			