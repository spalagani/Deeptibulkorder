<?
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
extract($_REQUEST);
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='validation.js'></script>

<script type="text/javascript">
//var _editor_url  = document.location.href.replace(/examples\/simple_example\.html.*/, '')
// And the language we need to use in the editor.
var _editor_lang = "en";
//var _editor_url  = document.location.href.replace(/xinha\/xinha\*/, '')
var _editor_url = "../../auction/admin/xinha/";
</script>
<!-- Load up the actual editor core -->
<script type="text/javascript" src="xinha/htmlarea.js"></script>
<script type="text/javascript">
/*var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'SpellChecker', 'Stylist', 'SuperClean', 'TableOperations', 'ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText', 'InsertSmiley', 'InsertAnchor', 'HorizontalRule', 'GetHtml', 'FullScreen', 'BackgroundImage','InsertWords','ListType'
 ];*/
 var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'Stylist', 'SuperClean','TableOperations','ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText',  'InsertAnchor','HtmlEntities','FullPage','ContextMenu'
];
/************************************************************************
 * Names of the textareas you will be turning into editors
 ************************************************************************/
var xinha_editors =
[
   'cat_desc1'
];
/************************************************************************
 * Initialisation function
 ************************************************************************/
function xinha_init()
{
  // THIS BIT OF JAVASCRIPT LOADS THE PLUGINS, NO TOUCHING  :)
  //var _editor_url  = document.location.href.replace(/xinha\*/, '');
 // alert(_editor_url);
  if(!HTMLArea.loadPlugins(xinha_plugins, xinha_init)) return;
  var xinha_config = new HTMLArea.Config();
    xinha_editors = HTMLArea.makeEditors(xinha_editors, xinha_config, xinha_plugins);
   //xinha_editors.cat_smdesc.config.width = '600px';
  // xinha_editors.cat_smdesc.config.height = '400px';
   xinha_editors.cat_desc.config.width = '500px';
   xinha_editors.cat_desc.config.height = '300px';
   //xinha_editors.cat_smdesc.config.statusBar = false;
   xinha_editors.cat_desc.config.statusBar = false;
   HTMLArea.startEditors(xinha_editors);
}
window.onload = xinha_init;
</script>
<script language="javascript">
function open_window(img_name)
{
	url = "../images/categories/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function open_window1(img_name)
{
	url = "../images/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function delete1(uid){
	if(confirm("Are you sure want to delete?")){
		document.location.href = 'quotes.php?del=1&uid='+uid;
	}
}
</script>
<link type="text/css" rel="stylesheet" title="xp-green" href="xinha/skins/xp-green/skin.css">
</head>
<?
///////////////////////////////single delete/////////////////////////////////
	$del=$_REQUEST['del'];
	$uid=$_REQUEST['uid'];
	if($del==1)
	{
			
			//delete_directory("../images/categories/".$name."/");

			$delete2=mysql_query("delete from nile_quotes where quote_id='$uid'");
			header("location:quotes.php?act=view");
			exit;
			
	}
///////////////////////////////////////multiple delete///////////////////////////
	$ok=$_REQUEST[ok];
	$colors=$_REQUEST['chk'];
	$chk1=$_REQUEST['chk1'];
	$number=count($colors);
	if($ok=='alldel')
	{
		foreach($colors as $chk1)
		{
			
			$delete2=mysql_query("delete from nile_quotes where quote_id='$chk1'");
		}
		header("location:quotes.php?act=view");
		exit;	
			
	}
//////////////////////////////end of multiple delete///////////////////////////////////	
$ok=$_REQUEST[ok];
//echo $ok;exit;
//////////////////////////////////////ADD////////////////////////////////////////////
if($ok==add)
{
	//echo "SELECT * FROM auc_categories WHERE listing_id='$listing_id' and name='$name'";exit;
	$selCat = mysql_query("SELECT * FROM nile_quotes WHERE quote='$quote'");
	//echo "SELECT * FROM nile_quotes WHERE cat_name='$catname'";exit;
	$num=mysql_num_rows($selCat);
	if($num<=0)
	{
		$sql=mysql_query("insert into nile_quotes (quote,date_added,status,cat_id) values('$quote',now(),1,'$category')");
		
		/*echo "insert into nile_quotes (cat_name,cat_description,cat_metakeyword,cat_metadesc,status,date_added) values('$catname','$cat_desc','$cat_metakeyword','$cat_metadesc','$status',now())";exit;*/
		header("location:quotes.php?act=view");
		exit;
	}
	else
	{
		header("location:quotes.php?act=new&error=1");
		exit;
	}
	
}
//////////////////////////////////////update////////////////////////////////////////////
if($ok==edit)
{	
extract($_REQUEST);
	
		
		$sql=mysql_query("select * from nile_quotes where quote='$quote' && quote_id != $idno");
		$row=mysql_fetch_array($sql);
		$cc=mysql_num_rows($sql);
		if($cc<=0){	
        //echo "update nile_quotes set quote='$quote',status='$status' where quote_id='$idno'";exit;
		$updsub=mysql_query("update nile_quotes set quote='$quote',status='$status',cat_id='$category' where quote_id='$idno'");
		header("location:quotes.php?act=view");
		exit;
		}
		else
		{
			header("location:quotes.php?act=view&error=1");
			exit;
		}
}
///////////////////paging////////////////////
$PageSize = 20;
$StartRow = 0;
if(empty($_GET['PageNo'])){
    if($StartRow == 0){
        $PageNo = $StartRow + 1;
    }
}else{
    $PageNo = $_GET['PageNo'];
    $StartRow = ($PageNo - 1) * $PageSize;
}

if($PageNo % $PageSize == 0){
    $CounterStart = $PageNo - ($PageSize - 1);
}else{
    $CounterStart = $PageNo - ($PageNo % $PageSize) + 1;
}
//Counter End
$CounterEnd = $CounterStart + ($PageSize - 1);
//////////////////end //////////////////////////////

	
	$TRecord=mysql_query("select * from nile_quotes");
	$sql=mysql_query("select * from nile_quotes  LIMIT ". $StartRow .",". $PageSize."");


$RecordCount = mysql_num_rows($TRecord);
$MaxPage = $RecordCount % $PageSize;
if($RecordCount % $PageSize == 0){
    $MaxPage = $RecordCount / $PageSize;
 }
else{
    $MaxPage = ceil($RecordCount / $PageSize);
 }

$num=mysql_num_rows($sql);

?>


<body>
	<TABLE cellSpacing=0 cellPadding=0 width=96% align=center border="0">
	
	<tr>
	<td>
	
	          <!--VIEW USERS -->
			  <? if($act=="view"){?>
	<form name="formx1" method="post" enctype="multipart/form-data">
	
<table width="100%">
	
	<tr>
		<td height="40" align="center" class="style13">&nbsp;<b class="greentext22bold">View Quotes </b></td>
	</tr>
	<? if($num<=0){?>
		<tr>
			<td height="40" colspan="2" align="center" class="style14">
			<?
				header("Location:quotes.php?act=new");
			?>
			</td>
		</tr>
	<? } else { ?>
					
					<tr class="txtblack3" >
					  <td height="10" align="right" class="normal" colspan="10" ><a href="quotes.php?act=new" class="greentextbold">Add Quotes </a></td>
	  </tr>
					<tr class="txtblack3" >
					  <td height="10" align="center" class="normal" colspan="10" ><span class="style14">
					    <?
					  if($error==1)
					  {
					  	echo "Quote already exists";
					  }
					  ?>
					  </span></td>
	  </tr>
					<tr class="txtblack3" >
					<td height="10" align="right" class="normal" colspan="10" ><b ><strong><font color="#FF0000">Page: <? echo $PageNo." of ". $MaxPage  ?></font></strong></b></td>
				</tr>
	
	<tr>
		<td colspan="2">
			<table width=59% border="0" align=center cellPadding=0 cellSpacing=0 frame="box" style="border-style:solid; border-width:1px; border-color:#999999" >
				<tr class="txtblack3" bgcolor="#FA9032" >
				  <td width="75" align="center" class="style12"><input type="checkbox" name="selall" onClick="checkstate('chk[]')" ></td>
				  <td width="279" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle">Quote</div></td>
				  <td width="91" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Edit</b></td>
					<td width="91" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Delete</b></td>
			  </tr>
<? 
 while($row=mysql_fetch_array($sql))
{ 
	
?>
				<tr style="background-color:#FFFFFF" onMouseOver="javascript:MouseOverMenu(this);" onMouseOut="javascript:MouseOutMenu(this);">
						<td align="center" class="style12"><input type="hidden" name="chk1[]"  id="chk1" value="<?=$row['quote_id']; ?>"> 
   					  <input type="checkbox" name="chk[]"  id="chk" value="<? echo $row['quote_id']; ?>" onClick="checkval('chk[]')"></td>
				
				    <td height="28" class="normal style12"><div align="center">
					  <?=$row['quote']?>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					  <a href="quotes.php?act=edit&aid=<?=$row['quote_id']?>"><img src="images/edit_f2.png" width="18" height="18" border="0"></a>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					   <a href="javascript:delete1(<?=$row['quote_id']?>)">
					   <img src="images/delete.png" width="18" height="18" border="0"></a>
				    </div></td>
			  </tr><?
					}
					?>
		  </table>	  </td>
		  </tr><tr><td>&nbsp;</td></tr>
					<tr>
					  <td align="center"><img src="images/delete1.gif" onClick="javascript:document.formx1.action='quotes.php?ok=alldel';document.formx1.submit();"></td>
	  </tr>
					<tr>
					  <td align="right" class="normal">
					  <?php
      	//Print First & Previous Link is necessary
        if($CounterStart != 1){
            $PrevStart = $CounterStart - 1;
            print "<a href=quotes.php?PageNo=1&act=view class=greenlink>First </a>: ";
            print "<a href=quotes.php?PageNo=$PrevStart&act=view class=greenlink>Previous </a>";
        }
        print " <font color='red'><b> [ </b></font>";
        $c = 0;

        //Print Page No
        for($c=$CounterStart;$c<=$CounterEnd;$c++){
            if($c < $MaxPage){
                if($c == $PageNo){
                    if($c % $PageSize == 0){
                        print "$c ";
                    }else{
                        print "$c , ";
                    }
                }elseif($c % $PageSize == 0){
                    echo "<a href=quotes.php?PageNo=$c&act=view class=greenlink>$c</a> ";
                }else{
                    echo "<a href=quotes.php?PageNo=$c&act=view class=greenlink>$c</a> , ";
                }//END IF


            }else{
                if($PageNo == $MaxPage){
                    print "$c ";
                    break;
                }else{
                    echo "<a href=quotes.php?PageNo=$c&act=view class=greenlink>$c</a> ";
                    break;
                }
            }
       }

      echo "<font color='red'><b> ]</b> </font> ";

      if($CounterEnd < $MaxPage){

          $NextPage = $CounterEnd + 1;
          echo "<a href=quotes.php?PageNo=$NextPage&act=view class=greenlink>Next</a>";
      }
      
      //Print Last link if necessary
      if($CounterEnd < $MaxPage){
       $LastRec = $RecordCount % $PageSize;
        if($LastRec == 0){
            $LastStartRecord = $RecordCount - $PageSize;
        }
        else{
            $LastStartRecord = $RecordCount - $LastRec;
        }

        print " : ";
        echo "<a href=quotes.php?PageNo=$MaxPage&act=view class=greenlink>Last</a>";
        }?></td>
	  </tr>
	
	</table></form>
	
	<?
		}}
	?>
	</td></tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr>
					  <td align="left">
					  
					  			<!--ADD and EDIT -->
					  <? 
				  		
					  if($act=='new' || $act=='edit') {
					   if($act == 'edit'){
					$chn=mysql_query("select * from nile_quotes where quote_id='$aid'");
					$row=getSqlFetch($chn);
					extract($row);
					}
					  ?>
					  <form name="formx1" method="post" enctype="multipart/form-data">
						<input type="hidden" name='idno' value="<?=$quote_id?>">
						<input type="hidden" name='oldname' value="<?=$cat_name?>">
					  <TABLE cellSpacing=0 cellPadding=0 width=100% align=center border="0">
                        <tr>
                          <td height="40" colspan="3" align="center" class="txtnolink">&nbsp;<b class="greentext22bold">
                            <?
							if($aid){
							?>
                            Edit Quote
  <? }else {?>
                            Add Quote
  <? }?>
                          </b></td>
                        </tr>
						<tr>
						<td colspan="3" align="center" class="style14">
						<?
						if($error==1)
						{
							echo "Quote already Exists";
						}
						?>						</td>
						</tr>
                        <tr>
                          <td height="40" colspan="3" align="right" class="txtnolink"><a href="quotes.php?act=view" class="greentextbold"><b>View Quotes </b></a>&nbsp;</td>
                        </tr>
                       
                        <TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Quote Name</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472"><?php /*?><textarea name="quote" cols="25" rows="5" id="cat_desc" style="width:173px"><?=stripslashes($cat_description)?></textarea><?php */?> <input type="text" name="quote" value="<? if($aid) { echo $quote; } ?>"></TD>
                        </TR>
						<?php
							$selq=mysql_query("select * from nile_quotes where quote_id='$aid'");
							$retq=mysql_fetch_array($selq);
						?>
						<?php
							$selcat=mysql_query("select * from nile_category");
						?>
						 <TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Select Category</TD>
                          <TD width="33" align="center">:</TD>	
                          <TD width="472"><select name="category">
						  				<option value="0">Select any Category</option>
										<? while($retcat=mysql_fetch_array($selcat)) { ?>
										<option value="<?=$retcat['cat_id']?>" <? if($retq['cat_id']==$retcat['cat_id']) { ?> selected="selected"<? } ?>>
										<?= $retcat['cat_name']?>
										</option>
										<? } ?>
						  				</select>
						 </TD>
                        </TR>
                        <TR>
                          <TD height="30" align="right" class="itemstyle">Status</TD>
                          <TD align="center">:</TD>
                          <td align="left" class="normal"><input name="status" type="radio" value="1" checked />
                            Yes
                            <input name="status" type="radio" value="0" <? if( isset($status) && $status == 0 ){ echo "checked";}?>>
                            No</td>
                        </TR>
                        <TR>
                          <TD height="60" colspan="3" align="center"><?
			if($aid){
			?>
                              <img src="images/update.gif" onClick="javascript:return quotes1();"><!--<input name="submit" type="submit" class="normal" onClick="javascript:return category1();" value='Update'>-->
                              <?
		} else {
		?>
               <img src="images/addcategory.gif" onClick="javascript:return quotes();"> <!--<input name="submit" type="submit" class="normal" onClick="javascript:return category();" value='Add Categories'>-->
                            <? }?>
                            &nbsp;
                            <img src="images/cancel.gif" onClick="javascript:document.formx1.action='quotes.php?act=view';document.formx1.submit();"><!--<input name="submit1" type="submit" class="normal" onClick="javascript:document.formx1.action='quotes.php?act=view';document.formx1.submit();" value="Cancel">-->                          </TD>
                        </TR>
                        <TR>
                          <TD height="50" colspan="3">&nbsp;</TD>
                        </TR>
                      </TABLE>
					  <?
					  }
					  ?>
					  </form>
					 <!-- END ADD AND EDIT -->
					  
					  </td>
	  </tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr><td align="center">&nbsp;</td>
					</tr>
					
					</TABLE>

					</body>
					</html>
			