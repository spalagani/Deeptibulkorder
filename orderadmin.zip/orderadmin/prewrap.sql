-- phpMyAdmin SQL Dump
-- version 2.8.2.4
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Mar 13, 2006 at 10:49 AM
-- Server version: 5.0.24
-- PHP Version: 5.1.6
-- 
-- Database: 'prewrap'
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table 'admin_user'
-- 

DROP TABLE IF EXISTS admin_user;
CREATE TABLE admin_user (
  auto_id int(11) NOT NULL auto_increment,
  fname varchar(65) NOT NULL,
  lname varchar(60) NOT NULL,
  username varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  date_added date NOT NULL,
  `status` int(3) NOT NULL,
  PRIMARY KEY  (auto_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table 'admin_user'
-- 

INSERT INTO admin_user VALUES (1, 'raju', 's', 'admin', 'admin', '0000-00-00', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table 'pre_categories'
-- 

DROP TABLE IF EXISTS pre_categories;
CREATE TABLE pre_categories (
  auto_id int(11) NOT NULL auto_increment,
  catname varchar(60) NOT NULL,
  cat_smdesc varchar(255) NOT NULL,
  cat_desc text NOT NULL,
  image varchar(255) NOT NULL,
  date_added date NOT NULL,
  last_modified date NOT NULL,
  `status` int(3) NOT NULL,
  PRIMARY KEY  (auto_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table 'pre_categories'
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table 'pre_news'
-- 

DROP TABLE IF EXISTS pre_news;
CREATE TABLE pre_news (
  auto_id int(11) NOT NULL auto_increment,
  news_title varchar(50) NOT NULL default '',
  news_desc text NOT NULL,
  date_added date NOT NULL default '0000-00-00',
  last_modified date NOT NULL default '0000-00-00',
  news_status int(2) NOT NULL default '0',
  PRIMARY KEY  (auto_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table 'pre_news'
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table 'pre_news_users'
-- 

DROP TABLE IF EXISTS pre_news_users;
CREATE TABLE pre_news_users (
  auto_id int(11) NOT NULL auto_increment,
  email varchar(255) NOT NULL default '',
  date_added date NOT NULL default '0000-00-00',
  last_modified date NOT NULL,
  `status` int(11) NOT NULL default '0',
  PRIMARY KEY  (auto_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table 'pre_news_users'
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table 'pre_products'
-- 

DROP TABLE IF EXISTS pre_products;
CREATE TABLE pre_products (
  auto_id int(11) NOT NULL auto_increment,
  cat_id int(11) NOT NULL,
  subcat_id int(11) NOT NULL,
  prod_title varchar(255) NOT NULL,
  prod_name varchar(60) NOT NULL,
  prod_smdesc varchar(255) NOT NULL,
  price float(10,2) NOT NULL,
  image varchar(255) NOT NULL,
  topten int(3) NOT NULL,
  date_added date NOT NULL,
  last_modified date NOT NULL,
  `status` int(3) NOT NULL,
  PRIMARY KEY  (auto_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table 'pre_products'
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table 'pre_subcategories'
-- 

DROP TABLE IF EXISTS pre_subcategories;
CREATE TABLE pre_subcategories (
  auto_id int(11) NOT NULL auto_increment,
  cat_id int(11) NOT NULL,
  catname varchar(60) NOT NULL,
  subcat_name varchar(60) NOT NULL,
  subcat_smdesc varchar(255) NOT NULL,
  subcat_desc text NOT NULL,
  image varchar(255) NOT NULL,
  date_added date NOT NULL,
  last_modified date NOT NULL,
  `status` int(3) NOT NULL,
  PRIMARY KEY  (auto_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table 'pre_subcategories'
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table 'pre_users'
-- 

DROP TABLE IF EXISTS pre_users;
CREATE TABLE pre_users (
  auto_id int(11) NOT NULL auto_increment,
  fname varchar(60) NOT NULL,
  lname varchar(60) NOT NULL,
  email varchar(60) NOT NULL,
  company varchar(60) NOT NULL,
  address varchar(60) NOT NULL,
  pincode int(11) NOT NULL,
  city varchar(60) NOT NULL,
  state varchar(66) NOT NULL,
  country varchar(66) NOT NULL,
  phone bigint(20) NOT NULL,
  `password` varchar(60) NOT NULL,
  date_added date NOT NULL,
  last_modified date NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY  (auto_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table 'pre_users'
-- 

