﻿/*
 * FCKeditor - The text editor for internet
 * Copyright (C) 2003-2006 Frederico Caldeira Knabben
 * 
 * Licensed under the terms of the GNU Lesser General Public License:
 * 		http://www.opensource.org/licenses/lgpl-license.php
 * 
 * For further information visit:
 * 		http://www.fckeditor.net/
 * 
 * "Support Open Source software. What about a donation today?"
 * 
 * File Name: pl.js
 * 	Placholder Polish language file.
 * 
 * File Authors:
 * 		Marcin Pietrzak (fck@iworks.pl)
 */
FCKLang.PlaceholderBtn			= 'Wstaw/Edytuj nagłówek' ;
FCKLang.PlaceholderDlgTitle		= 'Właśności nagłówka' ;
FCKLang.PlaceholderDlgName		= 'Nazwa nagłówka' ;
FCKLang.PlaceholderErrNoName	= 'Proszę wprowadzić nazwę nagłówka' ;
FCKLang.PlaceholderErrNameInUse	= 'Podana nazwa jest już w użyciu' ;