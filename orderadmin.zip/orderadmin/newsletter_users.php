<?php 
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
include "../includes/class.phpmailer.php";
$new_array=array("Lecture","Teachers","Corresponding","Students");
extract($_REQUEST);
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='validation.js'></script>

<script type="text/javascript">
//var _editor_url  = document.location.href.replace(/examples\/simple_example\.html.*/, '')
// And the language we need to use in the editor.
var _editor_lang = "en";
//var _editor_url  = document.location.href.replace(/xinha\/xinha\*/, '')
var _editor_url = "../../cybermix/admin/xinha/";
</script>
<!-- Load up the actual editor core -->
<script type="text/javascript" src="xinha/htmlarea.js"></script>
<script type="text/javascript">
/*var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'SpellChecker', 'Stylist', 'SuperClean', 'TableOperations', 'ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText', 'InsertSmiley', 'InsertAnchor', 'HorizontalRule', 'GetHtml', 'FullScreen', 'BackgroundImage','InsertWords','ListType'
 ];*/
 var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'Stylist', 'SuperClean','TableOperations','ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText',  'InsertAnchor','HtmlEntities','FullPage','ContextMenu'
];
/************************************************************************
 * Names of the textareas you will be turning into editors
 ************************************************************************/
var xinha_editors =
[
   'cat_desc1'
];
/************************************************************************
 * Initialisation function
 ************************************************************************/
function xinha_init()
{
  // THIS BIT OF JAVASCRIPT LOADS THE PLUGINS, NO TOUCHING  :)
  //var _editor_url  = document.location.href.replace(/xinha\*/, '');
 // alert(_editor_url);
  if(!HTMLArea.loadPlugins(xinha_plugins, xinha_init)) return;
  var xinha_config = new HTMLArea.Config();
    xinha_editors = HTMLArea.makeEditors(xinha_editors, xinha_config, xinha_plugins);
   //xinha_editors.cat_smdesc.config.width = '600px';
  // xinha_editors.cat_smdesc.config.height = '400px';
   xinha_editors.cat_desc.config.width = '500px';
   xinha_editors.cat_desc.config.height = '300px';
   //xinha_editors.cat_smdesc.config.statusBar = false;
   xinha_editors.cat_desc.config.statusBar = false;
   HTMLArea.startEditors(xinha_editors);
}
window.onload = xinha_init;
</script>
<script language="javascript">
function open_window(cat,img_name)
{
	url = "../images/news/"+cat+"/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function open_window1(img_name)
{
	url = "../images/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function delete1(uid){
	if(confirm("Are you sure want to delete?")){
		document.location.href = 'newsletter_users.php?del=1&uid='+uid;
	}
}
</script>
<link type="text/css" rel="stylesheet" title="xp-green" href="xinha/skins/xp-green/skin.css">
</head>
<?php 
///////////////////////////////single delete/////////////////////////////////
	$del=$_REQUEST['del'];
	$uid=$_REQUEST['uid'];
	if($del==1)
	{
			
			
			$delete2=mysql_query("delete from nile_news_users where news_users_id='$uid'");
			header("location:newsletter_users.php?act=view");
			exit;
			
	}
///////////////////////////////////////multiple delete///////////////////////////
	$ok=$_REQUEST[ok];
	$colors=$_REQUEST['chk'];
	$chk1=$_REQUEST['chk1'];
	$number=count($colors);
	if($ok=='alldel')
	{
		foreach($colors as $chk1)
		{
			
			$delete2=mysql_query("delete from nile_news_users where news_users_id='$chk1'");
			
		}
		header("location:newsletter_users.php?act=view");
		exit;	
			
	}
		

//////////////////////////////end of multiple delete///////////////////////////////////	


//////////////////////////////////////ADD////////////////////////////////////////////
$ok=$_REQUEST[ok];
if($ok==add)
{
	$selCat = mysql_query("SELECT * FROM nile_news_users WHERE email='$email'");
	$num=mysql_num_rows($selCat);
	if($num<=0)
	{
	
			
	foreach($comm as $value)
		{ 
		$subscribe_type.=$value.",";
				}
				
				$subscribe_type=substr($subscribe_type,0,-1);
				
				
		
		$sql=mysql_query("insert into nile_news_users (name,userid,email,date_added,last_modified,subscribedby,status,subscribed_for) values('',0,'$email',now(),now(),'admin','$status','$subscribe_type')");
		header("location:newsletter_users.php?act=view");
		exit;
	}
	else
	{
		header("location:newsletter_users.php?act=view&error=1");
		exit;
	}
	
}
//////////////////////////////////////update////////////////////////////////////////////
if($ok==edit)
{	
extract($_REQUEST);
			
		$sql=mysql_query("select * from nile_news_users where email='$email' && news_users_id != $idno");
		$row=mysql_fetch_array($sql);
		$cc=mysql_num_rows($sql);
		if($cc<=0){	
	
	$updsub=mysql_query("update nile_news_users set email='$email',last_modified=now(),status='$status' where news_users_id='$idno'");
	header("location:newsletter_users.php?act=view");
	exit;
	}
	else
	{
		header("location:newsletter_users.php?act=view&error=1");
		exit;
	}
}
///////////////////paging////////////////////
$PageSize = 10;
$StartRow = 0;
if(empty($_GET['PageNo'])){
    if($StartRow == 0){
        $PageNo = $StartRow + 1;
    }
}else{
    $PageNo = $_GET['PageNo'];
    $StartRow = ($PageNo - 1) * $PageSize;
}

if($PageNo % $PageSize == 0){
    $CounterStart = $PageNo - ($PageSize - 1);
}else{
    $CounterStart = $PageNo - ($PageNo % $PageSize) + 1;
}
//Counter End
$CounterEnd = $CounterStart + ($PageSize - 1);
//////////////////end //////////////////////////////

	
	$TRecord=mysql_query("select * from nile_news_users");
	//echo "select * from nile_news_users LIMIT ". $StartRow .",". $PageSize."";exit;
	$sql=mysql_query("select * from nile_news_users LIMIT ". $StartRow .",". $PageSize."");


$RecordCount = mysql_num_rows($TRecord);
$MaxPage = $RecordCount % $PageSize;
if($RecordCount % $PageSize == 0){
    $MaxPage = $RecordCount / $PageSize;
 }
else{
    $MaxPage = ceil($RecordCount / $PageSize);
 }

$num=mysql_num_rows($sql);

?>


<body>
	<TABLE cellSpacing=0 cellPadding=0 width=96% align=center border="0">
	
	<tr>
	<td>
	
	          <!--VIEW USERS -->
			  <?php  if($act=="view"){?>
	<form name="formx" method="post" enctype="multipart/form-data">
	
<table width="100%">
	
	<tr>
		<td height="40" align="center" class="style13">&nbsp;<b class="greentext22bold">View NewsLetter Users </b></td>
	</tr>
	<?php  if($num<=0){?>
		<tr>
			<td height="40" colspan="2" align="center" class="style14">
			<?php 
				header("Location:newsletter_users.php?act=new");
			?>			</td>
		</tr>
	<?php  } else { 
					
	?>
					
					<tr class="txtblack3" >
					  <td height="10" align="right" class="normal" colspan="10" ><a href="newsletter_users.php?act=new" class="greentextbold">Add Newsletter User </a></td>
	  </tr>
					<tr class="txtblack3" >
					  <td height="10" align="center" class="normal" colspan="10" ><span class="style14">
					    <?php 
					  if($error==1)
					  {
					  	echo "News Title already exists";
					  }
					  ?>
					  </span></td>
	  </tr>
					<tr class="txtblack3" >
					<td height="10" align="right" class="normal" colspan="10" ><b ><strong><font color="#FF0000">Page: <?php  echo $PageNo." of ". $MaxPage  ?></font></strong></b></td>
				</tr>
          <tr>
		<td colspan="2">
			<table width=79% border="0" align=center cellPadding=0 cellSpacing=0 frame="box" style="border-style:solid; border-width:1px; border-color:#999999" >
				<tr class="txtblack3" bgcolor="#FA9032" >
				  <td width="68" height="31" align="center" class="style12"><input type="checkbox" name="selall" onClick="checkstate('chk[]')" ></td>
				  <td width="215" align="center" bgcolor="#FA9032" class="style12"><span class="itemstyle">Email ID </span></td>
				  <td width="179" bgcolor="#FA9032" class="style12"><div align="center" class="itemstyle"><span class="tahoma11boldwhite">Date Added</span></div></td>
				  <td width="111" align="center" bgcolor="#FA9032" class="style12"><span class="itemstyle">Status</span></td>
				  <td width="60" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Edit</b></td>
					<td width="85" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Delete</b></td>
			  </tr>
<?php  
 while($row=mysql_fetch_array($sql))
{ 
				if($row['news_status'] ==1){
					$href = "newsletter_users.php?act=send&aid=$row[news_users_id]";
					
				}else{
					$href= "javascript:alert('You must activate this newsletter to send.');";
				}
?>
				<tr style="background-color:#FFFFFF" onMouseOver="javascript:MouseOverMenu(this);" onMouseOut="javascript:MouseOutMenu(this);">
						<td align="center" class="style12"><input type="hidden" name="chk1[]"  id="chk1" value="<?php echo $row['news_users_id']; ?>"> 
   					  <input type="checkbox" name="chk[]"  id="chk" value="<?php  echo $row['news_users_id']; ?>" onClick="checkval('chk[]')"></td>
				
					<td align="center" class="normal style12"><?php echo $row[email]?></td>
					<td height="28" class="normal style12"><div align="center">
					
					<?php  
					list($year1,$month1,$date1)=split('[-]',$row[date_added]);
					echo $month1."/".$date1."/".$year1;
				?>
					
				
				    </div></td>
					<td align="center" class="normal style12"><?php  if($row['status'] ==1){ echo "Approved";}else{ echo "Rejected";}?></td>
					<td height="28" class="normal style12"><div align="center">
					  <a href="newsletter_users.php?act=edit&aid=<?php echo $row[news_users_id]?>"><img src="images/edit_f2.png" width="18" height="18" border="0"></a>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					   <a href="javascript:delete1(<?php echo $row['news_users_id']?>)">
					   <img src="images/delete.png" width="18" height="18" border="0"></a>
				    </div></td>
			  </tr><?php 
					}
					?>
		  </table>	  </td>
		  </tr><tr><td>&nbsp;</td></tr>
					<tr>
					  <td align="center"><img src="images/delete1.gif" onClick="javascript:document.formx.action='newsletter_users.php?ok=alldel';document.formx.submit();"><!--<input name="delete" type="button" class="greentextbold" onClick="javascript:document.formx.action='newsletter_users.php?ok=alldel';document.formx.submit();" value="Delete">--></td>
	  </tr>
					<tr>
					  <td align="right" class="normal">
					  <?php
      	//Print First & brvious Link is necessary
        if($CounterStart != 1){
            $brvStart = $CounterStart - 1;
            print "<a href=newsletter_users.php?PageNo=1&act=view>First </a>: ";
            print "<a href=newsletter_users.php?PageNo=$brvStart&act=view>brvious </a>";
        }
        print " <font color='red'><b> [ </b></font>";
        $c = 0;

        //Print Page No
        for($c=$CounterStart;$c<=$CounterEnd;$c++){
            if($c < $MaxPage){
                if($c == $PageNo){
                    if($c % $PageSize == 0){
                        print "$c ";
                    }else{
                        print "$c , ";
                    }
                }elseif($c % $PageSize == 0){
                    echo "<a href=newsletter_users.php?PageNo=$c&act=view>$c</a> ";
                }else{
                    echo "<a href=newsletter_users.php?PageNo=$c&act=view>$c</a> , ";
                }//END IF


            }else{
                if($PageNo == $MaxPage){
                    print "$c ";
                    break;
                }else{
                    echo "<a href=newsletter_users.php?PageNo=$c&act=view>$c</a> ";
                    break;
                }
            }
       }

      echo "<font color='red'><b> ]</b> </font> ";

      if($CounterEnd < $MaxPage){

          $NextPage = $CounterEnd + 1;
          echo "<a href=newsletter_users.php?PageNo=$NextPage&act=view>Next</a>";
      }
      
      //Print Last link if necessary
      if($CounterEnd < $MaxPage){
       $LastRec = $RecordCount % $PageSize;
        if($LastRec == 0){
            $LastStartRecord = $RecordCount - $PageSize;
        }
        else{
            $LastStartRecord = $RecordCount - $LastRec;
        }

        print " : ";
        echo "<a href=newsletter_users.php?PageNo=$MaxPage&act=view>Last</a>";
        }?></td>
	  </tr>
	</table>
	</form>
	
	<?php 
		}}
	?>
	</td></tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr>
					  <td align="left">
					  
					  			<!--ADD and EDIT -->
					  <?php  
				  		
					  if($act=='new' || $act=='edit') {
					   if($act == 'edit'){
					$chn=mysql_query("select * from nile_news_users where news_users_id='$aid'");
					$row=getSqlFetch($chn);
					extract($row);
					}
					  ?>
					  <form name="formx1" method="post" enctype="multipart/form-data">
						<input type="hidden" name='idno' value="<?php echo $aid?>">
						<input type="hidden" name='oldname' value="<?php echo $catname?>">
						<input type="hidden" name='img' value="<?php echo $image?>">
					  <TABLE cellSpacing=0 cellPadding=0 width=100% align=center border="0">
                        <tr>
                          <td height="40" colspan="3" align="center" class="txtnolink">&nbsp;<b class="greentext22bold">
                            <?php 
							if($aid){
							?>
                            Edit NewsLetter Users Details
  <?php  }else {?>
                            Add  NewsLetter Users Details
  <?php  }?>
                          </b></td>
                        </tr>
						<tr>
						<td colspan="3" align="center" class="style14">
						<?php 
						if($error==1)
						{
							echo "Category already Exists";
						}
						?>						</td>
						</tr>
                        <tr>
                          <td height="40" colspan="3" align="right" class="txtnolink"><a href="newsletter_users.php?act=view" class="greentextbold"><b>View Users </b></a>&nbsp;</td>
                        </tr>
                        <TR>
                          <TD width="413" height="30" align="right" class="itemstyle"><span style="padding-top:4px;">Email ID </span></TD>
                          <TD width="34" align="center">:</TD>
                          <TD width="473"><input name="email" type="text" id="email" value="<?php echo $email?>" size="25" /></TD>
                        </TR>
						
						<tr><td>&nbsp;</td></tr>
						
						<?php  if($act == 'edit'){?>
						<TR>
                          <TD width="413" height="30" align="right" class="itemstyle"><span style="padding-top:4px;">Subscribed for  </span></TD>
                          <TD width="34" align="center">:</TD>
                          <TD width="473"><?php echo ucfirst($subscribed_for)?> Category</TD>
                        </TR>
						<?php  } ?>
						
						
						<?php  if($act == 'new'){?>
						
						
						<?php 	$sql_comm="select * from nile_news";
							$execute_sql=mysql_query($sql_comm) or die(mysql_error());
							 ?>
						
						
						<TR>
                          <TD width="413" height="30" align="right" class="itemstyle"><span style="padding-top:4px;">Subscribe for  </span></TD>
                          <TD width="34" align="center">:</TD>
                          <TD width="473">
						  
						   <?php foreach($new_array as $value)
						  					{ 
						  					?>
						  
						  
						  <table width="180" border="0" cellspacing="0" cellpadding="0">
										  <tr>
											<td><input type="checkbox" name="comm[]" value="<?php echo $value?>">
											<span class="normal"> <?php echo $value?></span></td>
										  </tr>
										</table>

						  
						  
						  
						 
						  <?php  } ?>
						  
						 						  
						  </TD>
                        </TR>
						<?php  } ?>
						
                        <?php  if($act == 'edit'){?>
						<?php  }?>
                        <TR>
                          <TD height="30" align="right" class="itemstyle">Approved user</TD>
                          <TD align="center">:</TD>
                          <td align="left" class="normal"><input name="status" type="radio" value="1" checked="checked" <?php  if( isset($status) && $status == 1 ){ echo "checked";}else if($act == 'new'){ echo "checked";}?> />
                            Yes
                            <input name="status" type="radio" value="0" <?php  if( isset($status) && $status == 0 ){ echo "checked";} ?> />
                          No</td>
                        </TR>
                        <TR>
                          <TD height="60" colspan="3" align="center"><?php 
			if($aid){
			?>
                              <img src="images/update.gif" onClick="javascript:return news_user1();" ><!--<input name="submit" type="submit" class="normal" onClick="javascript:return news_user1();" value='Update'>-->
                              <?php 
		} else {
		?>
                <img src="images/adduser.gif" onClick="javascript:return news_user();" ><!--<input name="submit" type="submit" class="normal" onClick="javascript:return news_user();" value='Add User'>-->
                            <?php  }?>
                            &nbsp;
                           <img src="images/cancel.gif"  onClick="javascript:document.formx1.action='newsletter_users.php?act=view';document.formx1.submit();" > <!--<input name="submit1" type="submit" class="normal" onClick="javascript:document.formx1.action='newsletter_users.php?act=view';document.formx1.submit();" value="Cancel">-->                          </TD>
                        </TR>
                        <TR>
                          <TD height="50" colspan="3">&nbsp;</TD>
                        </TR>
                      </TABLE>
					  <?php 
					  }
					  ?>
					  </form>
					 <!-- END ADD AND EDIT -->
					  
					  </td>
	  </tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr><td align="center">&nbsp;</td>
					</tr>
					
					</TABLE>

					</body>
					</html>
			