<HTML>
<BODY bgcolor="#FFFFFF" >
<table border="0" align="center" width="100%">
<tr><td>&nbsp;</td></tr>
<tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>
<tr>
<td align="center" valign="middle">
<?php

//include slideshow.php to access the Insert_Slideshow function
include "sample.php";

//insert the slideshow.swf flash file into the web page
//tell slideshow.swf to get the slideshow's data from sample.php created in the first step
//set the slideshow's width to 320 pixels and the height to 240
echo Insert_Slideshow ( "slideshow.swf", "sample.php", 320, 240 );

?>
</td></tr></table>
</BODY>
</HTML>