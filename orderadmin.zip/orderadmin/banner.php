<?
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
extract($_REQUEST);
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='validation.js'></script>

<script type="text/javascript">
//var _editor_url  = document.location.href.replace(/examples\/simple_example\.html.*/, '')
// And the language we need to use in the editor.
var _editor_lang = "en";
//var _editor_url  = document.location.href.replace(/xinha\/xinha\*/, '')
var _editor_url = "../../cybermix/admin/xinha/";
</script>
<!-- Load up the actual editor core -->
<script type="text/javascript" src="xinha/htmlarea.js"></script>
<script type="text/javascript">
/*var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'SpellChecker', 'Stylist', 'SuperClean', 'TableOperations', 'ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText', 'InsertSmiley', 'InsertAnchor', 'HorizontalRule', 'GetHtml', 'FullScreen', 'BackgroundImage','InsertWords','ListType'
 ];*/
 var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'Stylist', 'SuperClean','TableOperations','ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText',  'InsertAnchor','HtmlEntities','FullPage','ContextMenu'
];
/************************************************************************
 * Names of the textareas you will be turning into editors
 ************************************************************************/
var xinha_editors =
[
   'cat_desc1'
];
/************************************************************************
 * Initialisation function
 ************************************************************************/
function xinha_init()
{
  // THIS BIT OF JAVASCRIPT LOADS THE PLUGINS, NO TOUCHING  :)
  //var _editor_url  = document.location.href.replace(/xinha\*/, '');
 // alert(_editor_url);
  if(!HTMLArea.loadPlugins(xinha_plugins, xinha_init)) return;
  var xinha_config = new HTMLArea.Config();
    xinha_editors = HTMLArea.makeEditors(xinha_editors, xinha_config, xinha_plugins);
   //xinha_editors.cat_smdesc.config.width = '600px';
  // xinha_editors.cat_smdesc.config.height = '400px';
   xinha_editors.cat_desc.config.width = '500px';
   xinha_editors.cat_desc.config.height = '300px';
   //xinha_editors.cat_smdesc.config.statusBar = false;
   xinha_editors.cat_desc.config.statusBar = false;
   HTMLArea.startEditors(xinha_editors);
}
window.onload = xinha_init;
</script>
<script language="javascript">
function open_window(img_name)
{
	url = "../images/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function open_window1(img_name)
{
	url = "../images/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function delete1(uid){
	if(confirm("Are you sure want to delete?")){
		document.location.href = 'banner.php?del=1&uid='+uid;
	}
}
</script>
<link type="text/css" rel="stylesheet" title="xp-green" href="xinha/skins/xp-green/skin.css">
</head>
<?
///////////////////////////////single delete/////////////////////////////////
	$del=$_REQUEST['del'];
	$uid=$_REQUEST['uid'];
	if($del==1)
	{
			
			$sql=mysql_query("select * from nile_banner where nile_banner_id='$uid'");
			$res=mysql_fetch_array($sql);
			$image=$res['image'];
			@unlink("../images/banners/".$image);
			$delete2=mysql_query("delete from nile_banner where nile_banner_id='$uid'");
			header("location:banner.php?act=view");
			exit;
			
	}
///////////////////////////////////////multiple delete///////////////////////////
	$ok=$_REQUEST[ok];
	$colors=$_REQUEST['chk'];
	$chk1=$_REQUEST['chk1'];
	$number=count($colors);
	if($ok=='alldel')
	{
		foreach($colors as $chk1)
		{
			$sql=mysql_query("select * from nile_banner where nile_banner_id='$chk1'");
			$res=mysql_fetch_array($sql);
			$image=$res['image'];
			//delete_directory("../images/categories/".$name."/");
			@unlink("../images/banners/".$image);
			$delete2=mysql_query("delete from nile_banner where nile_banner_id='$chk1'");
		}
		header("location:banner.php?act=view");
		exit;	
			
	}
		

//////////////////////////////end of multiple delete///////////////////////////////////	
$ok=$_REQUEST[ok];
//////////////////////////////////////ADD////////////////////////////////////////////
if($ok==add)
{
	$selCat = mysql_query("SELECT * FROM nile_banner WHERE name='$name'");
	$num=mysql_num_rows($selCat);
	if($num<=0)
	{
		$rand=time();
		$ss=mkdir("images/banners/",0777);
		$uploaddir="images/banners/";
		$filetype=$_FILES[image][type];
		$filename=$_FILES[image][name];
		$realpath=$uploaddir.$filename;
		$cc=strtolower($catname);
		if(!empty($filetype)) 
		{	 
			if(move_uploaded_file($_FILES['image']['tmp_name'],$realpath )) 
			{
			
			}
		
		}	
		$sql=mysql_query("insert into nile_banner (advertiser,name,image,url,location,date_added,status) values('$advertiser','$name', '$filename','$url','$location',now(),'$status')");
		header("location:banner.php?act=view");
		exit;
	}
	else
	{
		header("location:banner.php?act=new&error=1");
		exit;
	}
	
}
//////////////////////////////////////update////////////////////////////////////////////
if($ok==edit)
{	
		extract($_REQUEST);
		$rand=time();
		$uploaddir="images/banners/";
		$filetype=$_FILES[image][type];
		$filename=$_FILES[image][name];
		$realpath=$uploaddir.$filename;
		if(!empty($filetype)) 
		{	
			@unlink("images/banners/".$last_cat_image); 
			if(move_uploaded_file($_FILES['image']['tmp_name'],$realpath)) 
			{
				
			}

		else
		{
			$filename=$last_cat_image;
		}
	}
		$sql=mysql_query("select * from nile_banner where name='$name' && nile_banner_id != $idno");
		$row=mysql_fetch_array($sql);
		$cc=mysql_num_rows($sql);
		if($cc<=0){	
	
	$updsub=mysql_query("update nile_banner set name='$name', advertiser='$advertiser' , image='$filename' ,url='$url' ,location='$location' ,last_modified=now(),status='$status' where nile_banner_id='$idno'");
	header("location:banner.php?act=view");
	exit;
	}
	else
	{
		header("location:banner.php?act=view&error=1");
		exit;
	}
}
///////////////////paging////////////////////
$PageSize = 10;
$StartRow = 0;
if(empty($_GET['PageNo'])){
    if($StartRow == 0){
        $PageNo = $StartRow + 1;
    }
}else{
    $PageNo = $_GET['PageNo'];
    $StartRow = ($PageNo - 1) * $PageSize;
}

if($PageNo % $PageSize == 0){
    $CounterStart = $PageNo - ($PageSize - 1);
}else{
    $CounterStart = $PageNo - ($PageNo % $PageSize) + 1;
}
//Counter End
$CounterEnd = $CounterStart + ($PageSize - 1);
//////////////////end //////////////////////////////

	
	$TRecord=mysql_query("select * from nile_banner");
	$sql=mysql_query("select * from nile_banner LIMIT ". $StartRow .",". $PageSize."");


$RecordCount = mysql_num_rows($TRecord);
$MaxPage = $RecordCount % $PageSize;
if($RecordCount % $PageSize == 0){
    $MaxPage = $RecordCount / $PageSize;
 }
else{
    $MaxPage = ceil($RecordCount / $PageSize);
 }

$num=mysql_num_rows($sql);

?>


<body>
	<TABLE cellSpacing=0 cellPadding=0 width=96% align=center border="0">
	
	<tr>
	<td>
	
	          <!--VIEW USERS -->
			  <? if($act=="view"){?>
	<form name="formx" method="post" enctype="multipart/form-data">
	
<table width="100%">
	
	<tr>
		<td height="40" align="center" class="style13">&nbsp;<b class="greentext22bold">View Banners </b></td>
	</tr>
	<? if($num<=0){?>
		<tr>
			<td height="40" colspan="2" align="center" class="style14">
			<?
				header("Location:banner.php?act=new");
			?>			</td>
		</tr>
	<? } else { ?>
					
					<tr class="txtblack3" >
					  <td height="10" align="right" class="normal" colspan="10" ><a href="banner.php?act=new" class="greentextbold">Add  Banner </a></td>
	  </tr>
					<tr class="txtblack3" >
					  <td height="10" align="center" class="normal" colspan="10" ><span class="style14">
					    <?
					  if($error==1)
					  {
					  	echo "Banner already exists";
					  }
					  ?>
					  </span></td>
	  </tr>
					<tr class="txtblack3" >
					<td height="10" align="right" class="normal" colspan="10" ><b ><strong><font color="#FF0000">Page: <? echo $PageNo." of ". $MaxPage  ?></font></strong></b></td>
				</tr>
	
	<tr>
		<td colspan="2">
			<table width=79% border="0" align=center cellPadding=0 cellSpacing=0 frame="box" style="border-style:solid; border-width:1px; border-color:#999999" >
				<tr class="txtblack3" bgcolor="#FA9032" >
				  <td width="50" align="center" class="style12"><input type="checkbox" name="selall" onClick="checkstate('chk[]')" ></td>
				  <td width="126" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><b> Name</b></div></td>
				  <td width="282" bgcolor="#FA9032" class="style12"><div align="center" class="itemstyle"><b>Banner</b></div></td>
				  <td width="155" class="style12"><div align="center" class="itemstyle"><b>Location</b></div></td>
				  <td width="45" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Edit</b></td>
					<td width="60" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Delete</b></td>
			  </tr>
<? 
 while($row=mysql_fetch_array($sql))
{ 
	
?>
				<tr style="background-color:#FFFFFF" onMouseOver="javascript:MouseOverMenu(this);" onMouseOut="javascript:MouseOutMenu(this);">
						<td align="center" class="style12"><input type="hidden" name="chk1[]"  id="chk1" value="<?=$row['nile_banner_id']; ?>"> 
   					  <input type="checkbox" name="chk[]"  id="chk" value="<? echo $row['nile_banner_id']; ?>" onClick="checkval('chk[]')"></td>
				
					<td height="28" class="normal style12"><div align="center">
					  <?=$row[name]?>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					  <?=stripslashes($row[image])?>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
                        <?=ucfirst($row[location])?>
                    </div></td>
					<td height="28" class="normal style12"><div align="center">
					  <a href="banner.php?act=edit&aid=<?=$row[nile_banner_id]?>"><img src="images/edit_f2.png" width="18" height="18" border="0"></a>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					   <a href="javascript:delete1(<?=$row['nile_banner_id']?>)">
					   <img src="images/delete.png" width="18" height="18" border="0"></a>
				    </div></td>
			  </tr><?
					}
					?>
		  </table>	  </td>
		  </tr><tr><td>&nbsp;</td></tr>
					<tr>
					  <td align="center"><img src="images/delete1.gif" onClick="javascript:document.formx.action='banner.php?ok=alldel';document.formx.submit();" ><!--<input name="delete" type="button" class="greentextbold" onClick="javascript:document.formx.action='banner.php?ok=alldel';document.formx.submit();" value="Delete">--></td>
	  </tr>
					<tr>
					  <td align="right" class="normal">
					  <?php
      	//Print First & Previous Link is necessary
        if($CounterStart != 1){
            $PrevStart = $CounterStart - 1;
            print "<a href=banner.php?PageNo=1&act=view>First </a>: ";
            print "<a href=banner.php?PageNo=$PrevStart&act=view>Previous </a>";
        }
        print " <font color='red'><b> [ </b></font>";
        $c = 0;

        //Print Page No
        for($c=$CounterStart;$c<=$CounterEnd;$c++){
            if($c < $MaxPage){
                if($c == $PageNo){
                    if($c % $PageSize == 0){
                        print "$c ";
                    }else{
                        print "$c , ";
                    }
                }elseif($c % $PageSize == 0){
                    echo "<a href=banner.php?PageNo=$c&act=view>$c</a> ";
                }else{
                    echo "<a href=banner.php?PageNo=$c&act=view>$c</a> , ";
                }//END IF


            }else{
                if($PageNo == $MaxPage){
                    print "$c ";
                    break;
                }else{
                    echo "<a href=banner.php?PageNo=$c&act=view>$c</a> ";
                    break;
                }
            }
       }

      echo "<font color='red'><b> ]</b> </font> ";

      if($CounterEnd < $MaxPage){

          $NextPage = $CounterEnd + 1;
          echo "<a href=banner.php?PageNo=$NextPage&act=view>Next</a>";
      }
      
      //Print Last link if necessary
      if($CounterEnd < $MaxPage){
       $LastRec = $RecordCount % $PageSize;
        if($LastRec == 0){
            $LastStartRecord = $RecordCount - $PageSize;
        }
        else{
            $LastStartRecord = $RecordCount - $LastRec;
        }

        print " : ";
        echo "<a href=banner.php?PageNo=$MaxPage&act=view>Last</a>";
        }?></td>
	  </tr>
	</table>
	</form>
	
	<?
		}}
	?>
	</td></tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr>
					  <td align="left">
					  
					  			<!--ADD and EDIT -->
					  <? 
				  		
					  if($act=='new' || $act=='edit') {
					   if($act == 'edit'){
					$chn=mysql_query("select * from nile_banner where nile_banner_id='$aid'");
					$row=getSqlFetch($chn);
					extract($row);
					}
					  ?>
					  <form name="formx1" method="post" enctype="multipart/form-data">
						<input type="hidden" name='idno' value="<?=$aid?>">
						<input type="hidden" name='oldname' value="<?=$catname?>">
						<input type="hidden" name='img' value="<?=$image?>">
					  <TABLE cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                        <tr>
                          <td height="40" colspan="3" align="center" class="txtnolink">&nbsp;<b class="greentext22bold">
                            <?
							if($aid){
							?>
                            Edit  Banners
  <? }else {?>
                            Add  Banners
  <? }?>
                          </b></td>
                        </tr>
						<tr>
						<td colspan="3" align="center" class="style14">
						<?
						if($error==1)
						{
							echo "Banner already Exists";
						}
						?>						</td>
						</tr>
                        <tr>
                          <td height="40" colspan="3" align="right" class="txtnolink"><a href="banner.php?act=view" class="greentextbold"><b>View  Banner </b></a>&nbsp;</td>
                        </tr>
                        <TR>
                          <TD height="30" align="right" class="itemstyle">Advertiser</TD>
                          <TD align="center">:</TD>
                          <TD><select name="advertiser" class="title" id="advertiser" style=width:173px>
                              <option value="0">Select</option>
                              <?
						  $selCat = mysql_query("SELECT * FROM advertiser WHERE status=1");
						  $num=mysql_num_rows($selCat);
						  while($data=mysql_fetch_array($selCat))
						  {
						  ?>
                              <option value="<?=$data['advertiser_id']?>" <? if($advertiser==$data['advertiser_id']){?> selected="selected" <? }?>>
                              <?=$data['name']?>
                            </option>
                              <?
						  }
						  ?>
                            </select>
                          <span class="normal"><span class="greentext">(</span><span class="greentextbold">Google Standard Sizes </span><span class="greentext">) </span></span>                          </TD>
                        </TR>
                        <TR>
                          <TD width="260" height="30" align="right" class="itemstyle"> Name</TD>
                          <TD width="37" align="center">:</TD>
                          <TD width="624"><input name="name" id="name" value="<?=$name?>" size=25>
                          <span class="normal">&nbsp;</span></TD>
                        </TR>
                        <?php /*?><TR>
                         
						 <TD height="30" align="right" class="itemstyle">Paste Code</TD>
                          <TD align="center">:</TD>
                          <TD><textarea name="image" rows="5" cols="20"><?=stripslashes($image)?></textarea></TD>
						  
                        </TR><?php */?>
                        <TR>
                          <TD height="30" align="right" class="itemstyle">Image</TD>
                          <TD align="center">:</TD>
                          <TD><input name="image" type="file" id="image" >&nbsp;<?=$image?></TD>
                        </TR>
                        <TR>
                          <TD width="260" height="30" align="right" class="itemstyle">Banner Url</TD>
                          <TD width="37" align="center">:</TD>
                          <TD width="624"><input name="url" id="url" value="<?=$url?>" size=35>
                          <span class="normal">&nbsp;</span></TD>
                        </TR>
						
                        <TR>
                          <TD height="30" align="right" class="itemstyle">Location</TD>
                          <TD align="center">:</TD>
                          <td align="left" class="normal"><input name="location" type="radio" value="top" <? if( isset($location) && $location == "top" ){ echo "checked";}?>>
                            Right top <span class="greentext">(728x90)</span>
                            <input name="location" type="radio" value="right" <? if( isset($location) && $location == "right" ){ echo "checked";}?>>
                            Right middle
                            <span class="greentext">(120x600)</span>
							 <input name="location" type="radio" value="bottom" checked>
                            Right bottom 
                            <span class="greentext">(182x260)</span>
							<input name="location" type="radio" value="header" <? if( isset($location) && $location == "header" ){ echo "checked";}?>>
                            Header
                            <span class="greentext">(182x260)</span>							</td>
                        </TR>
                        <TR>
                          <TD height="30" align="right" class="itemstyle">Status</TD>
                          <TD align="center">:</TD>
                          <td align="left" class="normal"><input name="status" type="radio" value="1" checked />
                            Yes
                            <input name="status" type="radio" value="0" <? if( isset($status) && $status == 0 ){ echo "checked";}?>>
                            No </td>
                        </TR>
                        <TR>
                          <TD height="60" colspan="3" align="center">
						  <?
			if($aid){
			?>
                           <img src="images/update.gif"  onClick="javascript:return banner1();"> <!--  <input name="submit" type="submit" class="normal" onClick="javascript:return banner1();" value='Update'>-->
                              <?
		} else {
		?>
                <img src="images/addbanner.gif"  onClick="javascript:return banner();"><!--<input name="submit" type="submit" class="normal" onClick="javascript:return banner();" value='Add Banners'>-->
                            <? }?>
                            &nbsp;
                          <img src="images/cancel.gif" onClick="javascript:document.formx1.action='banner.php?act=view';document.formx1.submit();"><!--  <input name="submit1" type="submit" class="normal" onClick="javascript:document.formx1.action='banner.php?act=view';document.formx1.submit();" value="Cancel">-->                          </TD>
                        </TR>
                        <TR>
                          <TD height="50" colspan="3">&nbsp;</TD>
                        </TR>
                      </TABLE>
					  <?
					  }
					  ?>
					  </form>
					 <!-- END ADD AND EDIT -->
					  
					  </td>
	  </tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr><td align="center">&nbsp;</td>
					</tr>
					
					</TABLE>

					</body>
					</html>
			