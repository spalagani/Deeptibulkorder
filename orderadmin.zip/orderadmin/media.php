<?
ob_start();
session_start();
extract($_REQUEST);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Welcome to The Greater Fool Auction.com</title>
<link href="images/style.css" rel="stylesheet" type="text/css" />
</head>
<table width="250" border="0" align="center" cellpadding="0" cellspacing="0">
  
  <tr>
    <td align="left" valign="top" bgcolor="#00538D"><embed src="../videos/<?=$ok?>" autostart="true" width="265" height="265" >  </td>
  </tr>
</table>

</html>
