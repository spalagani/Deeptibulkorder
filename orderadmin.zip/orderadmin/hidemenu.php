<?php
ob_start();
require_once('sessionchk.php');
?>
<html>
<head>
<title>Content</title>
<script type="text/javascript" src="cookies.js"></script>
<script type="text/javascript">
function setToggleUI() {
    var label = "Hide Menu";
    if (document.getElementById) {
        if (getCookie("frameHidden") == "true") {
            label = "Show Menu";
        }
        var newElem = document.createElement('a','#cdfff6');
        newElem.onclick = initiateToggle;
        var newText = document.createTextNode(label);
        newElem.appendChild(newText);
        document.getElementById("togglePlaceholder").appendChild(newElem);
    }
}
function initiateToggle(evt) {
    evt = (evt) ? evt : event;
    var elem = (evt.target) ? evt.target : evt.srcElement;
    if (elem.nodeType == 3) {
        elem = elem.parentNode;
    }
    parent.toggleFrame(elem);
}

</script>
<style type="text/css">
a:link {
	color: #ffffff;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #ffffff;
}
a:hover {
	text-decoration: none;
	color: #ffffff;
}
a:active {
	text-decoration: none;
	color: #ffffff;
}
a {
	font-family: verdana;
	font-weight: bold;
	font-size: 10px;
	color: #ffffff;
}
</style>

</head>
<body onLoad="setToggleUI()" topmargin=9 leftmargin=50 bgcolor='#F39542'>
<span id="togglePlaceholder" style="cursor:pointer;"></span>
</body>
</html>
