function ChangeBackground(what, color) {
what.style.backgroundColor=color;
}

function MouseOverMenu(what){
//what.style.cursor='hand';
ChangeBackground(what, "#F2DFD3");}

function MouseOutMenu(what){
what.style.cursor='default';
ChangeBackground(what, "#ffffff");
}

function callmsg()
{	
	var pp=confirm("Are you sure that you want to delete ?");

	if (pp)
	{
		alert("Deleted sucessfully");
		return true;		
		
	}
	else
	{
		return false;
	}
}
function checkval(chkname1)
{
	var allchkbox=document.forms['formx'].elements[chkname1];
	var countallchkbox = allchkbox.length;
	for(var i = 0; i < countallchkbox; i++)
		{
			if(allchkbox[i].checked == 0)
			document.formx.selall.checked=0;
		}
}	
function checkstate(chkname)
{
	if(document.formx.selall.checked==1)
	{
		checkall("formx",chkname,1);
		
	}
	if(document.formx.selall.checked==0)
	{
		checkall("formx",chkname,0);
	}
}	
function checkstate1(chkname)
{
	
		checkall("formx",chkname,1);
	
}	
function checkall(FormName, FieldName, CheckValue)
{
	if(!document.forms[FormName])
		return;
	var objCheckBoxes = document.forms[FormName].elements[FieldName];
	if(!objCheckBoxes)
		return;
	var countCheckBoxes = objCheckBoxes.length;
	if(!countCheckBoxes)
		objCheckBoxes.checked = CheckValue;
	else
		// set the check value for all check boxes
		for(var i = 0; i < countCheckBoxes; i++)
			objCheckBoxes[i].checked = CheckValue;
}	
//////////////////////////////////mouseover//////////////////////////////
function movepic(img_name,img_src) {
document[img_name].src=img_src;
}





///////////////////////////////News user validation//////////////////////////
function news_user()
{
	
	var name = document.formx1.name.value;
	var email = document.formx1.email.value;
	//var cat_desc = document.formx1.cat_desc.value;

		if(name == "")
		{
			alert("Please enter Name.");
			document.formx1.name.focus();
			return false;
							
		}
		if(email == "")
		{
			alert("Please enter Email.");
			document.formx1.email.focus();
			return false;
		
		}	
		
	else
	{
		document.formx1.action='newsletter_users.php?ok=add';
		document.formx1.submit();
	}

}
function news_user1()
{
	
		document.formx1.action='newsletter_users.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////Category validation//////////////////////////
function category()
{
	
	var catname = document.formx1.catname.value;
	var cat_desc = document.formx1.cat_desc.value;
	
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(catname == "")
		{
			alert("Please enter Name.");
			document.formx1.catname.focus();
			return false;
		
		} else if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
		}
						
	else
	{
		document.formx1.action='categories.php?ok=add';
		document.formx1.submit();
	}

}
function category1()
{
	
		document.formx1.action='categories.php?ok=edit';
		document.formx1.submit();
	
}
/////////////////////////////////////////////




function items()
{
	
	var itemname = document.formx1.itemname.value;
	var category = document.formx1.category.value;
	var subcategory = document.formx1.subcategory.value;
	var old_price = document.formx1.old_price.value;
	var new_price = document.formx1.new_price.value;
	
	//var cat_desc = document.formx1.cat_desc.value;
		if(category == "")
		{
			alert("Please select Category.");
			document.formx1.category.focus();
			return false;
		
		}	
		if(subcategory == "")
		{
			alert("Please select Sub Category.");
			document.formx1.subcategory.focus();
			return false;
		
		}	
		
		if(itemname == "")
		{
			alert("Please enter Item Name.");
			document.formx1.itemname.focus();
			return false;
		
		}
		if(old_price == "")
		{
			alert("Please Enter Stock Available");
			document.formx1.old_price.focus();
			return false;
		
		}
		if(new_price == "")
		{
			alert("Please New Price.");
			document.formx1.new_price.focus();
			return false;
		
		}
		
	
		
	else
	{
		document.formx1.action='items.php?ok=add';
		document.formx1.submit();
	}

}
function items1()
{
	
		document.formx1.action='items.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////
function links_items()
{
	
	var itemname = document.formx1.itemname.value;
	var category = document.formx1.category.value;
	var file = document.formx1.file.value;
	var have_hins = document.formx1.have_hins.value;
	var audio_file = document.formx1.audio_file.value;
	
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(itemname == "")
		{
			alert("Please enter Name.");
			document.formx1.itemname.focus();
			return false;
		
		}
		
		if(category == 0)
		{
			alert("Please select Category.");
			document.formx1.category.focus();
			return false;
		
		}	
		
		if(file == "")
		{
			alert("Please upload image.");
			document.formx1.file.focus();
			return false;
		
		}
		
/*		for (i=0;i<have_hins.length;i++) {
			if (have_hins[i].checked == 0) {
			alert("success");
	}
}
*/		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='links_items.php?ok=add';
		document.formx1.submit();
	}

}
function links_items1()
{
	
		document.formx1.action='links_items.php?ok=edit';
		document.formx1.submit();
	
}


function nileinfo_items()
{
	
	var itemname = document.formx1.itemname.value;
	var category = document.formx1.category.value;
	var file = document.formx1.file.value;
	var have_hins = document.formx1.have_hins.value;
	var audio_file = document.formx1.audio_file.value;
	
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(itemname == "")
		{
			alert("Please enter Name.");
			document.formx1.itemname.focus();
			return false;
		
		}
		
		if(category == 0)
		{
			alert("Please select Category.");
			document.formx1.category.focus();
			return false;
		
		}	
		
		if(file == "")
		{
			alert("Please upload image.");
			document.formx1.file.focus();
			return false;
		
		}
		
/*		for (i=0;i<have_hins.length;i++) {
			if (have_hins[i].checked == 0) {
			alert("success");
	}
}
*/		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='nileinfo_items.php?ok=add';
		document.formx1.submit();
	}

}
function nileinfo_items1()
{
	
		document.formx1.action='nileinfo_items.php?ok=edit';
		document.formx1.submit();
	
}



///////////////////////////////Admin validation//////////////////////////
function admin()
{
	
	var fname = document.formx1.fname.value;
	var lname = document.formx1.lname.value;
	var username = document.formx1.username.value;
	var password = document.formx1.password.value;
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(fname == "")
		{
			alert("Please enter First Name.");
			document.formx1.fname.focus();
			return false;
		
		}	
		if(lname == "")
		{
			alert("Please enter Last Name.");
			document.formx1.lname.focus();
			return false;
		
		}	
		if(username == "")
		{
			alert("Please enter username.");
			document.formx1.username.focus();
			return false;
		
		}	
		if(password == "")
		{
			alert("Please enter password.");
			document.formx1.password.focus();
			return false;
		
		}	

		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='admin_edit.php?ok=add';
		document.formx1.submit();
	}

}
function admin1()
{
	
		document.formx1.action='admin_edit.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////



///////////////////////////////auction validation//////////////////////////
function page()
{
	
	var name = document.formx1.name.value;
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(name == "")
		{
			alert("Please enter Name.");
			document.formx1.name.focus();
			return false;
		
		}	
		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='cms.php?ok=add';
		document.formx1.submit();
	}

}
function page1()
{
	
		document.formx1.action='cms.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////



///////////////////////////////sub category validation//////////////////////////
function newcategory()
{
	var cat_id = document.formx1.cat_id.value;
	var subcatname = document.formx1.subcatname.value;
	var subcat_desc = document.formx1.subcat_desc.value;
	
	//var cat_desc = document.formx1.cat_desc.value;
		if(cat_id == "")
		{
			alert("Please Select Category.");
			document.formx1.cat_id.focus();
			return false;
		
		}
		else if(subcatname == "")
		{
			alert("Please enter Name.");
			document.formx1.subcatname.focus();
			return false;
		
		} else if(subcat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.subcat_desc.focus();
			return false;
		}
						
	else
	{
		document.formx1.action='subcategories.php?ok=add';
		document.formx1.submit();
	}
	
 	
}
function newcategory1()
{
	document.formx1.action='subcategories.php?ok=edit';
	document.formx1.submit();
}
////////////////static pagesssssssss///////////////

////////////////////////////////////////////////////////

function pages()
{
	
	var pagename = document.formx1.pagename.value;
	var page_desc = document.formx1.page_desc.value;
		
		if(pagename == 0)
		{
			alert("Please Select any Page.");
			document.formx1.pagename.focus();
			return false;
		
		}
		
		if(page_desc == "")
		{
			alert("Please enter Page description.");
			document.formx1.page_desc.focus();
			return false;
		
		}	
		
	else
	{
		document.formx1.action='staticpages.php?ok=add';
		document.formx1.submit();
	}

}
function pages1()
{
	
		document.formx1.action='staticpages.php?ok=edit';
		document.formx1.submit();
	
}

///////////////////////////////auction validation//////////////////////////
function page()
{
	
	var name = document.formx1.name.value;
	//var cat_desc = document.formx1.cat_desc.value;

		
		if(name == "")
		{
			alert("Please enter Name.");
			document.formx1.name.focus();
			return false;
		
		}	
		
		/*if(cat_desc == "")
		{
			alert("Please enter Category Desc");
			document.formx1.cat_desc.focus();
			return false;
			
					
		}*/
		
	else
	{
		document.formx1.action='cms.php?ok=add';
		document.formx1.submit();
	}

}
function page1()
{
	
		document.formx1.action='cms.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////

///////////////////////////////News validation//////////////////////////
function news()
{
	
	var news_title = document.formx1.news_title.value;
	//var news_desc = document.formx1.news_desc.value;
	//var cat_desc = document.formx1.cat_desc.value;

		if(news_title == "")
		{
			alert("Please enter News Title.");
			document.formx1.news_title.focus();
			return false;
							
		}
		/*if(news_desc == "")
		{
			alert("Please enter News Desc.");
			document.formx1.news_desc.focus();
			return false;
		
		}	*/
		
	else
	{
		document.formx1.action='news.php?ok=add';
		document.formx1.submit();
	}

}
function news1()
{
	
		document.formx1.action='news.php?ok=edit';
		document.formx1.submit();
	
}

////////////////////////////////End //////////////////////////////////////////////////



///////////////////////////////News user validation//////////////////////////
function news_user()
{
	
	var name = document.formx1.name.value;
	var email = document.formx1.email.value;
	//var cat_desc = document.formx1.cat_desc.value;

		if(name == "")
		{
			alert("Please enter Name.");
			document.formx1.name.focus();
			return false;
							
		}
		if(email == "")
		{
			alert("Please enter Email.");
			document.formx1.email.focus();
			return false;
		
		}	
		
	else
	{
		document.formx1.action='newsletter_users.php?ok=add';
		document.formx1.submit();
	}

}
function news_user1()
{
	
		document.formx1.action='newsletter_users.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////
function order1()
{
	
		document.formx1.action='orders.php?ok=edit';
		document.formx1.submit();
	
}
////////////////////////////////End //////////////////////////////////////////////////
