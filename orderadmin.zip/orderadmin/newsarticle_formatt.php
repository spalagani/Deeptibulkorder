$msg = "<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Welcome to NileRiver</title>
<link href='http://202.63.102.85:82/php/nileriver/style.css' rel='stylesheet' type='text/css' />
<link href="file://///raju/nileriver/admin/images/style.css" rel="stylesheet" type="text/css">
</head>

<body  leftmargin='0' topmargin='0' marginwidth='0' marginheight='0'>

  <table width='91%' border='0' cellpadding='0' cellspacing='0' background='http://202.63.102.85:82/php/nileriver/images/header_01.jpg'>
  <tr>
    <td width='33%'><table width='100%' border='0' align='center' cellpadding='0' cellspacing='0'>
      <tr>
        	<td width='90%'><img src='http://202.63.102.85:82/php/nileriver/admin/images/logo_1191918845.gif' /></td>
      </tr>
    </table></td>
    <td width='37%'>&nbsp;</td>
    <td width='30%' align='left' valign='middle' ><div align='center'> <br />
   .</div></td>
  </tr></table>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width='779' border='0' cellpadding='0' cellspacing='0' >
      <tr>
        <td width='6' height='32' align='left'></td>
        <td width='758'><table width='100%' border='0'>
          <tr>
            <td width='12%'>&nbsp;</td>
            <td width='88%'><table width='100%' border='0' >
              
              <tr>
                <td class='search-txt'>&nbsp;</td>
              </tr>
              
              <tr>
                <td class='search-txt'>&nbsp;</td>
              </tr>
              <tr align='left'>
                <td  class="normal" align='left'>".stripslashes($news_desc)."</td>
              </tr>
              <tr>
                <td class='search-txt'>&nbsp;</td>
              </tr>
              
              <tr>
                <td class='search-txt'>&nbsp;</td>
              </tr>
              <tr align='left'>
                <td class='normal' align='left'><span class='search-txt'> Thank You,</span></td>
              </tr>
              <tr align='left'>
                <td class='normal' align='left'>The Nileriver Support Team</td>
              </tr>
              
            </table></td>
          </tr>
        </table></td>
        <td width='6' align='right'></td>
      </tr>
    </table></td>
  </tr>
  
  
 
</table>
</body>

</html>";