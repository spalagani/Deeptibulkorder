<?php
ob_start();
session_start();
include('includes/connection.php');
include("includes/sessionchk.php");
/////////////Query retrieving active users////////////////////
$qact=mysql_query("SELECT * FROM a1_users WHERE status='1'");
$numact=mysql_num_rows($qact);
//////////////////////////////////////////////////////////////

/////////////Query retrieving inactive users////////////////////
$qinact=mysql_query("SELECT * FROM a1_users WHERE status='0'");
$numinact=mysql_num_rows($qinact);
//////////////////////////////////////////////////////////////

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE><?php echo $title?></TITLE>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<LINK href="images/style.css" type=text/css rel=stylesheet>
<script language="JavaScript" type="text/javascript" src="images/common.js"></script>
<script language="JavaScript" type="text/javascript" src="images/ddmenu.js"></script>
	<link rel="stylesheet" type="text/css" href="images/common.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="images/default_view.css" media="screen" />
	<script language="JavaScript" type="text/javascript">
	<!-- 
	// this all you have to do get your menu working! 
	DHTML_Popup.DELAY = 100; 
	DHTML_Popup.ID = "navigation"
	
	//-->
	function refresh1()
	{
		window.reload();
	}
	</script>
	
<style type="text/css">
<!--
body {
	background-color: #FFFFFF;
}
-->
</style></HEAD>
<BODY onLoad="refresh1()" text=#000000 leftMargin=0 topMargin=0>
<TABLE cellSpacing=0 cellPadding=0 width="100%" bgColor=#ffffff border=0>
  <TBODY>
  <TR>
    <TD>
    <?php 
		include("includes/header.php");
	?>  
	</TD></TR></TBODY></TABLE>
<TABLE class=middlebgcolor height=396 cellSpacing=0 cellPadding=0 width="100%" 
border=0>
  <TBODY>
  <TR>
    <TD vAlign=top>
      <TABLE cellSpacing=2 cellPadding=2 width="97%" align=center border=0>
        <TBODY>
        <TR>
          <TD class="style1">
            <DIV class=style>
            <TABLE cellSpacing=0 width="98%" align=center>
              <TBODY>
              <TR>
                <TD height="10" class="style121">&nbsp;</TD>
                <TD height="10" class="style121">&nbsp;</TD>
                <TD class=uplevel></TD>
              </TR>
              <TR>
                <TD width="3%" class="style121"><IMG height=24 src="images/arrow-right.gif" 
                  width=24></TD>
                <TD width="93%" class="style121"> Desktop <SPAN class=style1>for ::<span class="style14">Vikram Tests</span>::</SPAN></TD>
                <TD width="4%" class=uplevel></TD></TR></TBODY></TABLE>
            </DIV>
            <TABLE>
              <TBODY>
              <TR>
                <TD>&nbsp;</TD></TR>
              <TR>
        <TD>&nbsp;</TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
      <TABLE cellSpacing=0 cellPadding=0 width="70%" align=center border=0>
        <TBODY>
        <TR>
          <TD>
            <DIV>
            <FIELDSET>
            <LEGEND>Desktop</LEGEND>
            <table width="695">
			<tr><td>&nbsp;</td></tr>
			<tr>
                  <td width="100%" bgcolor="">Welcome</td>
			</tr>
			
			
			</table></FIELDSET> 
        <BR></DIV></TD></TR></TBODY></TABLE></TD>
  </TR></TBODY></TABLE>
<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
  <TBODY>
  <TR>
    <TD background="images/bg-bottom.jpg" height=24>
      <?php 
	  		include("includes/footer.php");
	  ?>
</TD></TR></TBODY></TABLE></TD></TR></TABLE></BODY></HTML>
