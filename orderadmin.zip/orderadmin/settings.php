<?php 
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='validation.js'></script>
<script language="javascript">
function open_window(img_name)
{
	url = "images/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
var OpenSubX = (screen.width/2)-5;
var OpenSubY = (screen.height/2)-100;
var pos = "left="+OpenSubX+",top="+OpenSubY;

function openSub(x){
		
		openSub1Window = window.open("../template.php?id="+x ,"not","width=220,height=150,"+pos);
		
}
function openSubC(x){
		//alert(x);
		openSub1Window = window.open("../color.php?id="+x ,"not","width=300,height=320,"+pos);
		
}
</script>

</head>
<?php 
	extract($_REQUEST);

if($ok==edit)
{
$rand=time();
	
		$uploaddir="images/";
		$filetype=$_FILES[image][type];
		if($filetype=="image/pjpeg")
		{
			$type=".jpg";
		}
		elseif($filetype=="image/gif")
		{
			$type=".gif";
		}	
		$filename="logo_".$rand.$type;
		$realpath=$uploaddir.$filename;
		if(!empty($filetype)) 
		{	 
			@unlink("images/".$last_image); 
			if(move_uploaded_file($_FILES['image']['tmp_name'],$realpath )) 
			{
			
			}
		
		}
		else
		{
			$filename=$last_image;
		}
		/*echo "update nile_settings  set alogo='$filename', admintitle='$admintitle',htext='$htext', title='$title', metadesp='$metadesp',  metakeywords='$metakeywords',smtpauth='$smtpauth', smpthost='$smpthost',  username='$username' , password='$password',  fromadd='$fromadd', fromname='$fromname' where auto_id='$idno'";exit;*/
		
	$sql=mysql_query("update nile_settings  set alogo='$filename', admintitle='$admintitle',htext='$htext', title='$title', metadesp='$metadesp',  metakeywords='$metakeywords',smtpauth='$smtpauth', smpthost='$smpthost',  username='$username' , password='$password',  fromadd='$fromadd', fromname='$fromname' where auto_id='$idno'");
	header("location:settings.php");
	exit;
}
$chn=mysql_query("select * from nile_settings");
$row=mysql_fetch_array($chn);
?>
<body>
<form name="formx" method="post"  enctype="multipart/form-data">
<input type="hidden" name='idno' value="<?php echo $row['auto_id']?>">
	<TABLE cellSpacing=0 cellPadding=0 width=683 align=center border="0">
		<tr>
		  <td height="40" colspan="3" align="center" class="txtnolink">&nbsp;<b class="greentext22bold">
	      Edit Settings
	      </b></td>
	  </tr>
	    <TR>
	      <TD height="30" align="right" class="itemstyle">&nbsp;</TD>
	      <TD align="center">&nbsp;</TD>
	      <TD>&nbsp;</TD>
      </TR>
	    <TR>
          <TD height="30" align="right" class="itemstyle">Admin Logo </TD>
	      <TD align="center">:</TD>
	      <TD><input name="image" type="file" class="normal" id="image"></TD>
      </TR>
	    <TR>
	      <TD height="30" align="right" class="itemstyle">&nbsp;</TD>
	      <TD align="center">&nbsp;</TD>
	      <td align="left" class="normal"><?php echo $alogo?>
              <input type="hidden" name="last_image" value="<?php echo $alogo?>">
  &nbsp;<a href="javascript:open_window('<?php echo $alogo?>')" class="greenlink">View</a></td>
      </TR>
	    <TR>
          <TD height="30" align="right" class="itemstyle">Admin Title </TD>
	      <TD align="center">:</TD>
	      <TD><input name="admintitle" id="admintitle" value="<?php echo $row[admintitle]?>" size=25></TD>
      </TR>
        <TR>
          <TD height="30" align="right" class="itemstyle">Admin Header Text </TD>
          <TD align="center">:</TD>
          <TD><input name="htext" id="htext" value="<?php echo $row[htext]?>" size=25></TD>
        </TR>
      <TR>
		  	<TD width="294" height="30" align="right" class="itemstyle">Title </TD>
			<TD width="39" align="center">:</TD>
			<TD width="350"><input name="title" id="title" value="<?php echo $row[title]?>" size=25></TD>
	  </TR>
	  <TR>
		  	<TD height="30" align="right" class="itemstyle">Meta Description </TD>
			<TD align="center">:</TD>
			<TD><textarea name="metadesp" id="metadesp" cols="20" rows="5"><?php echo $row[metadesp]?></textarea></TD>
	  </TR>
	   <TR>
		  	<TD height="30" align="right" class="itemstyle">Meta Keywords  </TD>
			<TD align="center">:</TD>
		 <TD>
		    <textarea name="metakeywords" id="metakeywords" cols="20" rows="5"><?php echo $row[metakeywords]?></textarea></TD>
	  </TR>
	   <?php /*?><TR>
         <TD height="30" align="right" class="itemstyle">SMTP Auth </TD>
	     <TD align="center">:</TD>
	     <td align="left" class="normal">
		 <input name="smtpauth" type="radio" value="1" <? if(isset($row[smtpauth]) && $row[smtpauth] == 1 ){ ?> checked="checked"<? }?> >
	       Yes
	       <input name="smtpauth" type="radio" value="0" <? if( isset($row[smtpauth]) && $row[smtpauth] == 0 ){ echo "checked";}else if($act == 'new'){ echo "checked";}?> />
	       No</td>
      </TR>
       <TR>
         <TD height="30" align="right" class="itemstyle">SMTP Host </TD>
         <TD align="center">:</TD>
         <TD><input name="smpthost" id="smpthost" value="<?php echo $row[smpthost]?>" size=25></TD>
       </TR>
       <TR>
         <TD height="30" align="right" class="itemstyle">SMTP 
           <LABEL for="checkbox_row_7">Username</LABEL></TD>
         <TD align="center">:</TD>
         <TD><input name="username" id="username" value="<?php echo $row[username]?>" size=25></TD>
       </TR>
       <TR>
         <TD height="30" align="right" class="itemstyle">SMTP
           <LABEL for="checkbox_row_7">Password</LABEL></TD>
         <TD align="center">:</TD>
         <TD><input name="password" id="password" value="<?php echo $row[password]?>" size=25></TD>
       </TR>
       <TR>
         <TD height="30" align="right" class="itemstyle">From
           <LABEL for="checkbox_row_7"></LABEL></TD>
         <TD align="center">:</TD>
         <TD><input name="fromadd" id="fromadd" value="<?php echo $row[fromadd]?>" size=25></TD>
       </TR>
       <TR>
         <TD height="30" align="right" class="itemstyle">From Name
           <LABEL for="checkbox_row_7"></LABEL></TD>
         <TD align="center">:</TD>
         <TD><input name="fromname" id="fromname" value="<?php echo $row[fromname]?>" size=25></TD>
       </TR><?php */?>
       
	  
	  <TR>
	  	<TD height="60" colspan="3" align="center">
		
		<input type="button" class="normal" onClick="javascript:document.formx.action='settings.php?ok=edit';document.formx.submit();" value='Update'>  	   </TD>
	</TR>
       <TR>
		  	<TD height="50" colspan="3">&nbsp;</TD>
	</TR>
</TABLE>			
	</td>
		</tr>
  </TABLE>
</form>
 </BODY>
 </HTML>
