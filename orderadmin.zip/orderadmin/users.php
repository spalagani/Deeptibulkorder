<?php 
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
extract($_REQUEST);
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='validation.js'></script>
<script language="javascript">
function delete1(uid){
	if(confirm("Are you sure want to delete?")){
		document.location.href = 'users.php?del=1&uid='+uid;
	}
}
</script>
<style type="text/css">
<!--
.style123 {color: #2A0000}
-->
</style>
</head>
<?php 
$ok=$_REQUEST[ok];
//////////////////////////////////////update////////////////////////////////////////////
if($ok==edit)
{


	$sql=mysql_query("update nile_user set  address='$address', city='$city', state='$state',country='$country', zipcode='$zipcode',  email='$email',password='$password',ipaddress='$ipaddress',status='$news_status' where user_id='$idno'");
	header("location:users.php?act=view");
	exit;
}
///////////////////////////////single delete/////////////////////////////////
	$del=$_REQUEST['del'];
	$uid=$_REQUEST['uid'];
	if($del==1)
	{
		
			$delete2=mysql_query("delete from nile_user where user_id='$uid'");
			header("location:users.php?act=view");
			exit;
			
	}
///////////////////////////////////////multiple delete///////////////////////////
	$ok=$_REQUEST[ok];
	$colors=$_REQUEST['chk'];
	$chk1=$_REQUEST['chk1'];
	$number=count($colors);
	if($ok=='alldel')
	{
		foreach($colors as $chk1)
		{
			$delete2=mysql_query("delete from nile_user where user_id='$chk1'");
		}
		header("location:users.php?act=view");
		exit;	
			
	}
		

//////////////////////////////end of multiple delete///////////////////////////////////	
///////////////////paging////////////////////
$PageSize = 50;
$StartRow = 0;
if(empty($_GET['PageNo'])){
    if($StartRow == 0){
        $PageNo = $StartRow + 1;
    }
}else{
    $PageNo = $_GET['PageNo'];
    $StartRow = ($PageNo - 1) * $PageSize;
}

if($PageNo % $PageSize == 0){
    $CounterStart = $PageNo - ($PageSize - 1);
}else{
    $CounterStart = $PageNo - ($PageNo % $PageSize) + 1;
}
//Counter End
$CounterEnd = $CounterStart + ($PageSize - 1);
//////////////////end //////////////////////////////

	
	$TRecord=mysql_query("select * from nile_user");
	$sql=mysql_query("select * from nile_user LIMIT ". $StartRow .",". $PageSize."");


$RecordCount = mysql_num_rows($TRecord);
$MaxPage = $RecordCount % $PageSize;
if($RecordCount % $PageSize == 0){
    $MaxPage = $RecordCount / $PageSize;
 }
else{
    $MaxPage = ceil($RecordCount / $PageSize);
 }

$num=mysql_num_rows($sql);

?>
<body>
	<TABLE cellSpacing=0 cellPadding=0 width=96% align=center border="0">
	
	<tr>
	<td>
	
	          <!--VIEW USERS -->
			  <?php if($act=="view"){?>
	<form name="formx" method="post">
<table align="center">
	
	<tr>
		<td width="100%" height="40" align="center" class="style13">&nbsp;<b class="greentext22bold">Users Details</b></td>
	</tr>
	<?php if($num<=0){?>
		<tr>
			<td height="40" colspan="2" align="center" >
			<table width="100%">
			  <tr>
			  <td align="center" class="style1">
			There are no users registered!</td>
			</tr></table></td>
		</tr>
	<?php } else { ?>
					<tr class="txtblack3" >
					  <td height="10" align="right" class="normal" colspan="10" >&nbsp;</td>
	  </tr>
					<tr class="txtblack3" >
					<td height="10" align="right" class="normal" colspan="10" ><b ><strong><font color="#FF0000">Page: <?php echo $PageNo." of ". $MaxPage  ?></font></strong></b></td>
				</tr>
	
	<tr>
		<td colspan="2"><table width=100% border="0" align=center cellPadding=0 cellSpacing=0 frame="box" style="border-style:solid; border-width:1px; border-color:#999999" >
          <tr class="txtblack3" bgcolor="#FA9032" >
            <td width="60" align="center" class="style12"><input type="checkbox" name="selall" onClick="checkstate('chk[]')" ></td>
            <td width="131" height="30" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle style123"><b>Member ID</b></div></td>
            <td width="180" bgcolor="#FA9032" class="style12"><div align="center" class="itemstyle style123"><strong>Username</strong></div></td>
            <td width="189" bgcolor="#FA9032" class="style12"><div align="center" class="itemstyle"><b>Email</b></div></td>
            <td width="162" bgcolor="#FA9032" class="style12"><div align="center" class="itemstyle"><b>Registered Date</b></div></td>
			 <td width="162" bgcolor="#FA9032" class="style12"><div align="center" class="itemstyle"><b>Status</b></div></td>
            <td width="55" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Edit</b></td>
            <td width="93" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Delete</b></td>
          </tr>
          <?php 
 while($row=mysql_fetch_array($sql))
{ 
	
?>
          <tr <?php if($row[user_id]==$id){?> bgcolor="#FFCCFF" <?php }else{?> onMouseOver="javascript:MouseOverMenu(this);" onMouseOut="javascript:MouseOutMenu(this);"<?php }?>>
            <td align="center" class="style12"><input type="hidden" name="chk1[]"  id="chk1" value="<?php echo $row['user_id']; ?>">
                <input type="checkbox" name="chk[]"  id="chk" value="<?php echo $row['user_id']; ?>" onClick="checkval('chk[]')"></td>
            <td height="28" class="normal style12"><div align="center">M<?php echo $row[user_id]?>
            </div></td>
            <td height="28" class="normal style12"><div align="center">
              <?php echo $row[username]?>
            </div></td>
            <td height="28" class="normal style12"><div align="center">
                <?php echo $row[email]?>
            </div></td>
            <td height="28" class="normal style12"><div align="center">
               <?php 
					list($year,$month,$date)=split('[-]',$row['date_registered']);
					echo $month."/".$date."/".$year;
				?> 
            </div></td>
			
			
			
			<td height="28" class="normal style12"><div align="center">
                <?php if($row[status]==1)
						{
						$sta="Approved";
						}
						else
						{
						$sta="Not Approved";
						}
						
				echo $sta;
				?>
            </div></td>
			
			
            <td height="28" class="normal style12"><div align="center"><a href="users.php?act=edit&aid=<?php echo $row[user_id]?>"><img src="images/edit_f2.png" width="18" height="18" border="0"></a> </div></td>
            <td height="28" class="normal style12"><div align="center"><a href="javascript:delete1(<?php echo $row['user_id']?>)"><?php /*?><a href="users.php?del=1&uid=<?php echo $row['user_id']?>"><?php */?><img src="images/delete.png" width="18" height="18" border="0"></a> </div></td>
          </tr>
		  <?php 
					}
					?>
        </table></td>
		  </tr><tr><td>&nbsp;</td></tr>
					<tr>
					  <td align="center"><input name="delete" type="button" class="greentextbold" onClick="javascript:document.formx.action='users.php?ok=alldel';document.formx.submit();" value="Delete"></td>
	  </tr>
					<tr>
					  <td align="right" class="normal">
					  <?php
      	//Print First & Previous Link is necessary
        if($CounterStart != 1){
            $PrevStart = $CounterStart - 1;
            print "<a href=users.php?PageNo=1&act=view>First </a>: ";
            print "<a href=users.php?PageNo=$PrevStart&act=view>Previous </a>";
        }
        print " <font color='red'><b> [ </b></font>";
        $c = 0;

        //Print Page No
        for($c=$CounterStart;$c<=$CounterEnd;$c++){
            if($c < $MaxPage){
                if($c == $PageNo){
                    if($c % $PageSize == 0){
                        print "$c ";
                    }else{
                        print "$c , ";
                    }
                }elseif($c % $PageSize == 0){
                    echo "<a href=users.php?PageNo=$c&act=view>$c</a> ";
                }else{
                    echo "<a href=users.php?PageNo=$c&act=view>$c</a> , ";
                }//END IF


            }else{
                if($PageNo == $MaxPage){
                    print "$c ";
                    break;
                }else{
                    echo "<a href=users.php?PageNo=$c&act=view>$c</a> ";
                    break;
                }
            }
       }

      echo "<font color='red'><b> ]</b> </font> ";

      if($CounterEnd < $MaxPage){

          $NextPage = $CounterEnd + 1;
          echo "<a href=users.php?PageNo=$NextPage&act=view>Next</a>";
      }
      
      //Print Last link if necessary
      if($CounterEnd < $MaxPage){
       $LastRec = $RecordCount % $PageSize;
        if($LastRec == 0){
            $LastStartRecord = $RecordCount - $PageSize;
        }
        else{
            $LastStartRecord = $RecordCount - $LastRec;
        }

        print " : ";
        echo "<a href=users.php?PageNo=$MaxPage&act=view>Last</a>";
        }?></td>
	  </tr>
	</table>
	</form>
	
	<?php 
		}}
	?>
	</td></tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr>
					  <td align="left">
					  
					  			<!--ADD and EDIT -->
					  <?php 
				  		
					  if($act=='new' || $act=='edit') {
					$aid=$_REQUEST[aid];
					$chn=mysql_query("select * from nile_user where user_id='$aid'");
					$row=mysql_fetch_array($chn);
					  ?>
					  <form name="formx1" method="post">
						<input type="hidden" name='idno' value="<?php echo $aid?>">
						<TABLE cellSpacing=0 cellPadding=0 width=683 align=center border="0">
                          <tr>
                            <td height="40" colspan="2" align="right" class="txtnolink">&nbsp;<b class="greentext22bold">Edit Users Details</b></td>
                            <td width="350" align="right"><a href="users.php?act=view" class="menulink1"><b>View Users</b></a>&nbsp;</td>
                          </tr>
                          <TR>
                            <TD width="294" height="30" align="right" class="normal"><span class="style14">*</span>Name</TD>
                            <TD width="39" align="center">:</TD>
                            <TD><input size=25 name="name" value="<?php echo $row[fname]." .".$row[lname]?>" readonly="yes"></TD>
                          </TR>
                          
                          <TR>
                            <TD height="30" align="right" class="normal"><span class="style14">*</span>Username</TD>
                            <TD align="center">:</TD>
                            <TD><input size=25 name="username" value="<?php echo $row[username]?>" readonly="yes"></TD>
                          </TR>
                          <TR>
                            <TD height="30" align="right" class="normal"><span class="style14">*</span> Password</TD>
                            <TD align="center">:</TD>
                            <TD><input size=25 name="password" value="<?php echo $row[password]?>"></TD>
                          </TR>
                          <TR>
                            <TD height="30" align="right" class="normal"><span class="style14">*</span> Email</TD>
                            <TD align="center">:</TD>
                            <TD><input size=25 name="email" value="<?php echo $row[email]?>"></TD>
                          </TR>
                          <!--<TR>
                            <TD height="30" align="right" class="normal"><span class="style14">*</span> Age </TD>
                            <TD align="center">:</TD>
                            <TD><input name="age" id="age" value="<?php echo $row[age]?>" size=25></TD>
                          </TR>-->
                          
                          <TR>
                            <TD height="30" align="right" class="normal"><span class="style14">*</span> Address </TD>
                            <TD align="center">:</TD>
                            <TD><input size=25 name="address" value="<?php echo $row[address]?>"></TD>
                          </TR>
                          
                          <TR>
                            <TD height="30" align="right" class="normal"><span class="style14">*</span> City </TD>
                            <TD align="center">:</TD>
                            <TD><input name="city" id="city" value="<?php echo $row[city]?>" size=25></TD>
                          </TR>
                          <TR>
                            <TD height="30" align="right" class="normal"><span class="style14">*</span> State</TD>
                            <TD align="center">:</TD>
                            <TD><input size=25 name="state" value="<?php echo $row[state]?>"></TD>
                          </TR>
                          <TR>
                            <TD height="30" align="right" class="normal"><span class="style14">*</span> Country </TD>
                            <TD align="center">:</TD>
                            <TD><select name="country" class="normal">
                              <option value="">Select Country</option>
                              <?php 
							  $consql=mysql_query("select * from countries");
							  while($conres=mysql_fetch_array($consql))
							  {
							  ?>
                              <option value="<?php echo $conres['country_name']?>" <?php if($conres['country_name']==$row['country']){?> selected="selected" <?php }?>>
                                <?php echo $conres['country_name']?>
                              </option>
                              <?php 
							  }
							  ?>
                            </select></TD>
                          </TR>
                          <TR>
                            <TD height="30" align="right" class="normal"><span class="style14">*</span> Zip</TD>
                            <TD align="center">:</TD>
                            <TD><input name="zipcode" id="zipcode" value="<?php echo $row[zipcode]?>" size=25></TD>
                          </TR>
                         
						 <TR>
                            <TD height="30" align="right" class="normal"><span class="style14">*</span> Ipaddress</TD>
                            <TD align="center">:</TD>
                            <TD><input name="ipaddress" id="ipaddress" value="<?php echo $row[ipaddress]?>" size=25 readonly=""></TD>
                          </TR>
                         			  
						  
                          <TR>
                            <TD height="30" align="right" class="normal">Member ID #  </TD>
                            <TD align="center">:</TD>
                            <TD><input name="sid" id="sid" value="<?php echo $row[user_id]?>" size=25 readonly="yes"></TD>
                          </TR>
                          
                          
						   <TR>
                            <TD height="30" align="right" class="normal">Approved User </TD>
							 <TD align="center">:</TD>
                            <TD><input name="news_status" type="radio" value="1" <?php if( isset($row[status]) && $row[status] == 1 ){ echo "checked";}?> />
                            Yes
                            <input name="news_status" type="radio" value="0" <?php if( isset($row[status]) && $row[status] == 0 ){ echo "checked";}else if($act == 'new'){ echo "checked";}?> />
                          No</TD>
                          </TR>
                          <TR>
                            <TD height="30" colspan="3" align="center"><input name="button2" type="button" class="normal" onClick="javascript:document.formx1.action='users.php?ok=edit';document.formx1.submit();return register();" value='Update'>
                              &nbsp;
                              <input name="button" type="button" class="normal" onClick="javascript:document.formx1.action='users.php?act=view';document.formx1.submit();" value="Cancel"></TD>
                          </TR>
						  
						  <TR>
                            <TD height="30" colspan="3" align="center">&nbsp;</TD>
                          </TR>
						  
                        </TABLE>
						<?php 
					  }
					  ?>
					  </form>
					 <!-- END ADD AND EDIT -->
					  
					  </td>
	  </tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr><td align="center">&nbsp;</td>
					</tr>
					
					</TABLE>

					</body>
					</html>
			