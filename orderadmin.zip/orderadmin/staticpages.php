<?php 
ob_start();
session_start();
include('sessionchk.php');
include('../includes/dbconfig.php');
include("FCKeditor/fckeditor.php");
extract($_REQUEST);
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src='validation.js'></script>
<script type="text/javascript">
//var _editor_url  = document.location.href.replace(/examples\/simple_example\.html.*/, '')
// And the language we need to use in the editor.
var _editor_lang = "en";
//var _editor_url  = document.location.href.replace(/xinha\/xinha\*/, '')
var _editor_url = "../../auction/admin/xinha/";
</script>
<!-- Load up the actual editor core -->
<script type="text/javascript" src="xinha/htmlarea.js"></script>
<script type="text/javascript">
/*var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'SpellChecker', 'Stylist', 'SuperClean', 'TableOperations', 'ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText', 'InsertSmiley', 'InsertAnchor', 'HorizontalRule', 'GetHtml', 'FullScreen', 'BackgroundImage','InsertWords','ListType'
 ];*/
 var xinha_plugins =
[
 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'Stylist', 'SuperClean','TableOperations','ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText',  'InsertAnchor','HtmlEntities','FullPage','ContextMenu'
];
/************************************************************************
 * Names of the textareas you will be turning into editors
 ************************************************************************/
var xinha_editors =
[
   'cat_desc1'
];
/************************************************************************
 * Initialisation function
 ************************************************************************/
function xinha_init()
{
  // THIS BIT OF JAVASCRIPT LOADS THE PLUGINS, NO TOUCHING  :)
  //var _editor_url  = document.location.href.replace(/xinha\*/, '');
 // alert(_editor_url);
  if(!HTMLArea.loadPlugins(xinha_plugins, xinha_init)) return;
  var xinha_config = new HTMLArea.Config();
    xinha_editors = HTMLArea.makeEditors(xinha_editors, xinha_config, xinha_plugins);
   //xinha_editors.cat_smdesc.config.width = '600px';
  // xinha_editors.cat_smdesc.config.height = '400px';
   xinha_editors.cat_desc.config.width = '500px';
   xinha_editors.cat_desc.config.height = '300px';
   //xinha_editors.cat_smdesc.config.statusBar = false;
   xinha_editors.cat_desc.config.statusBar = false;
   HTMLArea.startEditors(xinha_editors);
}
window.onload = xinha_init;
</script>
<script language="javascript" type="text/javascript" src="includes/scripts.js"></script>
<script language="javascript">
function delete1(uid){
	if(confirm("Are you sure want to delete?")){
		document.location.href = 'staticpages.php?del=1&uid='+uid;
	}
}
function open_window(img_name)
{
	url = "../images/categories/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}
function open_window1(img_name)
{
	url = "../images/"+img_name;
	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');
}

</script>
<script language="javascript">
	function changeaudio(f){//alert(f.value);
	if(f.value == 1){
		if(navigator.appName == "Microsoft Internet Explorer"){
			document.getElementById("cur_inscomp").style.display = "block";
		}else{
			document.getElementById("cur_inscomp").style.display = "table-row";
		}
	}else{
		document.getElementById("cur_inscomp").style.display = "none";
	}
  }

</script>
<link type="text/css" rel="stylesheet" title="xp-green" href="xinha/skins/xp-green/skin.css">
</head>
<?php 
///////////////////////////////single delete/////////////////////////////////
	$del=$_REQUEST['del'];
	$uid=$_REQUEST['uid'];
	if($del==1)
	{
			
			//delete_directory("../images/categories/".$name."/");

			$delete2=mysql_query("delete from nile_staticpages  where page_id='$uid'");
			header("location:staticpages.php?act=view");
			exit;
			
	}
///////////////////////////////////////multiple delete///////////////////////////
	$ok=$_REQUEST[ok];
	$colors=$_REQUEST['chk'];
	$chk1=$_REQUEST['chk1'];
	$number=count($colors);
	if($ok=='alldel')
	{
		foreach($colors as $chk1)
		{
			
			$delete2=mysql_query("delete from nile_staticpages  where page_id='$chk1'");
		}
		header("location:staticpages.php?act=view");
		exit;	
			
	}
//////////////////////////////end of multiple delete///////////////////////////////////	
$ok=$_REQUEST[ok];
//echo $ok;exit;
//////////////////////////////////////ADD////////////////////////////////////////////
if($ok==add)
{
	//echo "SELECT * FROM auc_categories WHERE listing_id='$listing_id' and name='$name'";exit;
	$selCat = mysql_query("SELECT * FROM nile_staticpages  WHERE page_name='$pagename'");
	//echo "SELECT * FROM nile_category WHERE cat_name='$catname'";exit;
	$num=mysql_num_rows($selCat);
	if($num<=0)
	{
			
		$sql=mysql_query("insert into nile_staticpages(page_name,page_desc,page_status) values('$pagename','$page_description',1)");
		
		/*echo "insert into nile_staticpages  (cat_id,item_name,item_address,item_audio,item_description,item_metakeyword,item_metadesc,status,date_added) values('$category','$itemname','$item_image','$item_audio','$item_desc','$item_metakeyword','$item_metadesc','$status',now())";exit;*/
		header("location:staticpages.php?act=view");
		exit;
	}
	else
	{
		header("location:staticpages.php?act=new&error=1");
		exit;
	}
	
}
//////////////////////////////////////update////////////////////////////////////////////
if($ok==edit)
{	
extract($_REQUEST);
		//echo $pagename;exit;
		$sql=mysql_query("select * from nile_staticpages  where page_name='$pagename' && page_id != $pagename");
		$row=mysql_fetch_array($sql);
		$cc=mysql_num_rows($sql);
		if($cc<=0)
		{	
		//echo "update nile_staticpages set page_desc='$page_desc',status='$status' where page_id='$pagename'";exit;
	$updsub=mysql_query("update nile_staticpages set page_desc='$page_description',status='$status' where page_id='$pagename'");
	header("location:staticpages.php?act=view");
	exit;
	}
	else
	{
		header("location:staticpages.php?act=view&error=1");
		exit;
	}
}
///////////////////paging////////////////////
$PageSize = 20;
$StartRow = 0;
if(empty($_GET['PageNo'])){
    if($StartRow == 0){
        $PageNo = $StartRow + 1;
    }
}else{
    $PageNo = $_GET['PageNo'];
    $StartRow = ($PageNo - 1) * $PageSize;
}

if($PageNo % $PageSize == 0){
    $CounterStart = $PageNo - ($PageSize - 1);
}else{
    $CounterStart = $PageNo - ($PageNo % $PageSize) + 1;
}
//Counter End
$CounterEnd = $CounterStart + ($PageSize - 1);
//////////////////end //////////////////////////////

	
	$TRecord=mysql_query("select * from nile_staticpages");
	$sql=mysql_query("select * from nile_staticpages LIMIT ". $StartRow .",". $PageSize."");


$RecordCount = mysql_num_rows($TRecord);
$MaxPage = $RecordCount % $PageSize;
if($RecordCount % $PageSize == 0){
    $MaxPage = $RecordCount / $PageSize;
 }
else{
    $MaxPage = ceil($RecordCount / $PageSize);
 }

$num=mysql_num_rows($sql);

?>


<body>
	<TABLE cellSpacing=0 cellPadding=0 width=96% align=center border="0">
	
	<tr>
	<td>
	
	          <!--VIEW USERS -->
			  <?php  if($act=="view"){?>
	<form name="formx1" method="post" enctype="multipart/form-data" id="formx1" >
	
<table width="100%">
	
	<tr>
		<td height="40" align="center" class="style13">&nbsp;<b class="greentext22bold">View Static Pages </b></td>
	</tr>
	<?php  if($num<=0){?>
		<tr>
			<td height="40" colspan="2" align="center" class="style14">
			<?php 
				header("Location:staticpages.php?act=new");
			?>
			</td>
		</tr>
	<?php  } else { ?>
					
					<tr class="txtblack3" >
					 <!-- <td height="10" align="right" class="normal" colspan="10" ><a href="staticpages.php?act=new" class="greentextbold">Add Page </a></td>-->
	  </tr>
					<tr class="txtblack3" >
					  <td height="10" align="center" class="normal" colspan="10" ><span class="style14">
					    <?php 
					  if($error==1)
					  {
					  	echo "Page already exists";
					  }
					  ?>
					  </span></td>
	  </tr>
					<tr class="txtblack3" >
					<td height="10" align="right" class="normal" colspan="10" ><b ><strong><font color="#FF0000">Page: <?php  echo $PageNo." of ". $MaxPage  ?></font></strong></b></td>
				</tr>
	
	<tr>
		<td colspan="2">
			<table width=59% border="0" align=center cellPadding=0 cellSpacing=0 frame="box" style="border-style:solid; border-width:1px; border-color:#999999" >
				<tr class="txtblack3" bgcolor="#FA9032" >
				  <td width="75" align="center" class="style12"><input type="checkbox" name="selall" onClick="checkstate('chk[]')" ></td>
				  <td width="279" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><b> Page Name </b></div></td>
					<td width="91" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Status</b></td>
				  <td width="91" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Edit</b></td>
			  </tr>
<?php  
 while($row=mysql_fetch_array($sql))
{ 
	
?>
				<tr style="background-color:#FFFFFF" onMouseOver="javascript:MouseOverMenu(this);" onMouseOut="javascript:MouseOutMenu(this);">
						<td align="center" class="style12"><input type="hidden" name="chk1[]"  id="chk1" value="<?php echo $row['page_id']; ?>"> 
   					  <input type="checkbox" name="chk[]"  id="chk" value="<?php  echo $row['page_id']; ?>" onClick="checkval('chk[]')"></td>
				
				    <td height="28" class="normal style12"><div align="center">
					  <?php echo $row['page_name']?>
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					    <?php  if($row['status']==1) { echo "Active"; } else { echo "In Active"; }?> 
				    </div></td>
					<td height="28" class="normal style12"><div align="center">
					  <a href="staticpages.php?act=edit&aid=<?php echo $row['page_id']?>"><img src="images/edit_f2.png" width="18" height="18" border="0"></a>
				    </div></td>

			  </tr><?php 
					}
					?>
		  </table>	  </td>
		  </tr><tr><td>&nbsp;</td></tr>
					<tr>
					  <td align="center"><img src="images/delete1.gif" onClick="javascript:document.formx1.action='staticpages.php?ok=alldel';document.formx1.submit();"><!--<input name="delete" type="button" class="greentextbold" onClick="javascript:document.formx1.action='staticpages.php?ok=alldel';document.formx1.submit();" value="Delete">--></td>
	  </tr>
					<tr>
					  <td align="right" class="normal">
					  <?php
      	//Print First & Previous Link is necessary
        if($CounterStart != 1){
            $PrevStart = $CounterStart - 1;
            print "<a href=staticpages.php?PageNo=1&act=view class=greenlink>First </a>: ";
            print "<a href=staticpages.php?PageNo=$PrevStart&act=view class=greenlink>Previous </a>";
        }
        print " <font color='red'><b> [ </b></font>";
        $c = 0;

        //Print Page No
        for($c=$CounterStart;$c<=$CounterEnd;$c++){
            if($c < $MaxPage){
                if($c == $PageNo){
                    if($c % $PageSize == 0){
                        print "$c ";
                    }else{
                        print "$c , ";
                    }
                }elseif($c % $PageSize == 0){
                    echo "<a href=staticpages.php?PageNo=$c&act=view class=greenlink>$c</a> ";
                }else{
                    echo "<a href=staticpages.php?PageNo=$c&act=view class=greenlink>$c</a> , ";
                }//END IF


            }else{
                if($PageNo == $MaxPage){
                    print "$c ";
                    break;
                }else{
                    echo "<a href=staticpages.php?PageNo=$c&act=view class=greenlink>$c</a> ";
                    break;
                }
            }
       }

      echo "<font color='red'><b> ]</b> </font> ";

      if($CounterEnd < $MaxPage){

          $NextPage = $CounterEnd + 1;
          echo "<a href=staticpages.php?PageNo=$NextPage&act=view class=greenlink>Next</a>";
      }
      
      //Print Last link if necessary
      if($CounterEnd < $MaxPage){
       $LastRec = $RecordCount % $PageSize;
        if($LastRec == 0){
            $LastStartRecord = $RecordCount - $PageSize;
        }
        else{
            $LastStartRecord = $RecordCount - $LastRec;
        }

        print " : ";
        echo "<a href=staticpages.php?PageNo=$MaxPage&act=view class=greenlink>Last</a>";
        }?></td>
	  </tr>
	
	</table></form>
	
	<?php 
		}}
	?>
	</td></tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr>
					  <td align="left">
					  
					  			<!--ADD and EDIT -->
					  <?php  
				  		
					  if($act=='new' || $act=='edit') {
					   if($act == 'edit'){
					$chn=mysql_query("select * from nile_staticpages where page_id='$aid'");
					$row=getSqlFetch($chn);
					}
					  ?>
					  <form name="formx1" method="post" enctype="multipart/form-data">
						<input type="hidden" name='idno' value="<?php echo $page_id?>">
						<input type="hidden" name='oldname' value="<?php echo $page_name?>">
					  <TABLE cellSpacing=0 cellPadding=0 width=100% align=center border="0">
                        <tr>
                          <td height="40" colspan="3" align="center" class="txtnolink">&nbsp;<b class="greentext22bold">
                            <?php 
							if($aid){
							?>
                            Edit Page Details
  <?php  }else {?>
                            Add Page Details
  <?php  }?>
                          </b></td>
                        </tr>
						<tr>
						<td colspan="3" align="center" class="style14">
						<?php 
						if($error==1)
						{
							echo "Page already Exists";
						}
						?>						</td>
						</tr>
                        <tr>
                          <td height="40" colspan="3" align="right" class="txtnolink"><a href="staticpages.php?act=view" class="greentextbold"><b>View Pages </b></a>&nbsp;</td>
                        </tr>
                        <TR>
                          <TD width="415" height="30" align="right" class="itemstyle">Page Name</TD>
                          <TD width="33" align="center">:</TD>
                          <TD width="472">
						  	<input type="hidden" name="pagename" value="<?php echo $row['page_id'] ?>"><strong style="font-size:14px"><?php echo $row['page_name'] ?></strong></TD>
                       </TR>
                          <TD height="30" align="right" class="itemstyle">Page Description</TD>
                          <TD align="center">:</TD>
                          <TD>
						  
						  <?php /*?><textarea name="page_desc" cols="25" rows="5" id="page_desc" style="width:173px"><?php echo stripslashes($row['page_desc'])?></textarea> <?php */?>                         
						  <?php
								$oFCKeditor = new FCKeditor('page_description') ; 
								$oFCKeditor->BasePath = 'FCKeditor/';
								$oFCKeditor->Value = $row['page_desc'];
								$oFCKeditor->Width  = '550' ;
								$oFCKeditor->Height = '400' ;
								$oFCKeditor->Create() ;
			 				?>  
						  </TD>
                        </TR>
                        <TR>
                          <TD height="30" align="right" class="itemstyle">Status</TD>
                          <TD align="center">:</TD>
                          <td align="left" class="normal"><input name="status" type="radio" value="1" checked />
                            Yes
                            <input name="status" type="radio" value="0" <?php  if( isset($row['status']) && $row['status'] == 0 ){ echo "checked";}?>>
                            No</td>
                        </TR>
                        <TR>
                          <TD height="60" colspan="3" align="center"><?php 
			if($aid){
			?>
                              <img src="images/update.gif"  onClick="javascript:return pages1();"><!--<input name="submit" type="submit" class="normal" onClick="javascript:return items1();" value='Update'>-->
                              <?php 
		} else {
		?>
                <img src="images/additems.gif"  onClick="javascript:return pages();"><!--<input name="submit" type="submit" class="normal" onClick="javascript:return items();" value='Add Categories'>-->
                            <?php  }?>
                            &nbsp;
                            <img src="images/cancel.gif" onClick="javascript:document.formx1.action='staticpages.php?act=view';document.formx1.submit();"><!--<input name="submit1" type="submit" class="normal" onClick="javascript:document.formx1.action='staticpages.php?act=view';document.formx1.submit();" value="Cancel">-->                          </TD>
                        </TR>
                        <TR>
                          <TD height="50" colspan="3">&nbsp;</TD>
                        </TR>
                      </TABLE>
					  <?php 
					  }
					  ?>
					  </form>
					 <!-- END ADD AND EDIT -->
					  
					  </td>
	  </tr>
					<tr>
					  <td align="center">&nbsp;</td>
	  </tr>
					<tr><td align="center">&nbsp;</td>
					</tr>
					
					</TABLE>

					</body>
					</html>
			