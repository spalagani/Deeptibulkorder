<?php
ob_start();
require_once('sessionchk.php');
include('../includes/dbconfig.php');

$ok=$_REQUEST['ok'];
$pname=$_REQUEST['pname'];
if($ok==1)
{
	
	
		echo("<SCRIPT>window.open ('".$pname.".php?act=view', 'main')</script>");
	

}
$sql=mysql_query("select * from nile_user where status=1");
$num=mysql_num_rows($sql);
?>
<html>
<head>
<link href="images/style.css" rel="stylesheet" type="text/css" />
</head>
<body topmargin=6 bgcolor='#F39542' bottommargin="3">
<form name='formx' method="post">
<table width="691" border=0 align=center cellpadding=0 cellspacing=0>
<tr>
	<td width="387" align='left' class='greentextbold1'>Logged in as <span class="style14"><? echo $_SESSION['userid'];?></span>	</td>

<td width="20" align="left"><a href="home.php" target="main"><img src="images/Home.gif" width="15" height="15" border="0" ></a></td>
<td width="33" align="left" ><a href="home.php" class="greenlink1" target="main">Home</a></td> 
<td width="5"></td>
<td width="8" ><a href="../index.php" target="_blank"></a></td>
<td width="21"><img src="images/users.png" width="18" height="18" border="0" ></td>

<td width="9" >&nbsp;</td>
<td width="19" align="left"><a href="logout.php" target="_top"><img src="images/logout.gif" width="16" height="16" border="0" ></a></td>
<td width="110" align="left" ><a href="logout.php" target="_top"></a><a href="logout.php" class="greenlink1" target="_top">Logout</a></td>
</tr>
</table>
</form>
</body>
</html>