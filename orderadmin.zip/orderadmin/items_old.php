<?php ob_start();

session_start();

include('sessionchk.php');

include('../includes/dbconfig.php');

include('../includes/constants.php');

include("FCKeditor/fckeditor.php");

extract($_REQUEST);

?>

<html>

<head>

<link href="images/style.css" rel="stylesheet" type="text/css" />

<script language="javascript" src='validation.js'></script>



<script type="text/javascript">

//var _editor_url  = document.location.href.replace(/examples\/simple_example\.html.*/, '')

// And the language we need to use in the editor.

var _editor_lang = "en";

//var _editor_url  = document.location.href.replace(/xinha\/xinha\*/, '')

var _editor_url = "xinha/";

</script>

<!-- Load up the actual editor core -->

<script type="text/javascript" src="xinha/htmlarea.js"></script>

<script type="text/javascript">

/*var xinha_plugins =

[

 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'SpellChecker', 'Stylist', 'SuperClean', 'TableOperations', 'ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText', 'InsertSmiley', 'InsertAnchor', 'HorizontalRule', 'GetHtml', 'FullScreen', 'BackgroundImage','InsertWords','ListType'

 ];*/

 var xinha_plugins =

[

 'CharacterMap', 'ContextMenu', 'FullScreen', 'ListType', 'Stylist', 'SuperClean','TableOperations','ImageManager', 'ExtendedFileManager', 'InsertPicture', 'Linker', 'PasteText',  'InsertAnchor','HtmlEntities','FullPage','ContextMenu'

];

/************************************************************************

 * Names of the textareas you will be turning into editors

 ************************************************************************/

var xinha_editors =

[

   'cat_desc1'

];

/************************************************************************

 * Initialisation function

 ************************************************************************/

function xinha_init()

{

  // THIS BIT OF JAVASCRIPT LOADS THE PLUGINS, NO TOUCHING  :)

  //var _editor_url  = document.location.href.replace(/xinha\*/, '');

 // alert(_editor_url);

  if(!HTMLArea.loadPlugins(xinha_plugins, xinha_init)) return;

  var xinha_config = new HTMLArea.Config();

    xinha_editors = HTMLArea.makeEditors(xinha_editors, xinha_config, xinha_plugins);

   //xinha_editors.cat_smdesc.config.width = '600px';

  // xinha_editors.cat_smdesc.config.height = '400px';

   xinha_editors.cat_desc.config.width = '500px';

   xinha_editors.cat_desc.config.height = '300px';

   //xinha_editors.cat_smdesc.config.statusBar = false;

   xinha_editors.cat_desc.config.statusBar = false;

   HTMLArea.startEditors(xinha_editors);

}

window.onload = xinha_init;

</script>

<script language="javascript" type="text/javascript" src="includes/scripts.js"></script>

<script language="javascript">

function delete1(uid){

	if(confirm("Are you sure want to delete?")){

		document.location.href = 'items.php?del=1&uid='+uid;

	}

}

function open_window(img_name)

{

	url = "../images/categories/"+img_name;

	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');

}

function open_window1(img_name)

{

	url = "../images/"+img_name;

	window.open(url,'MyWin','resizable=no,scrollbars=yes,width=200,height=200,left=400,top=250');

}

</script>

<script type="text/javascript">

function itemsorting()

{



var sortvalue=document.formx1.itemdisplay.value;

document.formx1.action='items.php?sortid='+sortvalue+'&act=view';

document.formx1.submit();

}





</script>

<script language="javascript">

//////////////////////// for states/////////////////////

function category1()

{



document.formx1.subcategory.options.length=1;

cid=document.formx1.category.value;

var a=0;

<?php $selSub = mysql_query("SELECT * FROM nile_sub_category WHERE status=1" );

						 $num1=mysql_num_rows($selSub);

							while($data1=mysql_fetch_array($selSub)) { ?>

							

						

if( cid == '<?php echo$data1[cat_id]?>') {

a++;

document.formx1.subcategory.options.length=document.formx1.subcategory.options.length+1;

document.formx1.subcategory.options[a].text='<?php echo$data1[sub_cat_name]?>';

document.formx1.subcategory.options[a].value='<?php echo$data1[sub_cat_id]?>';

}

<?php } ?>

}







function extrafield(){



var a=document.formx1.category.value;



		if(navigator.appName == "Microsoft Internet Explorer"){

			if((a == '<?php echo $degree?>') ||  (a == '<?php echo $degreetestpapers?>'))

				{

				document.getElementById("univer").style.display = "block";

				 document.getElementById("type").style.display = "none";

				} 

			else if((a == '<?php echo $intermediate?>') || ( a == '<?php echo $school?>'))

				{

				document.getElementById("type").style.display = "block";

				document.getElementById("univer").style.display = "none";

				}

			else

			   {

			   document.getElementById("univer").style.display = "none";

			   document.getElementById("type").style.display = "none";

			   }

		}

		else

		{

			if(a == '<?php echo $degree?>') 

				{

				document.getElementById("univer").style.display = "table-row";

				 document.getElementById("type").style.display = "none";

				} 

			else if((a == '<?php echo $intermediate?>') || ( a == '<?php echo $school?>'))

				{

				document.getElementById("type").style.display = "table-row";

				document.getElementById("univer").style.display = "none";

				}

			else

			   {

			   document.getElementById("univer").style.display = "none";

			   document.getElementById("type").style.display = "none";

			   }

		

		}

}



</script>



<link type="text/css" rel="stylesheet" title="xp-green" href="xinha/skins/xp-green/skin.css">

</head>

<?php ///////////////////////////////single delete/////////////////////////////////

	$del=$_REQUEST['del'];

	$uid=$_REQUEST['uid'];

	if($del==1)

	{

			

			//delete_directory("../images/categories/".$name."/");



			$delete2=mysql_query("delete from nile_items where item_id='$uid'");

			header("location:items.php?act=view");

			exit;

			

	}

///////////////////////////////////////multiple delete///////////////////////////

	$ok=$_REQUEST[ok];

	$colors=$_REQUEST['chk'];

	$chk1=$_REQUEST['chk1'];

	$number=count($colors);

	if($ok=='alldel')

	{

		foreach($colors as $chk1)

		{

			

			$delete2=mysql_query("delete from nile_items where item_id='$chk1'");

		}

		header("location:items.php?act=view");

		exit;	

			

	}

//////////////////////////////end of multiple delete///////////////////////////////////	

$ok=$_REQUEST[ok];

//echo $ok;exit;

//////////////////////////////////////ADD////////////////////////////////////////////

if($ok==add)

{

	//echo "SELECT * FROM auc_categories WHERE listing_id='$listing_id' and name='$name'";exit;

	$selCat = mysql_query("SELECT * FROM nile_items WHERE item_name='$itemname' And cat_type='1'");

	//echo "SELECT * FROM nile_category WHERE cat_name='$catname'";exit;

	$num=mysql_num_rows($selCat);

	if($num<=0)

	{

			$item_image = $_FILES['file']['name'];

			uploadFile($_FILES['file']['tmp_name'],'../images/pictures/'.$item_image);

			

			/************************************Resizing the image 209x178****************/

			if($item_image<>'')

			{

			$path="../images/pictures/";

			$filetype=$_FILES['file']['type'];

			$bgim_file_name = $path."/".$item_image; 

			

			$bgimage_attribs = getimagesize($bgim_file_name);

			

			

			if($filetype=='image/gif')	{

				$bgim_old = imagecreatefromgif($bgim_file_name); 

			}	

			else	{

				 $bgim_old = imagecreatefromjpeg($bgim_file_name);

			}

						

			$bgth_max_width = 100; //for Album image

			$bgth_max_height = 70;

			$bgratio = ($bgwidth > $bgheight) ? $bgth_max_width/$bgimage_attribs[0] : $bgth_max_height/$bgimage_attribs[1];

		

			$bgth_width = 100;//$image_attribs[0] * $ratio; 

			$bgth_height = 70;//$image_attribs[1] * $ratio;

		

			$bgim_new = imagecreatetruecolor($bgth_width,$bgth_height); 

			imageantialias($bgim_new,true); 

			 $bgth_file_name = "../images/thumbnail/$item_image";

						 

			imagecopyresampled($bgim_new,$bgim_old,0,0,0,0,$bgth_width,$bgth_height, $bgimage_attribs[0], $bgimage_attribs[1]);

		

			if($filetype=='image/gif')	{									

				imagegif($bgim_new,$bgth_file_name,100); 

			}	else	{

				imagejpeg($bgim_new,$bgth_file_name,100);

			}}

			////////////////////////////////////////end resize/////////////////////////////////////

			

			/************************************Resizing the image 209x178****************/

	

				if($item_image<>'')

			{

			$path1="../images/pictures/";

			$filetype1=$_FILES['file']['type'];

			$bgim_file_name1 = $path."/".$item_image; 

			

			$bgimage_attribs1 = getimagesize($bgim_file_name1);

			

			

			if($filetype1=='image/gif')	{

				$bgim_old1 = imagecreatefromgif($bgim_file_name1); 

			}	

			else	{

				 $bgim_old1 = imagecreatefromjpeg($bgim_file_name1);

			}

						

			$bgth_max_width1 = 400; //for Album image

			$bgth_max_height1 = 300;

			$bgratio1 = ($bgwidth1 > $bgheight1) ? $bgth_max_width1/$bgimage_attribs1[0] : $bgth_max_height1/$bgimage_attribs1[1];

		

			$bgth_width1 = 400;//$image_attribs[0] * $ratio; 

			$bgth_height1 = 300;//$image_attribs[1] * $ratio;

		

			$bgim_new1 = imagecreatetruecolor($bgth_width1,$bgth_height1); 

			imageantialias($bgim_new1,true); 

			 $bgth_file_name1 = "../images/medium/$item_image";

						 

			imagecopyresampled($bgim_new1,$bgim_old1,0,0,0,0,$bgth_width1,$bgth_height1, $bgimage_attribs1[0], $bgimage_attribs1[1]);

		

			if($filetype1=='image/gif')	{									

				imagegif($bgim_new1,$bgth_file_name1,100); 

			}	else	{

				imagejpeg($bgim_new1,$bgth_file_name1,100);

			}}

			////////////////////////////////////////end resize/////////////////////////////////////

		

						

						

		$sql=mysql_query("insert into nile_items (cat_id,sub_cat_id,univercity,type,item_name,item_address,item_shortdesc,item_description,old_price,new_price,date_added,status) values('$category','$subcategory','$universe','$types','$itemname','$item_image','$sdesc','$item_desc','$old_price','$new_price',now(),'$status')");

		

		

		header("location:items.php?act=view");

		exit;

	}

	else

	{

		header("location:items.php?act=new&error=1");

		exit;

	}

	

}

//////////////////////////////////////update////////////////////////////////////////////

if($ok==edit)

{	

extract($_REQUEST);

		

		//echo $have_hins;

		$sql_filetype=mysql_query("select * from nile_items where item_id ='$idno'");

		$row_filetype=mysql_fetch_array($sql_filetype);

		

	

		$sql=mysql_query("select * from nile_items item_id !='$idno'");

		$row=mysql_fetch_array($sql);

		$cc=mysql_num_rows($sql);

		if($cc<=0)

		{	

				$item_edit_image = $_FILES['file']['name'];

				if($item_edit_image!="")

				{

				uploadFile($_FILES['file']['tmp_name'],'../images/pictures/'.$item_edit_image);

				/************************************Resizing the image 209x178****************/

			if($item_edit_image<>'')

			{

			$path="../images/pictures/";

			$filetype=$_FILES['file']['type'];

			$bgim_file_name = $path."/".$item_edit_image; 

			

			$bgimage_attribs = getimagesize($bgim_file_name);

			

			

			if($filetype=='image/gif')	{

				$bgim_old = imagecreatefromgif($bgim_file_name); 

			}	

			else	{

				 $bgim_old = imagecreatefromjpeg($bgim_file_name);

			}

						

			$bgth_max_width = 100; //for Album image

			$bgth_max_height = 70;

			$bgratio = ($bgwidth > $bgheight) ? $bgth_max_width/$bgimage_attribs[0] : $bgth_max_height/$bgimage_attribs[1];

		

			$bgth_width = 100;//$image_attribs[0] * $ratio; 

			$bgth_height = 70;//$image_attribs[1] * $ratio;

		

			$bgim_new = imagecreatetruecolor($bgth_width,$bgth_height); 

			imageantialias($bgim_new,true); 

			 $bgth_file_name = "../images/thumbnail/$item_edit_image";

						 

			imagecopyresampled($bgim_new,$bgim_old,0,0,0,0,$bgth_width,$bgth_height, $bgimage_attribs[0], $bgimage_attribs[1]);

		

			if($filetype=='image/gif')	{									

				imagegif($bgim_new,$bgth_file_name,100); 

			}	else	{

				imagejpeg($bgim_new,$bgth_file_name,100);

			}}

			////////////////////////////////////////end resize/////////////////////////////////////

			

			/************************************Resizing the image 209x178****************/

	

				if($item_edit_image<>'')

			{

			$path1="../images/pictures/";

			$filetype1=$_FILES['file']['type'];

			$bgim_file_name1 = $path."/".$item_edit_image; 

			

			$bgimage_attribs1 = getimagesize($bgim_file_name1);

			

			

			if($filetype1=='image/gif')	{

				$bgim_old1 = imagecreatefromgif($bgim_file_name1); 

			}	

			else	{

				 $bgim_old1 = imagecreatefromjpeg($bgim_file_name1);

			}

						

			$bgth_max_width1 = 400; //for Album image

			$bgth_max_height1 = 300;

			$bgratio1 = ($bgwidth1 > $bgheight1) ? $bgth_max_width1/$bgimage_attribs1[0] : $bgth_max_height1/$bgimage_attribs1[1];

		

			$bgth_width1 = 400;//$image_attribs[0] * $ratio; 

			$bgth_height1 = 300;//$image_attribs[1] * $ratio;

		

			$bgim_new1 = imagecreatetruecolor($bgth_width1,$bgth_height1); 

			imageantialias($bgim_new1,true); 

			 $bgth_file_name1 = "../images/medium/$item_edit_image";

						 

			imagecopyresampled($bgim_new1,$bgim_old1,0,0,0,0,$bgth_width1,$bgth_height1, $bgimage_attribs1[0], $bgimage_attribs1[1]);

		

			if($filetype1=='image/gif')	{									

				imagegif($bgim_new1,$bgth_file_name1,100); 

			}	else	{

				imagejpeg($bgim_new1,$bgth_file_name1,100);

			}}

			////////////////////////////////////////end resize/////////////////////////////////////

			

				}

				else 

				{

				$item_edit_image = $lastfile;

				}

				

			

				

	$updsub=mysql_query("update nile_items set cat_id='$category',sub_cat_id='$subcategory',univercity='$universe',type='$types',item_name='$itemname',item_address='$item_edit_image',item_shortdesc='$sdesc',item_description='$item_desc',old_price='$old_price',new_price='$new_price',date_added=now(),status='$status' where item_id='$idno'");

	//$id="a_".$idno;

		

	header("location:items.php?act=view");

	exit;

	}

	else

	{

		header("location:items.php?act=view&error=1");

		exit;

	}

}

///////////////////paging////////////////////

$PageSize = 20;

$StartRow = 0;

if(empty($_GET['PageNo'])){

    if($StartRow == 0){

        $PageNo = $StartRow + 1;

    }

}else{

    $PageNo = $_GET['PageNo'];

    $StartRow = ($PageNo - 1) * $PageSize;

}



if($PageNo % $PageSize == 0){

    $CounterStart = $PageNo - ($PageSize - 1);

}else{

    $CounterStart = $PageNo - ($PageNo % $PageSize) + 1;

}

//Counter End

$CounterEnd = $CounterStart + ($PageSize - 1);

//////////////////end //////////////////////////////



	

	$TRecord=mysql_query("select * from nile_items order by date_added desc");

	$sql=mysql_query("select * from nile_items order by date_added  desc LIMIT ". $StartRow .",". $PageSize."");





$RecordCount = mysql_num_rows($TRecord);

$MaxPage = $RecordCount % $PageSize;

if($RecordCount % $PageSize == 0){

    $MaxPage = $RecordCount / $PageSize;

 }

else{

    $MaxPage = ceil($RecordCount / $PageSize);

 }



$num=mysql_num_rows($sql);



if(($_REQUEST['sortid']<>''))

{

$act=$_REQUEST['act'];

 $sid=$_REQUEST['sortid'];

 

$TRecord=mysql_query("select * from nile_items where  cat_id='$sid' order by date_added desc");

	$sql=mysql_query("select * from nile_items where  cat_id='$sid' order by date_added desc LIMIT ". $StartRow .",". $PageSize."");





 $RecordCount = mysql_num_rows($TRecord);

$MaxPage = $RecordCount % $PageSize;

if($RecordCount % $PageSize == 0){

    $MaxPage = $RecordCount / $PageSize;

 }

else{

    $MaxPage = ceil($RecordCount / $PageSize);

 }



 $num=mysql_num_rows($sql);



}



?>





<body onLoad="extrafield()">

	<TABLE cellSpacing=0 cellPadding=0 width=96% align=center border="0">

	

	<tr>

	<td>

	

	          <!--VIEW USERS -->

			  <?php if($act=="view"){?>

	<form name="formx1" method="post" enctype="multipart/form-data" id="formx1" >

	

<table width="100%" border="0">

	

	<tr>

		<td height="40" align="center" class="style13" colspan="3">&nbsp;<b class="greentext22bold" >View Items </b></td>

	</tr>

	<?php if($num<=0){?>

		<tr>

			<td height="40" colspan="2" align="center" class="style1">

			<?php echo "Item Does not exists";

				

				

				//header("Location:nileinfo_items.php?act=new");

			?>

			

			<a href="#" onClick="javascript:history.go(-1);" class="greenlink">Go Back</a>&nbsp;&nbsp;&nbsp;	<a href="items.php?act=new" class="greentextbold">Add Books </a>		</td>

		</tr>

	<?php } else { ?>

					<?php $cat1=mysql_query("Select * from nile_category where status='1'");

						

						?>

						

					<tr class="txtblack3" >

					

					<td  width="91%" align="center">

					

					  <select name="itemdisplay" onChange="itemsorting()">

					<option value="">Select Item category</option>

					<?php while ($values=mysql_fetch_array($cat1)){?>

					<option value="<?php echo$values['cat_id']?>" <?php if($sortid==$values['cat_id']){ ?> selected <?php } ?>><?php echo$values['cat_name']?></option>

					<?php } ?>

					</select>

					

					</td>

					  <td width="9%" height="10" colspan="10" align="right" class="normal" ><a href="items.php?act=new" class="greentextbold">Add Book</a></td>

	  </tr>

					<tr class="txtblack3" >

					  <td height="10" align="center" class="normal" colspan="10" ><span class="style14">

					    <?php if($error==1)

					  {

					  	echo "Item already exists";

					  }

					  ?>

					  </span></td>

	  </tr>

					<tr class="txtblack3" >

					<td height="10" align="right" class="normal" colspan="10" ><b ><strong><font color="#FF0000">Page: <?php echo $PageNo." of ". $MaxPage  ?></font></strong></b></td>

				</tr>

	

	<tr>

		<td colspan="2" align="center" valign="middle">

			<table width=100% border="0" align=center cellPadding=0 cellSpacing=0 frame="box" style="border-style:solid; border-width:1px; border-color:#999999" >

				<tr class="txtblack3" bgcolor="#FA9032" >

				  <td width="46" align="center" class="style12"><input type="checkbox" name="selall" onClick="checkstate('chk[]')" ></td>

				  <td width="196" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><b> Item Name </b></div></td>

				  <td width="111" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><b> Image</b></div></td>

			      <td width="168" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><b>Category</b></div></td>

				  <td width="235" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><b>Sub Category</b></div></td>

				  <td width="88" height="31" bgcolor="#FA9032" class="style12" ><div align="center" class="itemstyle"><b>Status</b></div></td>

				  <td width="49" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Edit</b></td>

					<td width="61" align="center" bgcolor="#FA9032" class="style12"><b class="itemstyle">Delete</b></td>

			  </tr>

<?php while($row=mysql_fetch_array($sql))

{ 

	

?>

				<tr style="background-color:#FFFFFF" onMouseOver="javascript:MouseOverMenu(this);" onMouseOut="javascript:MouseOutMenu(this);">

						<td align="center" class="style12"><input type="hidden" name="chk1[]"  id="chk1" value="<?php echo$row['item_id']; ?>"> 

   					  <input type="checkbox" name="chk[]"  id="chk" value="<?php echo $row['item_id']; ?>" onClick="checkval('chk[]')"></td>

				

				    <td height="28" class="normal style12"><div align="center">

					  <?php echo$row['item_name']?>

				    </div></td>

					<td height="28" class="normal style12"><div align="center">

					  <img src="../images/pictures/<?php echo$row['item_address']?>" width="110" height="95" border="0">

				    </div></td>

					<?php $cat=mysql_query("Select * from nile_category where cat_id='".$row['cat_id']."'");

						$rowcat=mysql_fetch_array($cat);

					?>

					 <td height="28" class="normal style12"><div align="center">

					  <?php echo$rowcat['cat_name']?>

				    </div></td>

                    <?php $cat1=mysql_query("Select * from nile_sub_category where sub_cat_id='".$row['sub_cat_id']."'");

						$rowcat1=mysql_fetch_array($cat1);

					?>

					 <td class="normal style12"><div align="center">

                       <?php echo$rowcat1['sub_cat_name']?>

                     </div></td>

				    <td height="28" class="normal style12"><div align="center">

					  <?php if($row['status']==1) { ?>Active<?php } else { ?>Inactive<?php } ?>

				    </div></td>

					<td height="28" class="normal style12"><div align="center">

					  <a href="items.php?act=edit&aid=<?php echo$row['item_id']?>"><img src="images/edit_f2.png" width="18" height="18" border="0"></a>

				    </div></td>

					<td height="28" class="normal style12"><div align="center">

					   <a href="javascript:delete1(<?php echo$row['item_id']?>)">

					   <img src="images/delete.png" width="18" height="18" border="0"></a>

				    </div></td>

			  </tr><?php }

					?>

		  </table>	  </td>

		  </tr><tr><td colspan="2">&nbsp;</td></tr>

					<tr>

					  <td align="center" colspan="2"><img src="images/delete1.gif" onClick="javascript:document.formx1.action='items.php?ok=alldel';document.formx1.submit();"><!--<input name="delete" type="button" class="greentextbold" onClick="javascript:document.formx1.action='items.php?ok=alldel';document.formx1.submit();" value="Delete">--></td>

	  </tr>

					<tr>

					  <td align="right" class="normal" colspan="2">

					  <?php

      	//Print First & Previous Link is necessary

        if($CounterStart != 1){

            $PrevStart = $CounterStart - 1;

            print "<a href=items.php?PageNo=1&sortid=$sortid&act=view class=greenlink>First </a>: ";

            print "<a href=items.php?PageNo=1&sortid=$sortid&act=view class=greenlink>Previous </a>";

        }

        print " <font color='red'><b> [ </b></font>";

        $c = 0;



        //Print Page No

        for($c=$CounterStart;$c<=$CounterEnd;$c++){

            if($c < $MaxPage){

                if($c == $PageNo){

                    if($c % $PageSize == 0){

                        print "$c ";

                    }else{

                        print "$c , ";

                    }

                }elseif($c % $PageSize == 0){

                    echo "<a href=items.php?PageNo=$c&sortid=$sortid&act=view class=greenlink>$c</a> ";

                }else{

                    echo "<a href=items.php?PageNo=$c&sortid=$sortid&act=view class=greenlink>$c</a> , ";

                }//END IF





            }else{

                if($PageNo == $MaxPage){

                    print "$c ";

                    break;

                }else{

                    echo "<a href=items.php?PageNo=$c&sortid=$sortid&act=view class=greenlink>$c</a> ";

                    break;

                }

            }

       }



      echo "<font color='red'><b> ]</b> </font> ";



      if($CounterEnd < $MaxPage){



          $NextPage = $CounterEnd + 1;

          echo "<a href=items.php?PageNo=$NextPage&sortid=$sortid&act=view class=greenlink>Next</a>";

      }

      

      //Print Last link if necessary

      if($CounterEnd < $MaxPage){

       $LastRec = $RecordCount % $PageSize;

        if($LastRec == 0){

            $LastStartRecord = $RecordCount - $PageSize;

        }

        else{

            $LastStartRecord = $RecordCount - $LastRec;

        }



        print " : ";

        echo "<a href=items.php?PageNo=$MaxPage&sortid=$sortid&act=view class=greenlink>Last</a>";

        }?></td>

	  </tr>

	

	</table></form>

	

	<?php }}

	?>

	</td></tr>

					<tr>

					  <td align="center">&nbsp;</td>

	  </tr>

					<tr>

					  <td align="left">

					  

					  			<!--ADD and EDIT -->

					  <?php if($act=='new' || $act=='edit') {

					   if($act == 'edit'){

					$chn=mysql_query("select * from nile_items where item_id='$aid'");

					$row=getSqlFetch($chn);

					extract($row);

					$selcat=mysql_query("select * from nile_category where cat_id='$row[cat_id]'");

					$res=mysql_fetch_array($selcat);

					}

					  ?>

					  <form name="formx1" method="post" enctype="multipart/form-data">

						<input type="hidden" name='idno' value="<?php echo $item_id?>">

						<input type="hidden" name='oldname' value="<?php echo $item_name?>">

					  <TABLE cellSpacing=0 cellPadding=0 width=100% align=center border="0">

                        <tr>

                          <td height="40" colspan="3" align="center" class="txtnolink">&nbsp;<b class="greentext22bold">

                            <?php if($aid){

							?>

                            Edit Items Details

  <?php }else {?>

                            Add Items Details

  <?php }?>

                          </b></td>

                        </tr>

						<tr>

						<td colspan="3" align="center" class="style14">

						<?php if($error==1)

						{

							echo "Category already Exists";

						}

						?>						</td>

						</tr>

                        <tr>

                          <td height="40" colspan="3" align="right" class="txtnolink"><a href="items.php?act=view" class="greentextbold"><b>View Books </b></a>&nbsp;</td>

                        </tr>

						

						<?php

							$selcat=mysql_query("select * from nile_category where status=1"); 

						?>

						 <TR>

                          <TD width="415" height="30" align="right" class="itemstyle">Select Category</TD>

                          <TD width="33" align="center">:</TD>	

                          <TD width="472"><select name="category" onChange="category1(),extrafield()">

                                        <option value="">Select</option>

						  				<?php while($retcat=mysql_fetch_array($selcat)) { ?>

										<option value="<?php echo$retcat['cat_id']?>" <?php if($retcat['cat_id'] == $cat_id){ ?> selected <?php } ?>>

										<?php echo$retcat['cat_name']?>										</option>

										<?php } ?>

						  				</select>						 </TD>

                        </TR>

						<TR >

                          <TD width="415" height="30" align="right" class="itemstyle">Select Sub Category</TD>

                          <TD width="33" align="center">:</TD>

                          <TD width="472"><select name="subcategory" id="subcategory" >

											 <option value="">select</option> 

                  	                			  <?php 

												  $sta=mysql_query("select * from nile_sub_category where cat_id='$cat_id'");

													while($stat=mysql_fetch_array($sta)) { 

													?>

                                                  

														  <option value="<?php echo$stat[sub_cat_id]?>" <?php if($stat[sub_cat_id]== $sub_cat_id) { ?> selected="selected" <?php } ?>><?php echo$stat[sub_cat_name]?></option>

														  <?php } ?>

											</select></TD>

                        </TR>

						

                        

						 <TR style="display:none;" id="univer">

						

						  <TD height="30" align="right" class="itemstyle">Univercity</TD>

						  <TD align="center">:</TD>

						  <TD><select name="universe" id="select" >

                            <option value="">select</option>

                           <?php foreach($uni_array as $key) { ?>

						   <option value="<?php echo $key?>" <?php if($univercity== $key) { ?> selected="selected" <?php } ?>><?php echo $key?></option>

                            <?php } ?>

                          </select></TD>

					    </TR>

						

						<TR style="display:none;" id="type">

						  <TD height="30" align="right" class="itemstyle">Type of book </TD>

						  <TD align="center">:</TD>

						  <TD><select name="types" id="select" >

                            <option value="">select</option>

                           <?php foreach($typ_array as $key1) { ?>

						   <option value="<?php echo $key1?>" <?php if($type == $key1) { ?> selected="selected" <?php } ?>><?php echo $key1?></option>

                            <?php } ?>

                          </select></TD>

					    </TR>

						<TR>

                          <TD height="30" align="right" class="itemstyle">Items Name</TD>

						  <TD align="center">:</TD>

						  <TD><input name="itemname" id="itemname2" value="<?php echo$item_name?>" size=25></TD>

					    </TR>

						<TR>

                          <TD width="415" height="30" align="right" class="itemstyle">Upload Image</TD>

                          <TD width="33" align="center">:</TD>

                          <TD width="472"><input name="file" type="file" id="file" size=25></TD>

                        </TR>

						 <?php if(isset($aid) && $act=='edit'){ ?>

						<TR>

                          <TD width="415" height="30" align="right" class="itemstyle">&nbsp;</TD>

                          <TD width="33" align="center"></TD>

                          <TD width="472"><input name="lastfile" type="hidden" id="file" value="<?php echo$item_address?>" size=25><img src="../images/thumbnail/<?php echo$item_address?>" width="100" height="70" border="0">&nbsp;<?php echo$item_address?></TD>

                        </TR>

                        <?php }?>

						

					    <?php if($act == 'edit'){?>



						

						<?php }?>

						<TR>

                          <TD width="415" height="30" align="right" class="itemstyle">Short description</TD>

                          <TD width="33" align="center">:</TD>	

                          <TD width="472"><textarea name="sdesc" id="sdesc" cols="45" rows="5"><?php echo$item_shortdesc?></textarea>                          </TD>

                        </TR>

                        <TR>	

                          <TD height="30" align="right" class="itemstyle">Description</TD>

                          <TD align="center">:</TD>

                          <TD><?php /*?><textarea name="item_desc" cols="25" rows="5" id="item_desc" style="width:173px"><?php echostripslashes($item_description)?></textarea><?php */?> 

						  <?php

								$oFCKeditor = new FCKeditor('item_desc') ; 

								$oFCKeditor->BasePath = 'FCKeditor/';

								$oFCKeditor->Value = $item_description;

								$oFCKeditor->Width  = '550' ;

								$oFCKeditor->Height = '400' ;

								$oFCKeditor->Create() ;

			 				?>                         </TD>

                        </TR>

						 



						<TR >

                          <TD width="415" height="30" align="right" class="itemstyle">Stock Avaliable </TD>

                          <TD width="33" align="center">:</TD>

                          <TD width="472"><input name="old_price" id="old_price" value="<?php echo$old_price?>" size=25></TD>

                        </TR>

                        

						<TR>

						  <TD height="30" align="right" class="itemstyle">New Price </TD>

						  <TD align="center">:</TD>

						  <td align="left" class="normal"><input name="new_price" id="new_price" value="<?php echo$new_price?>" size=25></td>

					    </TR>

						<TR>

                          <TD height="30" align="right" class="itemstyle">Status</TD>

                          <TD align="center">:</TD>

                          <td align="left" class="normal"><input name="status" type="radio" value="1" checked />

                            Yes

                            <input name="status" type="radio" value="0" <?php if( isset($status) && $status == 0 ){ echo "checked";}?>>

                            No</td>

                        </TR>

                        <TR>

                          <TD height="60" colspan="3" align="center"><?php if($aid){

			?>

                              <img src="images/update.gif"  onClick="javascript:return items1();"><!--<input name="submit" type="submit" class="normal" onClick="javascript:return items1();" value='Update'>-->

                              <?php } else {

		?>

                <img src="images/additems.gif"  onClick="javascript:return items();"><!--<input name="submit" type="submit" class="normal" onClick="javascript:return items();" value='Add Categories'>-->

                            <?php }?>

                            &nbsp;

                            <img src="images/cancel.gif" onClick="javascript:document.formx1.action='items.php?act=view';document.formx1.submit();"><!--<input name="submit1" type="submit" class="normal" onClick="javascript:document.formx1.action='items.php?act=view';document.formx1.submit();" value="Cancel">-->                          </TD>

                        </TR>

                        <TR>

                          <TD height="50" colspan="3">&nbsp;</TD>

                        </TR>

                      </TABLE>

					  <?php }

					  ?>

					  </form>

					 <!-- END ADD AND EDIT -->

					  

					  </td>

	  </tr>

					<tr>

					  <td align="center">&nbsp;</td>

	  </tr>

					<tr><td align="center">&nbsp;</td>

					</tr>

					

					</TABLE>



					</body>

					</html>

			