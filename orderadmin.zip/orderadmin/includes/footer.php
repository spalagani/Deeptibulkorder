<table width="594" border="0" cellspacing="2" cellpadding="2">
      
      <tr>
        <td colspan="8" align="center" valign="middle" class="copy-txt"><table width="660" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td width="64" align="left"><a href="aboutus.php" class="footer">About us</a> </td>
            <td width="97" align="left"> <a href="login.php" class="footer">Register/ Sign in</a></td>
            <td width="47" align="left"><a href="faq.php" class="footer">FAQ&rsquo;s </a></td>
            <td width="101" align="left"><a href="prwinners.php" class="footer">Previous Winners</a></td>
            <td width="67" align="left"> <a href="contactus.php" class="footer">Contact Us </a></td>
            <td width="54" align="left"><a href="site.php" class="footer">Site Map</a></td>
            <td width="96" align="left"><a href="terms.php" class="footer">Terms of Service</a></td>
            <td width="73" align="left"><a href="privacy.php" class="footer">Privacy Policy</a></td>
            <td width="61" align="left"><a href="http://www.privacybot.com" target="_blank"><img src="images/pbseal.gif" width="100" height="25" border="0" /></a></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="544" colspan="8" align="center" valign="middle" class="copy-txt">Copy right  &copy; 2007 The Greater Fool Auction Co. Inc.</td>
  </tr>
    </table>