function showdiv(id){
	d=document.getElementById(id);
	d.className="divopen";
}

function hidediv(id){
	d=document.getElementById(id);
	d.className="divclosed";
}

function doSpouseQuote(el, div){
	if(el.selectedIndex==2){
		showdiv(div);
	}else{
		hidediv(div);
	}
}

function doPregnant(el, div){
	if(el.selectedIndex==2){
		showdiv(div);
	}else{
		hidediv(div);
	}
}

function doAdditional(el)
{
	if(el.selectedIndex>0){
		for(i=1; i<=el.selectedIndex; i++){
			showdiv("add"+i);
			showdiv("med"+i);
		}
	}
	
	for(i=el.selectedIndex+1; i<=5; i++){
		hidediv("add"+i);
		hidediv("med"+i);
	}
}


function doFname(el, nr){
	val=el.value;
	addel=document.getElementById("medfname"+nr);
	addel.value=val;
	
}
function doFname1(el, nr){
	val=el.value;
	addel="medfname"+nr;
    alert(document.insurance.addel.value);
	
}

function doLname(el){
	val=el.value;
	for(i=0; i<=4; i++){
		addel=document.getElementById("medlname"+i);
		addel.value=val;
	}
}