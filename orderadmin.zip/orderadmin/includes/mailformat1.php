<?php
$message = '
<table width="80%" border="0" cellspacing="0" cellpadding="0">
     <tr>
        <td height="6" colspan="2" align="center" valign="top"><table width="90%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center" valign="top" bgcolor="#828EB1"><table width="100%" border="0" cellspacing="1" cellpadding="2">
                  <tr><td height="60" background="images/header_01.jpg">
<table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/header_02.jpg">
  <tr>
    <td width="33%"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="90%">
	<!--	<img src="images/logo.gif" />-->
		<img src="images/logo_1191918845.gif" />
		</td>
      </tr>
    </table></td>
    <td width="47%">&nbsp;</td>
    <td width="20%" align="left" valign="middle"><div align="center"> <br />
   .</div></td>
  </tr></table></td></tr>
				  <tr>
                    <td colspan="2" align="center" bgcolor="#FFFFFF"><strong>Welcome to Nileriver<em>!</em></strong></td>
                  </tr>
				  <tr>
                	<td bgcolor="#FFFFFF">echo $news_desc</td>
              	</tr>
				  
				  <tr>
                    <td width="41%" align="center" valign="middle" bgcolor="#FFFFFF" class="subheading1">&nbsp;</td>
                  </tr>

                  <tr>
                    <td colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" class="subheading1"><table width="100%" border="0" cellspacing="2" cellpadding="0">
                      <tr>
                        <td width="89%">&nbsp;</td>
                        <td width="11%" align="left" valign="middle">&nbsp;</td>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
            </tr>
          </table>
            <br />
            <br />
            <table width="90%" border="0" cellspacing="0" cellpadding="0">
              
            </table>
			
			<br><br>
          <br />
            <br />
           
  <tr>
        <td height="6" colspan="3" align="left" valign="top"><img src="images/spacer.gif" width="1" height="1" /></td>
  </tr>
	  </form>
    </table>';
	?>