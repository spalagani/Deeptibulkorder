<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

//-->
</script>
<link href="../images/style.css" rel="stylesheet" type="text/css">
<script type="text/JavaScript">
<!--

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('images/myaccount_but_over.jpg','images/register_but_over.jpg','images/aboutus_but_over.jpg')">
<table width="177" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td align="center" valign="top"><table width="177" border="0" cellspacing="0" cellpadding="0">
				<?
					if($_SESSION['user_id']){
				?>
                  <tr>
                    <td height="10"></td>
                  </tr>
                  <tr>
                    <td height="10"><table width="177" border="0" align="center" cellpadding="0" cellspacing="0" class="buttonbg">
                      <tr>
                        <td width="18" align="right"><img src="images/orange_bullet.gif" width="5" height="5" /></td>
                        <td width="12"></td>
                        <td width="128" height="28" align="left" valign="middle"><span class="no-fee-txt"><span class="colororange12">Logged in as </span>&nbsp;&nbsp;
                              <?=$_SESSION['usname']?>
                        </span></td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td height="86" align="center" valign="top">
					<table width="178" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td class="topmenubg"><table width="166" border="0" align="center" cellpadding="0" cellspacing="0">
                          
                          <tr>
                            <td height="1" background="images/dots.jpg"></td>
                          </tr>
                          <tr>
                            <td><table width="166" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td width="18" align="center"><img src="images/orange_bullet.gif" width="5" height="5" /></td>
                                <td width="128" height="28" align="left" valign="middle" class="white-bold-txt"><a href="auctions.php" class="no-fee-txt" onMouseOver="MM_swapImage('Image101','','images/aboutus_but_over.jpg',1)" onMouseOut="MM_swapImgRestore()">Your Auctions</a></td>
                              </tr>
                            </table></td>
                          </tr>
                          <tr>
                            <td height="1" background="images/dots.jpg"></td>
                          </tr>
                          <tr>
                            <td><table width="166" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td width="18" align="center"><img src="images/orange_bullet.gif" width="5" height="5" /></td>
                                <td width="128" height="28" align="left" valign="middle" class="white-bold-txt"><a href="bids.php" class="no-fee-txt" onMouseOver="MM_swapImage('Image101','','images/aboutus_but_over.jpg',1)" onMouseOut="MM_swapImgRestore()">Your Bids </a></td>
                              </tr>
                            </table></td>
                          </tr>
                          <tr>
                            <td height="1" background="images/dots.jpg"></td>
                          </tr>
                          <tr>
                            <td><table width="166" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td width="18" align="center"><img src="images/orange_bullet.gif" width="5" height="5" /></td>
                                <td width="128" height="28" align="left" valign="middle" class="white-bold-txt"><a href="logout.php" class="no-fee-txt" onMouseOver="MM_swapImage('Image101','','images/aboutus_but_over.jpg',1)" onMouseOut="MM_swapImgRestore()">Logout </a></td>
                              </tr>
                            </table></td>
                          </tr>
                        </table></td>
                      </tr>
                    </table>					</td>
                  </tr>
				<?
					}
				?>	
                  <tr>
                    <td height="15"></td>
                  </tr>
                  
                  <tr>
                    <td height="245" align="left" valign="top"><table width="177" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td height="28"><table width="177" border="0" align="center" cellpadding="0" cellspacing="0" class="buttonbg">
                            <tr>
                              <td width="18" align="right"><img src="images/orange_bullet.gif" width="5" height="5" /></td>
                              <td width="12"></td>
                              <td width="128" height="28" align="left" valign="middle"><a href="precomm.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image111','','images/pre_over.gif',1)"><img src="images/pre_but.gif" alt="Pre Commercial" name="Image111"  border="0" id="Image111" /></a></td>
                            </tr>
                        </table></td>
                      </tr>
                      
                      <tr>
                        <td height="28"><table width="177" border="0" align="center" cellpadding="0" cellspacing="0" class="buttonbg">
                          <tr>
                            <td width="18" align="right"><img src="images/orange_bullet.gif" width="5" height="5" /></td>
                            <td width="12"></td>
                            <td width="128" height="28" align="left" valign="middle"><a href="aboutus.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image10','','images/aboutus_but_over.jpg',1)"><img src="images/aboutus_but.jpg" alt="About us" name="Image10" width="52" height="9" border="0" id="Image10" /></a></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td height="28"><table width="177" border="0" align="center" cellpadding="0" cellspacing="0" class="buttonbg">
                          <tr>
                            <td width="18" align="right"><img src="images/orange_bullet.gif" width="5" height="5" /></td>
                            <td width="12"></td>
                            <td width="128" height="28" align="left" valign="middle"><a href="privacy.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image24','','images/policy_but_over.jpg',1)"><img src="images/policy_but.jpg" alt="privacy policy" name="Image24" width="82" height="9" border="0" id="Image24" /></a><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image101','','images/aboutus_but_over.jpg',1)"></a></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td height="28"><table width="177" border="0" align="center" cellpadding="0" cellspacing="0" class="buttonbg">
                          <tr>
                            <td width="18" align="right"><img src="images/orange_bullet.gif" width="5" height="5" /></td>
                            <td width="12"></td>
                            <td width="128" height="28" align="left" valign="middle"><a href="terms.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image25','','images/terms_but_over.jpg',1)"><img src="images/terms_but.jpg" alt="terms" name="Image25" width="96" height="9" border="0" id="Image25" /></a><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image102','','images/aboutus_but_over.jpg',1)"></a></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td height="28"><table width="177" border="0" align="center" cellpadding="0" cellspacing="0" class="buttonbg">
                          <tr>
                            <td width="18" align="right"><img src="images/orange_bullet.gif" width="5" height="5" /></td>
                            <td width="12"></td>
                            <td width="128" height="30" align="left" valign="middle"><? if($_SESSION['usname'])
							{
							?>
                                <a href="editprofile.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image261','','images/myaccount_but_over.jpg',1)"><img src="images/myaccount_but.jpg" alt="Myaccount" name="Image261"  border="0" id="Image261" /></a>
                                <? }else{?>
                                <a href="login.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image26','','images/register_but_over.jpg',1)"><img src="images/register_but.jpg" alt="register" name="Image26"  border="0" id="Image26" /></a>
                                <? }?>                            </td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td height="28"><table width="177" border="0" align="center" cellpadding="0" cellspacing="0" class="buttonbg">
                          <tr>
                            <td width="18" align="right"><img src="images/orange_bullet.gif" width="5" height="5" /></td>
                            <td width="12"></td>
                            <td width="128" height="30" align="left" valign="middle"><a href="faq.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image27','','images/faq_but_over.jpg',1)"><img src="images/faq_but.jpg" alt="faqs" name="Image27" width="30" height="9" border="0" id="Image27" /></a><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image104','','images/aboutus_but_over.jpg',1)"></a></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td height="28"><table width="177" border="0" align="center" cellpadding="0" cellspacing="0" class="buttonbg">
                          <tr>
                            <td width="18" align="right"><img src="images/orange_bullet.gif" width="5" height="5" /></td>
                            <td width="12"></td>
                            <td width="128" height="30" align="left" valign="middle"><a href="prwinners.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image28','','images/previous_but_over.jpg',1)"><img src="images/previous_but.jpg" alt="previous winners" name="Image28" width="104" height="9" border="0" id="Image28" /></a><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image105','','images/aboutus_but_over.jpg',1)"></a></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td height="28"><table width="177" border="0" align="center" cellpadding="0" cellspacing="0" class="buttonbg">
                          <tr>
                            <td width="18" align="right"><img src="images/orange_bullet.gif" width="5" height="5" /></td>
                            <td width="12"></td>
                            <td width="128" height="30" align="left" valign="middle"><a href="contactus.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image29','','images/contactus_but_over.jpg',1)"><img src="images/contactus_but.jpg" alt="contact us" name="Image29" width="67" height="9" border="0" id="Image29" /></a><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image106','','images/aboutus_but_over.jpg',1)"></a></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td height="30" align="left" valign="top"><table width="177" border="0" align="center" cellpadding="0" cellspacing="0" class="buttonbg">
                          <tr>
                            <td width="18" align="right"><img src="images/orange_bullet.gif" width="5" height="5" /></td>
                            <td width="12"></td>
                            <td width="128" height="30" align="left" valign="middle"><a href="site.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image30','','images/sitemap_but_over.jpg',1)"><img src="images/sitemap_but.jpg" alt="sitemap" name="Image30" width="50" height="9" border="0" id="Image30" /></a><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image107','','images/aboutus_but_over.jpg',1)"></a></td>
                          </tr>
                        </table></td>
                      </tr>
                    </table></td>
                  </tr>
                  
                </table></td>
              </tr>
              <tr>
                <td width="177" height="259" align="left" valign="top" background="images/jar_bg.jpg"><table width="177" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td height="8"></td>
                  </tr>
                  <tr>
                    <td><table width="177" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="11">&nbsp;</td>
                        <td width="166" align="left"><a href="kitty.php"><img src="images/kitty_txt.jpg" width="105" height="25" border="0" /></a></td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td height="5"></td>
                  </tr>
                  <tr>
                    <td align="center"><table width="88" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center"><a href="kitty.php"><img src="images/jar-img.jpg" width="88" height="124" border="0" /></a></td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td height="20"></td>
                  </tr>
                  <tr>
                    <td height="15" align="center" class="win-txt">Winning Auction Grand Prize</td>
                  </tr>
                  <tr>
                    <td><img src="images/$.jpg" width="184" height="28" /></td>
                  </tr>
                  <tr>
                    <td height="11"></td>
                  </tr>
                  
                </table></td>
              </tr>
              <tr>
                <td height="0" align="center" valign="middle"><img src="images/joker_img.gif" width="131" height="133" /></td>
              </tr>
              <tr>
                <td align="center" valign="middle">&nbsp;</td>
              </tr>
              
</table>